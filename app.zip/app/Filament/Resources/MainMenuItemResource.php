<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MainMenuItemResource\Pages;
use App\Models\MainMenuItem;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class MainMenuItemResource extends Resource
{
    protected static ?string $model = MainMenuItem::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-bars-3';
    protected static ?int $navigationSort = 5;

    public static function getNavigationGroup(): ?string { return 'الدعم والدليل'; }
    public static function getModelLabel(): string { return 'عنصر القائمة الرئيسية'; }
    public static function getPluralModelLabel(): string { return 'القائمة الرئيسية'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات عنصر القائمة')->schema([
                TextInput::make('label')->label('اسم العنصر')->required()->maxLength(100),
                Select::make('route_name')->label('الصفحة / المسار')->options([
                    'home' => 'الرئيسية',
                    'about' => 'من نحن',
                    'members.index' => 'الأعضاء',
                    'library.index' => 'المكتبة المرئية',
                    'blog.index' => 'المركز الإعلامي',
                    'faq.index' => 'الأسئلة الشائعة',
                    'contact.index' => 'تواصل معنا',
                ])->searchable()->nullable(),
                TextInput::make('url')->label('رابط مخصص (اختياري)')->url()->maxLength(500)
                    ->helperText('إذا أُدخل رابط مخصص فسيتم استخدامه بدلاً من مسار الصفحة.'),
                TextInput::make('icon')->label('الأيقونة')->maxLength(100),
                TextInput::make('sort_order')->label('الترتيب')->numeric()->minValue(0)->default(0)->required(),
                Toggle::make('is_visible')->label('إظهار في القائمة')->default(true),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->defaultSort('sort_order')->columns([
            TextColumn::make('sort_order')->label('الترتيب')->sortable(),
            TextColumn::make('label')->label('العنصر')->searchable(),
            TextColumn::make('route_name')->label('المسار')->placeholder('رابط مخصص'),
            IconColumn::make('is_visible')->label('ظاهر')->boolean(),
        ])->recordActions([
            Actions\EditAction::make(),
            Actions\DeleteAction::make()->requiresConfirmation(),
        ])->toolbarActions([
            Actions\CreateAction::make(),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMainMenuItems::route('/'),
            'create' => Pages\CreateMainMenuItem::route('/create'),
            'edit' => Pages\EditMainMenuItem::route('/{record}/edit'),
        ];
    }
}
