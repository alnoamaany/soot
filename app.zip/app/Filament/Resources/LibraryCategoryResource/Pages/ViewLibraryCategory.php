<?php
namespace App\Filament\Resources\LibraryCategoryResource\Pages;
use App\Filament\Resources\LibraryCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;
class ViewLibraryCategory extends ViewRecord { protected static string $resource = LibraryCategoryResource::class; protected function getHeaderActions(): array { return [Actions\EditAction::make()]; } }
