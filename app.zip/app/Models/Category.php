<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'slug',
        'parent_id',
        'sort_order',
    ];

    protected static function booted(): void
    {
        static::creating(function (Category $category): void {
            if (blank($category->slug)) {
                $category->slug = Str::slug($category->name);
            }

            if (is_null($category->sort_order)) {
                // الترتيب رقم فريد على مستوى جدول التصنيفات بالكامل مثل الـ slug.
                $category->sort_order = (int) static::query()->max('sort_order') + 1;
            }
        });

        static::deleting(function (Category $category): void {
            if ($category->children()->exists() || $category->posts()->exists()) {
                throw ValidationException::withMessages([
                    'record' => 'لا يمكن حذف هذا التصنيف لأنه يحتوي على تصنيفات فرعية أو عناصر مرتبطة به. انقل العناصر أولاً.',
                ]);
            }
        });

        static::updating(function (Category $category): void {
            if ($category->isDirty('name') && blank($category->slug)) {
                $category->slug = Str::slug($category->name);
            }
        });
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('sort_order')->orderBy('name');
    }

    public function posts(): HasMany
    {
        return $this->hasMany(Post::class);
    }

    public function descendantIds(bool $includeSelf = true): array
    {
        $ids = $includeSelf ? [$this->id] : [];
        $pending = [$this->id];

        while ($pending) {
            $parentId = array_pop($pending);
            $children = static::query()->where('parent_id', $parentId)->pluck('id')->all();
            foreach ($children as $childId) {
                $ids[] = $childId;
                $pending[] = $childId;
            }
        }

        return array_values(array_unique($ids));
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('name');
    }
}
