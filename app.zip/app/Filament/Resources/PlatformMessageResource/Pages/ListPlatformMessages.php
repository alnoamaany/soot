<?php
namespace App\Filament\Resources\PlatformMessageResource\Pages;
use App\Filament\Resources\PlatformMessageResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Actions\CreateAction;
class ListPlatformMessages extends ListRecords {protected static string $resource=PlatformMessageResource::class;protected function getHeaderActions():array{return [CreateAction::make()->label('إرسال رسالة')];}}
