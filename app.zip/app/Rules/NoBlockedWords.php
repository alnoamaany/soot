<?php

namespace App\Rules;

use App\Services\BlockedWordsService;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class NoBlockedWords implements ValidationRule
{
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $word = app(BlockedWordsService::class)->contains(is_scalar($value) ? (string) $value : null);
        if ($word !== null) {
            $fail('النص يحتوي على كلمة أو عبارة محظورة: ' . $word);
        }
    }
}
