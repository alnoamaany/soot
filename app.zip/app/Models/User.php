<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use App\Helper\Traits\Scopes\HasPrimaryImage;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\MediaLibrary\HasMedia;
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;

use Spatie\Permission\Traits\HasRoles;

#[Fillable(['name', 'email', 'password', 'phone', 'national_id', 'role', 'city', 'markaz', 'area', 'detailed_address', 'latitude', 'longitude', 'governorate_id', 'markaz_id', 'area_id', 'is_approved', 'fcm_token'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable implements HasMedia, FilamentUser
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable, HasPrimaryImage, HasRoles;

    public function canAccessPanel(Panel $panel): bool
    {
        return true;
    }
    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_approved' => 'boolean',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (User $user) {
            if (empty($user->email) && !empty($user->phone)) {
                $user->email = $user->phone . '@parliament.gov.eg';
            }
        });

        static::updated(function (User $user) {
            if ($user->wasChanged('is_approved') && (bool) $user->is_approved) {
                \App\Services\WelcomeEmailService::sendApprovalEmail($user);
            }
        });
    }

    public function isMp(): bool
    {
        if ($this->role === 'mp') {
            return true;
        }

        return $this->relationLoaded('mp') ? ($this->mp !== null) : $this->mp()->exists();
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isCitizen(): bool
    {
        return ! $this->isMp() && ! $this->isAdmin();
    }

    /**
     * Get the MP profile if the user is an MP.
     */
    public function mp()
    {
        return $this->hasOne(Mp::class);
    }

    /**
     * The MPs that the user is following.
     */
    public function followingMps()
    {
        return $this->belongsToMany(Mp::class, 'mp_followers', 'user_id', 'mp_id')->withTimestamps();
    }

    /**
     * The requests created by the user.
     */
    public function requests()
    {
        return $this->hasMany(MpRequest::class, 'user_id');
    }

    /**
     * Get the user's governorate.
     */
    public function governorate()
    {
        return $this->belongsTo(Governorate::class);
    }

    /**
     * Get the user's markaz.
     */
    public function markaz()
    {
        return $this->belongsTo(Markaz::class, 'markaz_id');
    }

    public function markazModel()
    {
        return $this->belongsTo(Markaz::class, 'markaz_id');
    }

    /**
     * Get the user's area.
     */
    public function areaModel()
    {
        return $this->belongsTo(Area::class, 'area_id');
    }
}
