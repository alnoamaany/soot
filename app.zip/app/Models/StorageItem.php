<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class StorageItem extends Model {
    protected $fillable=['owner_type','owner_id','folder','name','path','size','mime_type','item_type'];
}
