<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckMpSubscription
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check()) {
            $user = Auth::user();
            $mp = $user->mp;

            // If the user is an MP, check if their subscription has expired
            if ($mp && ! $mp->hasValidSubscription()) {
                Auth::logout();
                if ($request->hasSession()) {
                    $request->session()->invalidate();
                    $request->session()->regenerateToken();
                }

                $errorMessage = 'انتهت فترة اشتراكك البرلماني، يرجى تجديد الاشتراك للمتابعة والوصول إلى خدمات النائب.';

                if ($request->expectsJson()) {
                    return response()->json([
                        'message' => $errorMessage,
                        'subscription_expired' => true,
                    ], 403);
                }

                return redirect()->route('login')->with('error', $errorMessage);
            }
        }

        return $next($request);
    }
}
