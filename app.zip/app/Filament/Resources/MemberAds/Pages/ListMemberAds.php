<?php

namespace App\Filament\Resources\MemberAds\Pages;

use App\Filament\Resources\MemberAds\MemberAdResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListMemberAds extends ListRecords
{
    protected static string $resource = MemberAdResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
