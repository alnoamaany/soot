<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SitePage extends Model {
    protected $fillable=['title','slug','content','is_visible','show_in_navigation','sort_order','contact_phone','contact_email','contact_address','contact_intro'];
    protected $casts=['is_visible'=>'boolean','show_in_navigation'=>'boolean'];
}
