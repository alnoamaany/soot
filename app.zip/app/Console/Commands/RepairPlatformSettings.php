<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RepairPlatformSettings extends Command
{
    protected $signature = 'platform:repair-settings';
    protected $description = 'إصلاح إعدادات المنصة القديمة، خصوصاً blocked_words، دون فقد إعدادات أخرى.';

    public function handle(): int
    {
        if (! DB::getSchemaBuilder()->hasTable('settings')) {
            $this->warn('جدول settings غير موجود. شغّل migrations أولاً.');
            return self::FAILURE;
        }

        $updated = DB::table('settings')
            ->where('group', 'general')
            ->where('name', 'blocked_words')
            ->where(function ($query) {
                $query->whereNull('payload')->orWhere('payload', 'null');
            })
            ->update([
                'payload' => json_encode('', JSON_UNESCAPED_UNICODE),
            ]);

        if ($updated === 0) {
            $exists = DB::table('settings')
                ->where('group', 'general')
                ->where('name', 'blocked_words')
                ->exists();

            if (! $exists) {
                DB::table('settings')->insert([
                    'group' => 'general',
                    'name' => 'blocked_words',
                    'locked' => false,
                    'payload' => json_encode('', JSON_UNESCAPED_UNICODE),
                ]);
                $updated = 1;
            }
        }

        $this->info($updated ? 'تم إصلاح blocked_words بنجاح.' : 'لا توجد قيمة تحتاج إلى إصلاح.');
        return self::SUCCESS;
    }
}
