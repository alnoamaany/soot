<?php

namespace App\Filament\Resources\MainMenuItemResource\Pages;

use App\Filament\Resources\MainMenuItemResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMainMenuItem extends CreateRecord
{
    protected static string $resource = MainMenuItemResource::class;
}
