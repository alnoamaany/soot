<?php
namespace App\Filament\Resources\AccessBanResource\Pages;
use App\Filament\Resources\AccessBanResource;
use Filament\Resources\Pages\EditRecord;
class EditAccessBan extends EditRecord { protected static string $resource=AccessBanResource::class; }
