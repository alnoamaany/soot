<?php
namespace App\Filament\Resources;
use App\Filament\Resources\ConnectedSessionResource\Pages;
use App\Models\ConnectedSession;
use App\Models\User;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\DB;

class ConnectedSessionResource extends Resource {
 protected static ?string $model=ConnectedSession::class;
 protected static string|\BackedEnum|null $navigationIcon='heroicon-o-signal';
 protected static ?int $navigationSort=5;
 public static function getNavigationGroup(): ?string{return 'إدارة الحسابات';}
 public static function getModelLabel():string{return 'بيانات المتصلين';}
 public static function getPluralModelLabel():string{return 'بيانات المتصلين';}
 public static function form(Schema $schema):Schema{return $schema->components([Section::make('بيانات الاتصال')->schema([
  Select::make('user_id')->label('المستخدم')->options(fn()=>User::orderBy('name')->pluck('name','id'))->searchable()->disabled(),
 ])]);}
 public static function table(Table $table):Table{return $table->columns([
  TextColumn::make('user.name')->label('المستخدم')->placeholder('زائر')->searchable(),
  TextColumn::make('user.role')->label('الفئة')->formatStateUsing(fn($s)=>match($s){'mp'=>'نائب','admin'=>'إداري',default=>'مواطن'})->badge(),
  TextColumn::make('ip_address')->label('IP')->copyable()->searchable(),
  TextColumn::make('country')->label('الدولة')->placeholder('غير متاح'),
  TextColumn::make('device_fingerprint')->label('معرّف الجهاز')->limit(18)->copyable(),
  TextColumn::make('last_activity')->label('آخر نشاط')->dateTime('Y-m-d H:i'),
  TextColumn::make('user_agent')->label('المتصفح والجهاز')->limit(45)->wrap(),
  TextColumn::make('mac_address')->label('MAC')->default('غير متاح عبر متصفح الإنترنت'),
  ])->filters([
    SelectFilter::make('user_role')->label('الفئة')->options(['guest'=>'الزوار','citizen'=>'المواطنون','mp'=>'النواب','admin'=>'الإداريون'])
      ->query(function($query,$data){$role=$data['value']??null;if(!$role)return $query;if($role==='guest')return $query->whereNull('user_id');return $query->whereHas('user',fn($q)=>$q->where('role',$role));}),
  ])->recordActions([
    Action::make('ban')->label('حظر IP')->icon('heroicon-o-no-symbol')->color('danger')->requiresConfirmation()
      ->form([\Filament\Forms\Components\Textarea::make('reason')->label('سبب المنع')->required()])
      ->action(function(ConnectedSession $record,array $data){\App\Models\AccessBan::create(['ip_address'=>$record->ip_address,'reason'=>$data['reason'],'is_active'=>true,'created_by_admin_id'=>auth('admin')->id()]);Notification::make()->title('تم حظر عنوان IP')->success()->send();}),
  ])->defaultSort('last_activity','desc')->poll('30s');}
 public static function getPages():array{return ['index'=>Pages\ListConnectedSessions::route('/')];}
}
