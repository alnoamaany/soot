<?php

namespace App\Filament\Resources\MainMenuItemResource\Pages;

use App\Filament\Resources\MainMenuItemResource;
use Filament\Resources\Pages\ListRecords;

class ListMainMenuItems extends ListRecords
{
    protected static string $resource = MainMenuItemResource::class;
}
