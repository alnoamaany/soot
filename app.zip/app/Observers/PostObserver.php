<?php
namespace App\Observers;

use App\Models\Post;
use App\Services\AdminAlertService;

class PostObserver
{
    public function created(Post $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');
        AdminAlertService::notify(
            'article_created',
            'إضافة خبر أو مقال جديد',
            str_replace(['{title}'], [$title], 'تمت إضافة الخبر/المقال "{title}" بواسطة النائب.'),
            $model,
            meta: ['post_id' => $model->id],
        );
    }
}
