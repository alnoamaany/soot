<?php
namespace App\Observers;

use App\Models\ContactMessage;
use App\Services\AdminAlertService;

class ContactMessageObserver
{
    public function created(ContactMessage $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');
        AdminAlertService::notify(
            'contact_message_created',
            'رسالة تواصل جديدة',
            str_replace(['{title}'], [$title], 'وصلت رسالة جديدة من {title}.'),
            $model,
            meta: ['contact_id' => $model->id],
        );
    }
}
