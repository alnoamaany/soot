<?php
namespace App\Filament\Resources\PlatformImportantNotificationResource\Pages;
use App\Filament\Resources\PlatformImportantNotificationResource;
use Filament\Resources\Pages\CreateRecord;
class CreatePlatformImportantNotification extends CreateRecord { protected static string $resource = PlatformImportantNotificationResource::class; }
