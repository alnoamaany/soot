<?php
namespace App\Observers;

use App\Models\Admin;
use App\Services\AdminAlertService;

class AdminObserver
{
    public function created(Admin $admin): void
    {
        AdminAlertService::notify(
            'admin_created',
            'إضافة مدير منصة',
            "تم إنشاء حساب المدير {$admin->name}.",
            $admin,
            meta: ['admin_id' => $admin->id],
        );
    }

    public function updated(Admin $admin): void
    {
        if ($admin->wasChanged('password')) {
            AdminAlertService::notify(
                'admin_password_changed',
                'تغيير كلمة مرور مدير',
                "تم تغيير كلمة مرور المدير {$admin->name}.",
                $admin,
                meta: ['admin_id' => $admin->id],
            );
        }

        if ($admin->wasChanged('is_active')) {
            AdminAlertService::notify(
                $admin->is_active ? 'admin_activated' : 'admin_deactivated',
                $admin->is_active ? 'تفعيل مدير منصة' : 'تعطيل مدير منصة',
                $admin->is_active
                    ? "تم تفعيل حساب المدير {$admin->name}."
                    : "تم تعطيل حساب المدير {$admin->name}.",
                $admin,
                meta: ['admin_id' => $admin->id, 'is_active' => (bool) $admin->is_active],
            );
        }
    }
}
