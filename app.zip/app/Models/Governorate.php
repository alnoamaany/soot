<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Governorate extends Model
{
    use HasFactory;

    protected $fillable = ['name_ar', 'name_en'];

    public function areas()
    {
        return $this->hasMany(Area::class);
    }

    public function markazes()
    {
        return $this->hasMany(Markaz::class);
    }

    public function users()
    {
        return $this->hasMany(User::class);
    }
}
