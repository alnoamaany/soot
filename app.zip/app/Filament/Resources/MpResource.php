<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MpResource\Pages;
use App\Models\Mp;
use App\Models\SubscriptionPlan;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Area;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Infolists\Components\SpatieMediaLibraryImageEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Components\Section;

class MpResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = Mp::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-identification';
    protected static ?int $navigationSort = 2;

    public static function getModelLabel(): string
    {
        return 'نائب شعب';
    }

    public static function getPluralModelLabel(): string
    {
        return 'نواب الشعب';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة المستخدمين والأعضاء';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات حساب النائب')
                ->schema([
                    TextInput::make('user_name')
                        ->label('الاسم الكامل')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('user_email')
                        ->label('البريد الإلكتروني')
                        ->email()
                        ->required()
                        ->maxLength(255)
                        ->unique(table: 'users', column: 'email', ignorable: fn (?Mp $record) => $record?->user),
                    TextInput::make('user_phone')
                        ->label('رقم الهاتف')
                        ->required()
                        ->rules([new \App\Rules\EgyptianPhone()])
                        ->maxLength(20)
                        ->unique(table: 'users', column: 'phone', ignorable: fn (?Mp $record) => $record?->user),
                    TextInput::make('user_national_id')
                        ->label('الرقم القومي (اختياري)')
                        ->nullable()
                        ->numeric()
                        ->length(14)
                        ->unique(table: 'users', column: 'national_id', ignorable: fn (?Mp $record) => $record?->user),
                    TextInput::make('user_password')
                        ->label('كلمة المرور')
                        ->password()
                        ->revealable()
                        ->required(fn (string $operation): bool => $operation === 'create')
                        ->minLength(8)
                        ->helperText(fn (string $operation): ?string => $operation === 'edit' ? 'اتركها فارغة إذا كنت لا ترغب في تغيير كلمة المرور' : null),
                    FileUpload::make('user_avatar')
                        ->label('الصورة الشخصية')
                        ->disk('public')
                        ->directory('mp-avatars')
                        ->image()
                        ->imageEditor()
                        ->maxSize(2048)
                        ->helperText(fn (string $operation): ?string => $operation === 'edit' ? 'اتركها فارغة للإبقاء على الصورة الحالية' : null),
                    Select::make('user_governorate_id')
                        ->label('المحافظة')
                        ->options(fn () => Governorate::orderBy('name_ar')->pluck('name_ar', 'id'))
                        ->searchable()
                        ->preload()
                        ->reactive()
                        ->afterStateUpdated(function (callable $set): void {
                            $set('user_markaz_id', null);
                            $set('user_area_id', null);
                        }),
                    Select::make('user_markaz_id')
                        ->label('المركز / القسم')
                        ->options(fn (callable $get) => filled($get('user_governorate_id'))
                            ? Markaz::where('governorate_id', $get('user_governorate_id'))->orderBy('name_ar')->pluck('name_ar', 'id')
                            : [])
                        ->searchable()
                        ->preload()
                        ->disabled(fn (callable $get): bool => blank($get('user_governorate_id')))
                        ->reactive()
                        ->afterStateUpdated(fn (callable $set) => $set('user_area_id', null)),
                    Select::make('user_area_id')
                        ->label('المنطقة / الحي')
                        ->options(fn (callable $get) => filled($get('user_markaz_id'))
                            ? Area::where('markaz_id', $get('user_markaz_id'))->orderBy('name_ar')->pluck('name_ar', 'id')
                            : [])
                        ->searchable()
                        ->preload()
                        ->disabled(fn (callable $get): bool => blank($get('user_markaz_id'))),
                ])->columns(2),
            Section::make('بيانات النائب البرلمانية والدائرة')
                ->schema([
                    Select::make('subscription_plan_id')
                        ->label('خطة الاشتراك')
                        ->options(fn () => SubscriptionPlan::query()
                            ->where('is_active', true)
                            ->orderBy('name')
                            ->get()
                            ->mapWithKeys(fn (SubscriptionPlan $p) => [
                                $p->id => $p->name . ' (' . ($p->request_limit > 0 ? "حد: {$p->request_limit} / " . match($p->limit_period) { 'weekly' => 'أسبوع', 'monthly' => 'شهر', default => 'يوم' } : 'طلبات غير محدودة') . ' - ' . number_format($p->price, 0) . ' ج.م)'
                            ]))
                        ->searchable()
                        ->preload()
                        ->reactive()
                        ->afterStateUpdated(function ($state, callable $set) {
                            if ($state) {
                                $plan = SubscriptionPlan::find($state);
                                if ($plan) {
                                    $set('request_limit', (int) $plan->request_limit);
                                    $set('limit_period', $plan->limit_period ?: 'daily');
                                }
                            }
                        })
                        ->required(fn (string $operation): bool => $operation === 'create')
                        ->helperText('يتم تعيين وتحديث اشتراك النائب وحد استقبال الطلبات تلقائيًا حسب الخطة المختارة.'),
                    Textarea::make('user_detailed_address')
                        ->label('العنوان التفصيلي')
                        ->rows(3)
                        ->maxLength(1000)
                        ->columnSpanFull(),
                    TextInput::make('title')
                        ->label('لقب النائب')
                        ->placeholder('مثال: النائب / الدكتورة')
                        ->maxLength(100),
                    TextInput::make('party')
                        ->label('الحزب السياسي')
                        ->placeholder('مثال: مستقبل وطن / مستقل')
                        ->maxLength(255),
                    TextInput::make('district')
                        ->label('الدائرة الانتخابية')
                        ->placeholder('مثال: دائرة بندر المنيا')
                        ->maxLength(255),
                    TextInput::make('reception_hours')
                        ->label('مواعيد استقبال المواطنين')
                        ->placeholder('مثال: الأحد والأربعاء من كل أسبوع (5م - 9م)')
                        ->maxLength(255),
                    Textarea::make('bio')
                        ->label('نبذة عن النائب والسيرة الذاتية')
                        ->rows(4)
                        ->maxLength(2000)
                        ->columnSpanFull(),
                    Toggle::make('is_active')
                        ->label('حساب النائب نشط ومُفعّل')
                        ->default(true),
                    Toggle::make('is_featured')
                        ->label('عرض كنائب مميز في الصفحة الرئيسية')
                        ->default(false),
                ]),

            Section::make('إعدادات ظهور إحصائيات صفحة النائب')
                ->description('يمكن اختيار التلقائي ليتغير الرقم تلقائياً مع الطلبات والمتابعين والمحتوى، أو اليدوي لتحديد رقم ثابت لهذا النائب.')
                ->schema([
                    Select::make('followers_stat_mode')->label('عدد المتابعين')->options(['automatic' => 'تلقائي', 'manual' => 'يدوي'])->default('automatic')->required()->live(),
                    TextInput::make('followers_stat_manual')->label('عدد المتابعين اليدوي')->numeric()->minValue(0)->visible(fn (callable $get): bool => $get('followers_stat_mode') === 'manual')->required(fn (callable $get): bool => $get('followers_stat_mode') === 'manual'),
                    Select::make('completed_requests_stat_mode')->label('الطلبات المنجزة')->options(['automatic' => 'تلقائي', 'manual' => 'يدوي'])->default('automatic')->required()->live(),
                    TextInput::make('completed_requests_stat_manual')->label('الطلبات المنجزة اليدوي')->numeric()->minValue(0)->visible(fn (callable $get): bool => $get('completed_requests_stat_mode') === 'manual')->required(fn (callable $get): bool => $get('completed_requests_stat_mode') === 'manual'),
                    Select::make('recorded_videos_stat_mode')->label('الفيديوهات المسجلة')->options(['automatic' => 'تلقائي', 'manual' => 'يدوي'])->default('automatic')->required()->live(),
                    TextInput::make('recorded_videos_stat_manual')->label('الفيديوهات المسجلة اليدوي')->numeric()->minValue(0)->visible(fn (callable $get): bool => $get('recorded_videos_stat_mode') === 'manual')->required(fn (callable $get): bool => $get('recorded_videos_stat_mode') === 'manual'),
                    Select::make('response_rate_stat_mode')->label('معدل الاستجابة')->options(['automatic' => 'تلقائي', 'manual' => 'يدوي'])->default('automatic')->required()->live(),
                    TextInput::make('response_rate_stat_manual')->label('معدل الاستجابة اليدوي %')->numeric()->minValue(0)->maxValue(100)->visible(fn (callable $get): bool => $get('response_rate_stat_mode') === 'manual')->required(fn (callable $get): bool => $get('response_rate_stat_mode') === 'manual'),
                ])->columns(2),

            Section::make('إعدادات حد استقبال الطلبات (مرتبطة بباقة الاشتراك)')
                ->description('يتم جلب حد الطلبات وفترتها تلقائياً وفقاً لباقة الاشتراك المحددة للنائب.')
                ->schema([
                    TextInput::make('request_limit')
                        ->label('الحد الأقصى للطلبات')
                        ->helperText('يتم ضبطه تلقائياً من باقة الاشتراك المختارة (0 = غير محدود).')
                        ->numeric()
                        ->default(0)
                        ->required(),
                    Select::make('limit_period')
                        ->label('فترة تحديد الحد')
                        ->options([
                            'daily' => 'يومي (تجدد يومياً)',
                            'weekly' => 'أسبوعي (تجدد أسبوعياً)',
                            'monthly' => 'شهري (تجدد شهرياً)',
                        ])
                        ->default('daily')
                        ->required(),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            SpatieMediaLibraryImageColumn::make('user.avatar')->collection('avatar')->label('صورة النائب'),
            TextColumn::make('display_name')->label('اسم النائب'),
            TextColumn::make('user.phone')->label('الهاتف')->searchable(),
            TextColumn::make('party')->label('الحزب')->searchable()->sortable(),
            TextColumn::make('district')->label('الدائرة')->searchable()->sortable(),
            TextColumn::make('followers_count')
                ->label('عدد المتابعين')
                ->getStateUsing(fn (Mp $record) => $record->followers()->count()),
            TextColumn::make('requests_count')
                ->label('عدد الطلبات')
                ->getStateUsing(fn (Mp $record) => $record->requests()->count()),
            IconColumn::make('is_featured')->boolean()->label('مميز'),
            IconColumn::make('is_active')->boolean()->label('نشط'),
            TextColumn::make('created_at')->label('تاريخ الإنشاء')->dateTime()->sortable(),
        ])
        ->recordActions([
            Actions\ViewAction::make(),
            Actions\EditAction::make(),
        ])
        ->filters([]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('معلومات النائب والدائرة')
                ->schema([
                    TextEntry::make('display_name')->label('اسم النائب'),
                    TextEntry::make('user.phone')->label('رقم الهاتف'),
                    TextEntry::make('user.email')->label('البريد الإلكتروني'),
                    TextEntry::make('party')->label('الحزب السياسي'),
                    TextEntry::make('district')->label('الدائرة الانتخابية'),
                    TextEntry::make('reception_hours')->label('مواعيد استقبال المواطنين')->placeholder('غير محددة'),
                    TextEntry::make('followers_count')
                        ->label('إجمالي المتابعين')
                        ->getStateUsing(fn ($record) => $record->followers()->count()),
                    TextEntry::make('requests_count')
                        ->label('إجمالي الطلبات الموجهة')
                        ->getStateUsing(fn ($record) => $record->requests()->count()),
                    TextEntry::make('is_featured')
                        ->label('نائب مميز')
                        ->formatStateUsing(fn ($state) => $state ? 'نعم' : 'لا'),
                    TextEntry::make('is_active')
                        ->label('حالة التفعيل')
                        ->formatStateUsing(fn ($state) => $state ? 'نشط ومفعل' : 'غير نشط'),
                    TextEntry::make('bio')
                        ->label('السيرة الذاتية / نبذة')
                        ->columnSpanFull(),
                ]),
            Section::make('بيانات النطاق الجغرافي للنائب')
                ->schema([
                    TextEntry::make('user.governorate.name_ar')->label('المحافظة'),
                    TextEntry::make('user.markaz.name_ar')->label('المركز/القسم'),
                    TextEntry::make('user.areaModel.name_ar')->label('المنطقة/الحي'),
                ]),
        ]);
    }

    public static function getRelations(): array
    {
        return [
            \App\Filament\Resources\MpResource\RelationManagers\VideosRelationManager::class,
            \App\Filament\Resources\MpResource\RelationManagers\PlatformMessagesRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMps::route('/'),
            'create' => Pages\CreateMp::route('/create'),
            'edit' => Pages\EditMp::route('/{record}/edit'),
            'view' => Pages\ViewMp::route('/{record}'),
        ];
    }
}
