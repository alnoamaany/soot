<?php

namespace App\Filament\Resources\MpResource\RelationManagers;

use App\Models\PlatformMessage;
use App\Notifications\PlatformMessageNotification;
use Filament\Actions;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;

class PlatformMessagesRelationManager extends RelationManager
{
    protected static string $relationship = 'platformMessages';
    protected static ?string $title = 'الرسائل الإدارية — إرسال رسالة';
    protected static ?string $recordTitleAttribute = 'subject';

    public function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('subject')->label('عنوان الرسالة')->required()->maxLength(255),
            Textarea::make('message')->label('نص الرسالة')->required()->rows(8)->columnSpanFull(),
            SpatieMediaLibraryFileUpload::make('attachments')
                ->label('مرفقات الرسالة (حتى 50 ميجابايت للملف الواحد)')
                ->collection('attachments')
                ->multiple()
                ->maxSize(51200)
                ->downloadable()
                ->openable()
                ->columnSpanFull(),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('subject')->label('العنوان')->searchable()->wrap(),
            TextColumn::make('message')->label('الرسالة')->limit(80)->wrap(),
            TextColumn::make('media_count')->label('المرفقات')->getStateUsing(fn (PlatformMessage $record) => $record->getMedia('attachments')->count()),
            TextColumn::make('sent_at')->label('تاريخ الإرسال')->dateTime()->sortable(),
        ])->recordActions([
            Actions\EditAction::make(),
            Actions\DeleteAction::make()->requiresConfirmation(),
        ])->headerActions([
            Actions\CreateAction::make()
                ->label('إرسال رسالة إدارية')
                ->icon('heroicon-o-paper-airplane')
                ->after(function (PlatformMessage $message): void {
                    $mp = $this->getOwnerRecord();
                    $message->update([
                        'mp_id' => $mp->id,
                        'sender_type' => 'admin',
                        'sender_id' => auth('admin')->id(),
                        'recipient_type' => 'mp',
                        'recipient_id' => $mp->user_id,
                        'sent_at' => now(),
                    ]);
                    if ($mp->user) {
                        $mp->user->notify(new PlatformMessageNotification(
                            title: 'رسالة إدارية جديدة',
                            message: $message->subject,
                            url: route('member.dashboard')
                        ));
                    }

                    Notification::make()
                        ->title('تم إرسال الرسالة الإدارية للنائب')
                        ->success()
                        ->send();
                }),
        ]);
    }
}
