<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MpSubscriptionResource\Pages;
use App\Models\Mp;
use App\Models\MpSubscription;
use App\Models\SubscriptionPlan;
use Filament\Actions;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class MpSubscriptionResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = MpSubscription::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-calendar-days';
    protected static ?int $navigationSort = 5;
    public static function getNavigationGroup(): ?string { return 'الاشتراكات'; }
    public static function getModelLabel(): string { return 'اشتراك عضو'; }
    public static function getPluralModelLabel(): string { return 'اشتراكات الأعضاء'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([Section::make('إسناد الاشتراك')->schema([
            Select::make('mp_id')->label('عضو البرلمان')->options(fn () => Mp::with('user')->get()->mapWithKeys(fn (Mp $mp) => [$mp->id => $mp->display_name ?: "عضو #{$mp->id}"]))->searchable()->required(),
            Select::make('subscription_plan_id')->label('خطة الاشتراك')->options(fn () => SubscriptionPlan::where('is_active', true)->pluck('name', 'id'))->searchable()->required(),
            DatePicker::make('starts_at')->label('تاريخ البداية')->default(today())->required(),
            TextInput::make('price')->label('السعر المدفوع')->numeric()->prefix('ج.م')->helperText('اتركه فارغًا لاستخدام سعر الخطة.'),
            TextInput::make('free_days')->label('أيام مجانية إضافية')->numeric()->minValue(0)->helperText('اتركه فارغًا لاستخدام أيام الخطة المجانية.'),
            Select::make('status')->label('الحالة')->options(['active' => 'نشط', 'cancelled' => 'ملغي', 'expired' => 'منتهي'])->default('active')->required(),
        ])]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('mp.user.name')->label('العضو')->searchable(),
            TextColumn::make('plan.name')->label('الخطة')->searchable(),
            TextColumn::make('price')->label('السعر')->money('EGP'),
            TextColumn::make('starts_at')->label('يبدأ')->date(),
            TextColumn::make('ends_at')->label('ينتهي')->date()->color(fn (MpSubscription $record) => $record->ends_at->isPast() ? 'danger' : null),
            TextColumn::make('status')->label('الحالة')->badge()->color(fn (string $state) => ['active' => 'success', 'expired' => 'danger', 'cancelled' => 'gray'][$state] ?? 'gray'),
            TextColumn::make('reminder_sent_at')->label('أُرسل التنبيه')->dateTime()->placeholder('لم يُرسل'),
        ])->recordActions([Actions\EditAction::make(), Actions\DeleteAction::make()]);
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListMpSubscriptions::route('/'), 'create' => Pages\CreateMpSubscription::route('/create'), 'edit' => Pages\EditMpSubscription::route('/{record}/edit')];
    }
}
