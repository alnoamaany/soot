<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ContactController extends Controller
{
    public function index()
    {
        return view('pages.contact');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'nullable|string|email|max:255',
            'type' => 'required|string|in:inquiry,complaint,suggestion,other',
            'message' => 'required|string|max:5000',
            'other_message' => 'nullable|required_if:type,other|string|max:255',
            'cf-turnstile-response' => ['required', new \App\Rules\Turnstile()],
            'attachments' => 'nullable|array|max:5',
            'attachments.*' => 'file|mimes:jpg,jpeg,png,pdf,doc,docx|max:10240',
        ], [
            'name.required' => 'الاسم بالكامل مطلوب.',
            'phone.required' => 'رقم الهاتف مطلوب.',
            'email.email' => 'البريد الإلكتروني غير صحيح.',
            'type.required' => 'يرجى اختيار نوع الرسالة.',
            'other_message.required' => 'يرجى كتابة تفاصيل نوع الرسالة الأخرى.',
            'message.required' => 'نص الرسالة مطلوب.',
            'cf-turnstile-response.required' => 'يرجى تأكيد التحقق الأمني (الكابتشا).',
            'attachments.*.mimes' => 'أنواع الملفات المسموح بها: JPG, PNG, PDF, DOC, DOCX.',
            'attachments.*.max' => 'الحد الأقصى لحجم كل ملف هو 10 ميجابايت.',
        ]);

        $contactMessage = ContactMessage::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'type' => $request->type,
            'message' => $request->type === 'other' && $request->filled('other_message')
                ? $request->message . "\n\nنوع الرسالة: " . $request->other_message
                : $request->message,
        ]);

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                if ($file->isValid()) {
                    $contactMessage->addMedia($file)->toMediaCollection('attachments');
                }
            }
        }

        return back()->with('success', 'تم إرسال رسالتك بنجاح. وسنقوم بالتواصل معك في أقرب وقت.');
    }
}
