<?php

namespace App\Filament\Resources\LibraryCategoryResource\Pages;

use App\Filament\Resources\LibraryCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
use Filament\Support\Enums\Width;

class EditLibraryCategory extends EditRecord
{
    protected static string $resource = LibraryCategoryResource::class;
    protected string|Width|null $maxContentWidth = Width::Full;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
