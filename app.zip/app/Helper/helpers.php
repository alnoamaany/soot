<?php

use App\Settings\PixelSettings;


if (! function_exists('pixel_settings')) {
    function pixel_settings(): PixelSettings
    {
        return app(PixelSettings::class);
    }
}

if (! function_exists('versioned_asset')) {
    /**
     * Generate an asset path with automatic filemtime versioning to bust browser cache on updates.
     */
    function versioned_asset(string $path): string
    {
        $cleanPath = ltrim($path, '/\\');
        $realPath = public_path($cleanPath);

        if (file_exists($realPath)) {
            $version = filemtime($realPath);
            return asset($cleanPath) . '?v=' . $version;
        }

        return asset($cleanPath) . '?v=' . time();
    }
}

