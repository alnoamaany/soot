<?php

namespace App\Helper\Traits\Filamentv4;

use Illuminate\Database\Eloquent\Model;

trait FilamentCountBadgeRelationManager
{
    // For Relation Managers
    public static function getBadge(Model $ownerRecord, string $pageClass): ?string
    {
        return $ownerRecord->{self::getRelationshipName()}()->count();
    }

    // For Relation Managers
    public static function getBadgeColor(Model $ownerRecord, string $pageClass): ?string
    {
        return $ownerRecord->{self::getRelationshipName()}()->exists() ? 'primary' : 'danger';
    }
}
