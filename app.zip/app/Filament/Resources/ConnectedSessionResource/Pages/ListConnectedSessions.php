<?php
namespace App\Filament\Resources\ConnectedSessionResource\Pages;
use App\Filament\Resources\ConnectedSessionResource;
use Filament\Resources\Pages\ListRecords;
class ListConnectedSessions extends ListRecords { protected static string $resource=ConnectedSessionResource::class; }
