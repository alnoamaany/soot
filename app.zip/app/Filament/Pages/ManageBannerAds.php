<?php

namespace App\Filament\Pages;

use App\Settings\GeneralSettings;
use Filament\Pages\SettingsPage;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Placeholder;

class ManageBannerAds extends SettingsPage
{
    protected static string $settings = GeneralSettings::class;

    public static function getNavigationIcon(): string
    {
        return 'heroicon-o-photo';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'الدعاية والإعلان';
    }

    public static function getNavigationSort(): ?int
    {
        return 1;
    }

    public static function getNavigationLabel(): string
    {
        return 'الإعلانات العادية (الصفحة الرئيسية)';
    }

    public function getTitle(): string
    {
        return 'الإعلانات العادية (الصفحة الرئيسية)';
    }

    public function form(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make('مواضع الإعلانات')
                ->tabs([
                    $this->tab('below_ticker', 'تحت شريط عاجل'),
                    $this->tab('below_hero', 'تحت الهيرو'),
                    $this->tab('below_track', 'تحت تتبع الطلب'),
                    $this->tab('below_request_banner', 'تحت الطلبات'),
                    $this->tab('below_members', 'تحت الأعضاء'),
                    $this->tab('below_news', 'تحت الأخبار'),
                    $this->tab('below_polls', 'تحت الاستطلاعات'),
                    $this->tab('below_library', 'تحت المكتبة'),
                ])
                ->columnSpanFull(),
        ]);
    }

    private function tab(string $key, string $label): Tab
    {
        return Tab::make($label)
            ->schema([
                Toggle::make("home_banner_ads.{$key}.enabled")
                    ->label('تفعيل الإعلان')
                    ->helperText('إظهار أو إخفاء الإعلان في هذا الموضع.')
                    ->columnSpanFull(),

                FileUpload::make("home_banner_ads.{$key}.image")
                    ->label('بانر الإعلان')
                    ->image()
                    ->directory('ads')
                    ->helperText('ارفع صورة الإعلان. المقاسات أدناه تتحكم في طريقة ظهورها على الموقع.'),

                TextInput::make("home_banner_ads.{$key}.url")
                    ->label('رابط الإعلان')
                    ->url()
                    ->placeholder('https://example.com/target-page'),

                TextInput::make("home_banner_ads.{$key}.title")
                    ->label('العنوان')
                    ->placeholder('المساحة الإعلانية الرسمية'),

                TextInput::make("home_banner_ads.{$key}.subtitle")
                    ->label('النص الفرعي')
                    ->placeholder('النص التوضيحي للإعلان'),

                Section::make('إعدادات مقاس الإعلان')
                    ->description('يمكن ضبط المقاس بشكل مستقل. المقاسات المقترحة: سطح المكتب 1200×320 — التابلت 768×240 — الموبايل 360×180.')
                    ->schema([
                        TextInput::make("home_banner_ads.{$key}.desktop.width")
    ->dehydrated(true)
                            ->label('سطح المكتب — العرض')
                            ->numeric()
                            ->dehydrated(true)
                            ->minValue(100)
                            ->maxValue(3000)
                            ->default(1200)
                            ->suffix('px')
                            ->helperText('الافتراضي: 1200'),

                        TextInput::make("home_banner_ads.{$key}.desktop.height")
                            ->label('سطح المكتب — الارتفاع')
                            ->numeric()
                            ->dehydrated(true)
                            ->minValue(50)
                            ->maxValue(1000)
                            ->default(320)
                            ->suffix('px')
                            ->helperText('المقترح: 320px — المقاس الافتراضي الجديد للإعلانات العريضة'),

                        TextInput::make("home_banner_ads.{$key}.tablet.width")
                            ->label('التابلت — العرض')
                            ->numeric()
                            ->dehydrated(true)
                            ->minValue(100)
                            ->maxValue(2000)
                            ->default(768)
                            ->suffix('px')
                            ->helperText('الافتراضي: 768'),

                        TextInput::make("home_banner_ads.{$key}.tablet.height")
                            ->label('التابلت — الارتفاع')
                            ->numeric()
                            ->dehydrated(true)
                            ->minValue(50)
                            ->maxValue(800)
                            ->default(240)
                            ->suffix('px')
                            ->helperText('المقترح: 240px — مناسب للتابلت'),

                        TextInput::make("home_banner_ads.{$key}.mobile.width")
                            ->label('الموبايل — العرض')
                            ->numeric()
                            ->dehydrated(true)
                            ->minValue(100)
                            ->maxValue(1000)
                            ->default(360)
                            ->suffix('px')
                            ->helperText('الافتراضي: 360'),

                        TextInput::make("home_banner_ads.{$key}.mobile.height")
                            ->label('الموبايل — الارتفاع')
                            ->numeric()
                            ->dehydrated(true)
                            ->minValue(50)
                            ->maxValue(600)
                            ->default(180)
                            ->suffix('px')
                            ->helperText('المقترح: 180px — مناسب لشاشات الهاتف'),

                        Select::make("home_banner_ads.{$key}.fit")
                            ->label('طريقة احتواء صورة الإعلان')
                            ->options([
                                'cover' => 'ملء مع الحفاظ على النسبة — Cover',
                                'contain' => 'إظهار الصورة كاملة — Contain',
                                'fill' => 'تمديد كامل حسب المقاس — Fill',
                            ])
                            ->default('cover')
                            ->native(false)
                            ->helperText('Cover يملأ الإطار وقد يقص أطراف الصورة، بينما Contain يحافظ على الصورة كاملة.'),

                        Select::make("home_banner_ads.{$key}.alignment")
                            ->label('محاذاة الإعلان')
                            ->options([
                                'center' => 'في المنتصف',
                                'start' => 'بداية الصفحة',
                                'end' => 'نهاية الصفحة',
                            ])
                            ->default('center')
                            ->native(false),
                    ])
                    ->columns(3)
                    ->columnSpanFull(),

                Section::make('معاينة الإعلان')
                    ->description('معاينة تقريبية لشكل الإعلان قبل الحفظ.')
                    ->schema([

                        Placeholder::make("home_banner_ads.{$key}.preview")
                            ->label('')
                            ->content(function ($get) use ($key) {

                                $image = $get("home_banner_ads.{$key}.image");

                                if (!$image) {
                                    return 'ارفع صورة الإعلان لعرض المعاينة.';
                                }

                                return new \Illuminate\Support\HtmlString('
                                    <div style="display:flex;gap:25px;flex-wrap:wrap;align-items:flex-start">

                                        <div>
                                            <strong>سطح المكتب</strong>
                                            <div style="
                                                width:300px;
                                                height:80px;
                                                overflow:hidden;
                                                border:1px solid #ccc;
                                                border-radius:12px;
                                                margin-top:10px;
                                            ">
                                                <img src="/storage/'.$image.'"
                                                     style="
                                                        width:100%;
                                                        height:100%;
                                                        object-fit:'.$get("home_banner_ads.{$key}.fit").';
                                                     ">
                                            </div>
                                            <small>
                                                '.$get("home_banner_ads.{$key}.desktop.width").' × '.
                                                $get("home_banner_ads.{$key}.desktop.height").'
                                            </small>
                                        </div>


                                        <div>
                                            <strong>الموبايل</strong>
                                            <div style="
                                                width:100px;
                                                height:150px;
                                                overflow:hidden;
                                                border:1px solid #ccc;
                                                border-radius:12px;
                                                margin-top:10px;
                                            ">
                                                <img src="/storage/'.$image.'"
                                                     style="
                                                        width:100%;
                                                        height:100%;
                                                        object-fit:'.$get("home_banner_ads.{$key}.fit").';
                                                     ">
                                            </div>
                                            <small>
                                                '.$get("home_banner_ads.{$key}.mobile.width").' × '.
                                                $get("home_banner_ads.{$key}.mobile.height").'
                                            </small>
                                        </div>

                                    </div>
                                ');
                            })

                    ])
                    ->columnSpanFull(),

                Textarea::make("home_banner_ads.{$key}.code")
                    ->label('كود HTML مخصص لهذا الموضع — اختياري')
                    ->rows(4)
                    ->placeholder('<a href="..."><img src="..." /></a>')
                    ->helperText('إذا تم إدخال كود HTML مخصص، سيُعرض بدل صورة الإعلان. كود الإعلان الخارجي يظل مسؤولًا عن أبعاده الداخلية.')
                    ->columnSpanFull(),
            ])
            ->columns(2);
    }
}