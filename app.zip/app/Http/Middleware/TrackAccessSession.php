<?php
namespace App\Http\Middleware;
use Closure; use Illuminate\Http\Request; use Illuminate\Support\Facades\DB; use Symfony\Component\HttpFoundation\Response;
class TrackAccessSession {
 public function handle(Request $request, Closure $next): Response {
   $response=$next($request);
   if($request->hasSession()){
      try {
        $sid=$request->session()->getId();
        $country=$request->header('CF-IPCountry') ?: ($request->header('X-Country') ?: null);
        $fingerprint=hash('sha256', ($request->userAgent()??'').'|'.$request->ip());
        DB::table(config('session.table','sessions'))->where('id',$sid)->update([
          'country'=>$country,'device_fingerprint'=>$fingerprint
        ]);
      } catch(\Throwable $e){}
   }
   return $response;
 }
}
