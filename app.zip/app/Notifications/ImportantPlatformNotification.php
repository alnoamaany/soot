<?php

namespace App\Notifications;

use App\Models\PlatformImportantNotification;
use App\Services\EmailTemplateService;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class ImportantPlatformNotification extends Notification
{
    use Queueable;

    public function __construct(public PlatformImportantNotification $record)
    {
    }

    public function via(object $notifiable): array
    {
        $channels = ['database'];
        $settings = app(\App\Settings\GeneralSettings::class);

        if (
            $settings->email_notify_important_notifications
            && filled($notifiable->email)
            && (EmailTemplateService::get('important_platform_notification')?->is_enabled ?? true)
        ) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toArray(object $notifiable): array
    {
        return [
            'important' => true,
            'title' => $this->record->title,
            'message' => $this->record->body,
            'url' => route('important-notifications.index'),
            'platform_notification_id' => $this->record->id,
        ];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $settings = app(\App\Settings\GeneralSettings::class);

        $variables = [
            'name' => $notifiable->name ?? '',
            'email' => $notifiable->email ?? '',
            'title' => $this->record->title,
            'message' => strip_tags($this->record->body),
            'url' => route('important-notifications.index'),
            'site_name' => $settings->site_name ?? 'منصة صوتنا',
        ];

        $template = EmailTemplateService::render(
            'important_platform_notification',
            $variables,
            [
                'subject' => '{title}',
                'greeting' => 'مرحباً {name}،',
                'body_html' => '{message}',
                'button_text' => 'عرض الإشعارات المهمة',
                'button_url' => '{url}',
                'footer' => 'هذه رسالة آلية من {site_name}.',
            ]
        );

        return (new MailMessage)
            ->subject($template['subject'] ?: $this->record->title)
            ->greeting($template['greeting'] ?: 'مرحباً ' . ($notifiable->name ?? ''))
            ->line($template['body_html'] ?: strip_tags($this->record->body))
            ->when(
                filled($template['button_text']) && filled($template['button_url']),
                fn ($mail) => $mail->action($template['button_text'], $template['button_url'])
            )
            ->line($template['footer'] ?: '');
    }
}
