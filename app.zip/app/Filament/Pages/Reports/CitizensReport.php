<?php

namespace App\Filament\Pages\Reports;

use App\Models\Governorate;
use App\Models\User;
use Filament\Pages\Page;
use Livewire\WithPagination;

class CitizensReport extends Page
{
    use WithPagination;

    protected string $view = 'filament.pages.reports.citizens-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-users';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 8;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير المواطنين والمستخدمين';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير قاعدة بيانات المواطنين والمستخدمين';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير المواطنين والمستخدمين';
    }

    public ?string $search = '';
    public ?string $governorate = 'all';
    public ?string $verificationStatus = 'all';
    public int $perPage = 25;

    public function updatingSearch(): void
    {
        $this->resetPage();
    }

    public function updatingGovernorate(): void
    {
        $this->resetPage();
    }

    public function updatingVerificationStatus(): void
    {
        $this->resetPage();
    }

    public function updatingPerPage(): void
    {
        $this->resetPage();
    }

    public function resetFilters(): void
    {
        $this->search = '';
        $this->governorate = 'all';
        $this->verificationStatus = 'all';
        $this->perPage = 25;
        $this->resetPage();
    }

    public function getViewData(): array
    {
        $baseQuery = User::where('role', 'citizen');

        if ($this->search) {
            $term = '%' . trim($this->search) . '%';
            $baseQuery->where(function ($q) use ($term) {
                $q->where('name', 'like', $term)
                    ->orWhere('email', 'like', $term)
                    ->orWhere('phone', 'like', $term)
                    ->orWhere('national_id', 'like', $term);
            });
        }

        if ($this->governorate && $this->governorate !== 'all') {
            $baseQuery->where(function ($q) {
                $q->where('city', $this->governorate)
                    ->orWhereHas('governorate', fn ($g) => $g->where('name_ar', $this->governorate));
            });
        }

        if ($this->verificationStatus === 'verified') {
            $baseQuery->whereNotNull('email_verified_at');
        } elseif ($this->verificationStatus === 'unverified') {
            $baseQuery->whereNull('email_verified_at');
        }

        // Database-level high performance aggregations
        $totalCitizens = (clone $baseQuery)->count();
        $verifiedCount = (clone $baseQuery)->whereNotNull('email_verified_at')->count();
        $withRequestsCount = (clone $baseQuery)->has('requests')->count();

        // Paginated results with only necessary lightweight relations
        $citizens = (clone $baseQuery)
            ->with(['governorate'])
            ->withCount('requests')
            ->latest('id')
            ->paginate($this->perPage);

        $governoratesList = Governorate::orderBy('name_ar')->get(['id', 'name_ar']);

        return [
            'citizens' => $citizens,
            'totalCitizens' => $totalCitizens,
            'verifiedCount' => $verifiedCount,
            'withRequestsCount' => $withRequestsCount,
            'governoratesList' => $governoratesList,
        ];
    }
}
