<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailTemplate extends Model
{
    protected $fillable = [
        'key',
        'name',
        'is_enabled',
        'subject',
        'greeting',
        'body_html',
        'button_text',
        'button_url',
        'footer',
    ];

    protected $casts = [
        'is_enabled' => 'boolean',
    ];
}
