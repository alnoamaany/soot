<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Translatable\HasTranslations;

class Library extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia, HasTranslations;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'library_category_id',
        'sort_order',
        'mp_id',
        'is_featured',
        'deleted_by_mp_id', 'deleted_by_mp_at', 'deleted_by_mp_reason',
        'title',
        'description',
        'video_url',
        'is_active',
        'published_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'is_active' => 'boolean',
        'published_at' => 'datetime',
        'is_featured' => 'boolean',
        'deleted_by_mp_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::creating(function ($library) {
            if ($library->sort_order === null || (int) $library->sort_order === 0) {
                $query = static::query();
                $library->sort_order = ((int) ($library->library_category_id === null
                    ? $query->whereNull('library_category_id')->max('sort_order')
                    : $query->where('library_category_id', $library->library_category_id)->max('sort_order'))) + 1;
            }
        });
    }

    public function mp(): BelongsTo
    {
        return $this->belongsTo(Mp::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(LibraryCategory::class, 'library_category_id');
    }

    /**
     * Register media collections.
     */
    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('thumbnail')
            ->singleFile();

        $this->addMediaCollection('video_file')
            ->singleFile();
    }
}
