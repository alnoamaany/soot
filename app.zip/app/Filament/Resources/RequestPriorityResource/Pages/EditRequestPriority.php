<?php
namespace App\Filament\Resources\RequestPriorityResource\Pages;
use App\Filament\Resources\RequestPriorityResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
class EditRequestPriority extends EditRecord { protected static string $resource = RequestPriorityResource::class; protected function getHeaderActions(): array { return [Actions\DeleteAction::make()->disabled(fn ($record): bool => $record->requests()->exists())]; } }
