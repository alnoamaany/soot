<?php

namespace App\Notifications;

use App\Services\EmailTemplateService;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewDeviceLoginNotification extends Notification
{
    public function __construct(
        protected string $accountName,
        protected string $ipAddress,
        protected ?string $country,
        protected string $userAgent,
        protected string $loginAt,
        protected bool $forAdmin = false,
    ) {
    }

    public function via(object $notifiable): array
    {
        $key = $this->forAdmin
            ? 'new_device_login_admin'
            : 'new_device_login_citizen';

        $channels = ['database'];

        if (
            filled($notifiable->routeNotificationFor('mail'))
            && (EmailTemplateService::get($key)?->is_enabled ?? true)
        ) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toArray(object $notifiable): array
    {
        if ($this->forAdmin) {
            return [
                'type' => 'security_new_device_login',
                'title' => 'تنبيه أمني: تسجيل دخول من جهاز جديد',
                'message' => "تم تسجيل دخول الحساب {$this->accountName} من جهاز غير معروف سابقًا.",
                'account_name' => $this->accountName,
                'ip_address' => $this->ipAddress,
                'country' => $this->country,
                'user_agent' => $this->userAgent,
                'login_at' => $this->loginAt,
            ];
        }

        return [
            'type' => 'security_new_device_login',
            'title' => 'تنبيه أمني: تسجيل دخول من جهاز جديد',
            'message' => 'تم تسجيل الدخول إلى حسابك من جهاز غير معروف سابقًا.',
            'ip_address' => $this->ipAddress,
            'country' => $this->country,
            'user_agent' => $this->userAgent,
            'login_at' => $this->loginAt,
        ];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $settings = app(\App\Settings\GeneralSettings::class);

        $key = $this->forAdmin
            ? 'new_device_login_admin'
            : 'new_device_login_citizen';

        $variables = [
            'name' => $notifiable->name ?? $this->accountName,
            'account_name' => $this->accountName,
            'email' => $notifiable->email ?? '',
            'ip_address' => $this->ipAddress,
            'country' => $this->country ?: 'غير متاح',
            'user_agent' => $this->userAgent,
            'login_at' => $this->loginAt,
            'site_name' => $settings->site_name ?? 'منصة صوتنا',
        ];

        $defaults = $this->forAdmin
            ? [
                'subject' => 'تنبيه أمني - تسجيل دخول من جهاز جديد',
                'greeting' => 'تنبيه أمني',
                'body_html' =>
                    'تم تسجيل دخول الحساب: {account_name}<br>' .
                    'تم اكتشاف جهاز غير معروف سابقًا لهذا الحساب.<br><br>' .
                    'عنوان IP: {ip_address}<br>' .
                    'الدولة: {country}<br>' .
                    'وقت الدخول: {login_at}<br>' .
                    'المتصفح والجهاز: {user_agent}',
                'button_text' => '',
                'button_url' => '',
                'footer' => 'هذه رسالة آلية من {site_name}.',
            ]
            : [
                'subject' => 'تنبيه أمني - تسجيل دخول من جهاز جديد',
                'greeting' => 'مرحبًا {name}',
                'body_html' =>
                    'تم تسجيل الدخول إلى حسابك من جهاز غير معروف سابقًا.<br><br>' .
                    'عنوان IP: {ip_address}<br>' .
                    'الدولة: {country}<br>' .
                    'وقت الدخول: {login_at}<br>' .
                    'المتصفح والجهاز: {user_agent}<br><br>' .
                    'إذا لم تكن أنت من قام بتسجيل الدخول، يرجى التواصل مع إدارة المنصة فورًا.',
                'button_text' => '',
                'button_url' => '',
                'footer' => 'هذه رسالة آلية من {site_name}.',
            ];

        $template = EmailTemplateService::render($key, $variables, $defaults);

        $mail = (new MailMessage)
            ->subject($template['subject'])
            ->greeting($template['greeting'])
            ->line($template['body_html']);

        if (filled($template['button_text']) && filled($template['button_url'])) {
            $mail->action($template['button_text'], $template['button_url']);
        }

        if (filled($template['footer'])) {
            $mail->line($template['footer']);
        }

        return $mail;
    }
}
