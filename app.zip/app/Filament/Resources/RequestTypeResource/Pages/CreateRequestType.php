<?php
namespace App\Filament\Resources\RequestTypeResource\Pages;
use App\Filament\Resources\RequestTypeResource;
use Filament\Resources\Pages\CreateRecord;
class CreateRequestType extends CreateRecord { protected static string $resource = RequestTypeResource::class; }
