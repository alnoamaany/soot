<?php
namespace App\Filament\Resources\MpRequestResource\Pages;
use App\Filament\Resources\MpRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
class ListMpRequests extends ListRecords { protected static string $resource = MpRequestResource::class; protected function getHeaderActions(): array { return [Actions\CreateAction::make()]; } }
