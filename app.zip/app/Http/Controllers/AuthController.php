<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Admin;
use App\Notifications\NewDeviceLoginNotification;
use App\Rules\EgyptianPhone;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        if ($request->has('phone')) {
            $request->merge(['phone' => EgyptianPhone::normalize($request->phone)]);
        }

        $credentials = $request->validate([
            'phone' => ['required', 'string', new EgyptianPhone()],
            'password' => ['required', 'string'],
            'cf-turnstile-response' => ['required', new \App\Rules\Turnstile()],
        ], [
            'phone.required' => 'رقم الهاتف مطلوب',
            'password.required' => 'كلمة المرور مطلوبة',
            'cf-turnstile-response.required' => 'يرجى تأكيد التحقق الأمني (الكابتشا).',
        ]);

        if (Auth::attempt(['phone' => $credentials['phone'], 'password' => $credentials['password']])) {
            $user = Auth::user();

            // 1. Check if user account is approved by admin (exempt admin role)
            if (! $user->is_approved && $user->role !== 'admin') {
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();

                return back()
                    ->with('error', 'حسابك ما زال قيد المراجعة والموافقة من قبل الإدارة، ولا يمكنك تسجيل الدخول حتى يتم اعتماد وتفعيل الحساب.')
                    ->withInput($request->only('phone'));
            }

            // 2. Check if user is MP and verify subscription expiration
            if ($user->role === 'mp' || $user->mp) {
                $mp = $user->mp;
                if ($mp && ! $mp->hasValidSubscription()) {
                    Auth::logout();
                    $request->session()->invalidate();
                    $request->session()->regenerateToken();

                    return back()->with('error', 'انتهت فترة اشتراكك البرلماني، يرجى تجديد الاشتراك للمتابعة والوصول إلى لوحة التحكم.')->withInput($request->only('phone'));
                }
            }

            /*
             * Security:
             * Detect whether this login comes from a device fingerprint
             * that was previously associated with this account.
             *
             * IP is intentionally NOT part of the fingerprint, so changing
             * the internet connection does not by itself trigger an alert.
             */
            $deviceFingerprint = $this->makeDeviceFingerprint($request);
            $currentIp = (string) $request->ip();
            $country = $request->header('CF-IPCountry')
                ?: $request->header('X-Country')
                ?: null;
            $userAgent = (string) ($request->userAgent() ?: 'غير معروف');

            $knownDevice = false;

            try {
                $knownDevice = DB::table(config('session.table', 'sessions'))
                    ->where('user_id', $user->id)
                    ->whereNotNull('device_fingerprint')
                    ->where('device_fingerprint', $deviceFingerprint)
                    ->exists();
            } catch (\Throwable) {
                // Security alert failure must never prevent a valid login.
            }

            $request->session()->regenerate();

            /*
             * Save the regenerated session immediately so its database row
             * exists before we attach device metadata.
             */
            try {
                $request->session()->save();

                DB::table(config('session.table', 'sessions'))
                    ->where('id', $request->session()->getId())
                    ->update([
                        'user_id' => $user->id,
                        'ip_address' => $currentIp,
                        'user_agent' => $userAgent,
                        'country' => $country,
                        'device_fingerprint' => $deviceFingerprint,
                    ]);
            } catch (\Throwable) {
                // Session metadata must never prevent a valid login.
            }

            // Keep only the newest N sessions for this account.
            try {
                $maxDevices = max(1, (int) (app(\App\Settings\GeneralSettings::class)->max_devices_per_user ?? 3));
                $currentSessionId = $request->session()->getId();

                $sessions = DB::table(config('session.table', 'sessions'))
                    ->where('user_id', $user->id)
                    ->orderByDesc('last_activity')
                    ->pluck('id');

                $sessionsToDelete = $sessions
                    ->skip($maxDevices)
                    ->filter(fn ($id) => $id !== $currentSessionId)
                    ->values();

                if ($sessionsToDelete->isNotEmpty()) {
                    DB::table(config('session.table', 'sessions'))
                        ->whereIn('id', $sessionsToDelete)
                        ->delete();
                }
            } catch (\Throwable) {
                // Device limiting must never prevent a valid login if the session store is unavailable.
            }

            /*
             * First device after installation is trusted automatically.
             * Only a different fingerprint from an already-known device
             * generates the security notifications.
             */
            if (! $knownDevice) {
                try {
                    $loginAt = now()->format('Y-m-d H:i:s');

                    $user->notify(new NewDeviceLoginNotification(
                        accountName: (string) $user->name,
                        ipAddress: $currentIp,
                        country: $country,
                        userAgent: $userAgent,
                        loginAt: $loginAt,
                        forAdmin: false,
                    ));

                    Admin::query()
                        ->where('is_active', true)
                        ->whereNotNull('email')
                        ->each(function (Admin $admin) use (
                            $user,
                            $currentIp,
                            $country,
                            $userAgent,
                            $loginAt
                        ): void {
                            $admin->notify(new NewDeviceLoginNotification(
                                accountName: (string) $user->name,
                                ipAddress: $currentIp,
                                country: $country,
                                userAgent: $userAgent,
                                loginAt: $loginAt,
                                forAdmin: true,
                            ));
                        });
                } catch (\Throwable) {
                    // Notification/email failure must never prevent a valid login.
                }
            }

            return redirect()->intended('/')->with('success', 'تم تسجيل الدخول بنجاح');
        }

        return back()->with('error', 'رقم الهاتف أو كلمة المرور غير صحيحة')->withInput($request->only('phone'));
    }

    /**
     * Generate a stable browser/device fingerprint.
     *
     * The IP address is intentionally excluded.
     */
    private function makeDeviceFingerprint(Request $request): string
    {
        return hash('sha256', implode('|', [
            (string) ($request->userAgent() ?: ''),
            (string) ($request->header('Accept-Language') ?: ''),
            (string) ($request->header('Sec-CH-UA') ?: ''),
            (string) ($request->header('Sec-CH-UA-Platform') ?: ''),
            (string) ($request->header('Sec-CH-UA-Mobile') ?: ''),
        ]));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/')->with('success', 'تم تسجيل الخروج بنجاح');
    }

    public function showForgotPassword()
    {
        session()->forget('forgot_captcha_sum');

        // Kept only for backward compatibility with cached versions of the old math CAPTCHA view.
        return view('pages.forgot_password', ['num1' => 0, 'num2' => 0]);
    }

    public function handleForgotPassword(Request $request)
    {
        if ($request->has('phone')) {
            $request->merge(['phone' => EgyptianPhone::normalize($request->phone)]);
        }

        $request->validate([
            'phone' => ['required', 'string', new EgyptianPhone(), 'exists:users,phone'],
            'email' => ['required', 'string', 'email', 'max:255', 'exists:users,email'],
            'password' => 'required|string|min:8|confirmed',
            'cf-turnstile-response' => ['required', new \App\Rules\Turnstile()],
        ], [
            'phone.required' => 'رقم الهاتف مطلوب.',
            'phone.exists' => 'رقم الهاتف المدخل غير مسجل لدينا.',
            'email.required' => 'البريد الإلكتروني مطلوب.',
            'email.email' => 'البريد الإلكتروني غير صحيح.',
            'email.exists' => 'البريد الإلكتروني المدخل غير مسجل لدينا.',
            'password.required' => 'كلمة المرور الجديدة مطلوبة.',
            'password.min' => 'كلمة المرور يجب أن لا تقل عن 8 أحرف.',
            'password.confirmed' => 'تأكيد كلمة المرور غير متطابق.',
            'cf-turnstile-response.required' => 'يرجى تأكيد التحقق الأمني (الكابتشا).',
        ]);

        $user = User::where('phone', $request->phone)
            ->where('email', $request->email)
            ->first();

        if (! $user) {
            return back()->with('error', 'بيانات رقم الهاتف والبريد الإلكتروني غير متطابقة مع أي حساب مسجل لدينا.')->withInput();
        }

        $user->update([
            'password' => Hash::make($request->password),
        ]);

        return redirect()->route('login')->with('success', 'تم إعادة تعيين كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة.');
    }
}
