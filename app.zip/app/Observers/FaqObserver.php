<?php
namespace App\Observers;

use App\Models\Faq;
use App\Services\AdminAlertService;

class FaqObserver
{
    public function created(Faq $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');
        AdminAlertService::notify(
            'faq_created',
            'إضافة سؤال شائع جديد',
            str_replace(['{title}'], [$title], 'تمت إضافة سؤال شائع جديد: "{title}".'),
            $model,
            meta: ['faq_id' => $model->id],
        );
    }
}
