<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Mp;

class MpFollowerController extends Controller
{
    /** Toggle following an MP for the authenticated user. */
    public function toggle(Request $request, $id)
    {
        $user = Auth::user();
        if (! $user) {
            return redirect()->route('login')->with('error', 'الرجاء تسجيل الدخول أولاً.');
        }

        $mp = Mp::findOrFail($id);

        $isFollowing = $user->followingMps()->where('mp_id', $mp->id)->exists();

        if ($isFollowing) {
            $user->followingMps()->detach($mp->id);
            $message = 'تم إلغاء المتابعة.';
        } else {
            $user->followingMps()->attach($mp->id);
            $message = 'تم متابعة النائب.';
        }

        if ($request->wantsJson()) {
            return response()->json(['following' => ! $isFollowing, 'followers_count' => $mp->followers()->count()]);
        }

        return redirect()->back()->with('success', $message);
    }
}
