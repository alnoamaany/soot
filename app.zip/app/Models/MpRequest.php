<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

#[Fillable(['user_id', 'mp_id', 'reference_number', 'type', 'request_type_id', 'request_status_id', 'request_priority_id', 'recipient_sector', 'recipient_name', 'title', 'content', 'notes', 'status', 'citizen_can_reply'])]
class MpRequest extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    /**
     * Get the citizen who created the request.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the MP to whom the request is directed.
     */
    public function mp()
    {
        return $this->belongsTo(Mp::class);
    }

    public function requestStatus()
    {
        return $this->belongsTo(RequestStatus::class);
    }

    public function requestType()
    {
        return $this->belongsTo(RequestType::class);
    }

    public function requestPriority()
    {
        return $this->belongsTo(RequestPriority::class);
    }

    /**
     * Get the replies for the request.
     */
    public function replies()
    {
        return $this->hasMany(RequestReply::class);
    }

    /**
     * Automatically generate reference number.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->reference_number)) {
                do {
                    $reference = '#REQ-' . date('Y') . '-' . str_pad(random_int(1, 999999), 6, '0', STR_PAD_LEFT);
                } while (static::where('reference_number', $reference)->exists());

                $model->reference_number = $reference;
            }

            if (empty($model->request_type_id)) {
                $model->request_type_id = RequestType::where('is_active', true)->orderBy('sort_order')->value('id');
            }
            if (empty($model->request_status_id)) {
                $model->request_status_id = RequestStatus::where('is_active', true)->orderBy('sort_order')->value('id');
            }
            if (empty($model->request_priority_id)) {
                $model->request_priority_id = RequestPriority::where('is_active', true)->orderBy('sort_order')->value('id');
            }

            if (empty($model->type) && $model->request_type_id) {
                $model->type = RequestType::find($model->request_type_id)?->name ?? 'عام';
            }
        });
    }
}
