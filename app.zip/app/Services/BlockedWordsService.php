<?php

namespace App\Services;

use App\Settings\GeneralSettings;

class BlockedWordsService
{
    public function words(): array
    {
        $raw = (string) (app(GeneralSettings::class)->blocked_words ?? '');
        return collect(preg_split('/[\r\n,]+/u', $raw) ?: [])
            ->map(fn ($word) => trim($word))
            ->filter()
            ->unique(fn ($word) => mb_strtolower($word))
            ->values()
            ->all();
    }

    public function contains(?string $text): ?string
    {
        $normalized = mb_strtolower(strip_tags((string) $text));
        foreach ($this->words() as $word) {
            if ($word !== '' && mb_stripos($normalized, mb_strtolower($word)) !== false) {
                return $word;
            }
        }
        return null;
    }
}
