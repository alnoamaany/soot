<?php

namespace App\Filament\Pages\Reports;

use App\Models\Governorate;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\RequestPriority;
use App\Models\RequestStatus;
use App\Models\RequestType;
use Filament\Pages\Page;
use Livewire\WithPagination;

class RequestsReport extends Page
{
    use WithPagination;

    protected string $view = 'filament.pages.reports.requests-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-document-chart-bar';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 2;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير الطلبات والشكاوى';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير الطلبات والشكاوى البرلمانية المفصل';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير الطلبات والشكاوى';
    }

    public ?string $search = '';
    public ?string $dateFrom = null;
    public ?string $dateTo = null;
    public ?string $mpId = 'all';
    public ?string $statusId = 'all';
    public ?string $typeId = 'all';
    public ?string $priorityId = 'all';
    public ?string $governorate = 'all';
    public int $perPage = 25;

    public function mount(): void
    {
        $this->dateFrom = now()->subMonths(6)->format('Y-m-d');
        $this->dateTo = now()->format('Y-m-d');
    }

    public function updatingSearch(): void { $this->resetPage(); }
    public function updatingDateFrom(): void { $this->resetPage(); }
    public function updatingDateTo(): void { $this->resetPage(); }
    public function updatingMpId(): void { $this->resetPage(); }
    public function updatingStatusId(): void { $this->resetPage(); }
    public function updatingTypeId(): void { $this->resetPage(); }
    public function updatingPriorityId(): void { $this->resetPage(); }
    public function updatingGovernorate(): void { $this->resetPage(); }
    public function updatingPerPage(): void { $this->resetPage(); }

    public function resetFilters(): void
    {
        $this->search = '';
        $this->dateFrom = now()->subMonths(6)->format('Y-m-d');
        $this->dateTo = now()->format('Y-m-d');
        $this->mpId = 'all';
        $this->statusId = 'all';
        $this->typeId = 'all';
        $this->priorityId = 'all';
        $this->governorate = 'all';
        $this->perPage = 25;
        $this->resetPage();
    }

    public function getViewData(): array
    {
        $baseQuery = MpRequest::query();

        if ($this->search) {
            $term = '%' . trim($this->search) . '%';
            $baseQuery->where(function ($q) use ($term) {
                $q->where('mp_requests.title', 'like', $term)
                    ->orWhere('mp_requests.tracking_code', 'like', $term)
                    ->orWhereHas('user', fn ($u) => $u->where('name', 'like', $term)->orWhere('phone', 'like', $term)->orWhere('national_id', 'like', $term))
                    ->orWhereHas('mp', fn ($m) => $m->where('name', 'like', $term)->orWhere('display_name', 'like', $term));
            });
        }

        if ($this->dateFrom) {
            $baseQuery->whereDate('mp_requests.created_at', '>=', $this->dateFrom);
        }
        if ($this->dateTo) {
            $baseQuery->whereDate('mp_requests.created_at', '<=', $this->dateTo);
        }
        if ($this->mpId && $this->mpId !== 'all') {
            $baseQuery->where('mp_requests.mp_id', $this->mpId);
        }
        if ($this->statusId && $this->statusId !== 'all') {
            $baseQuery->where('mp_requests.request_status_id', $this->statusId);
        }
        if ($this->typeId && $this->typeId !== 'all') {
            $baseQuery->where('mp_requests.request_type_id', $this->typeId);
        }
        if ($this->priorityId && $this->priorityId !== 'all') {
            $baseQuery->where('mp_requests.request_priority_id', $this->priorityId);
        }
        if ($this->governorate && $this->governorate !== 'all') {
            $baseQuery->whereHas('user', function ($q) {
                $q->where('city', $this->governorate)
                    ->orWhereHas('governorate', fn ($g) => $g->where('name_ar', $this->governorate));
            });
        }

        // Database aggregations without loading records into memory
        $totalCount = (clone $baseQuery)->count();

        $completedCount = (clone $baseQuery)->where(function ($q) {
            $q->where('status', 'completed')
                ->orWhereHas('requestStatus', fn ($s) => $s->where('name', 'like', '%مكتمل%'));
        })->count();

        $inProgressCount = (clone $baseQuery)->where(function ($q) {
            $q->whereIn('status', ['in_progress', 'approved', 'received', 'final_review'])
                ->orWhereHas('requestStatus', fn ($s) => $s->where('name', 'not like', '%مكتمل%'));
        })->count();

        $urgentCount = (clone $baseQuery)->whereHas('requestPriority', function ($q) {
            $q->where('name', 'like', '%عاجل%');
        })->count();

        // Database-level groupings for maximum speed & scale
        $byType = (clone $baseQuery)
            ->join('request_types', 'mp_requests.request_type_id', '=', 'request_types.id')
            ->selectRaw('request_types.name as type_name, count(*) as count')
            ->groupBy('request_types.name')
            ->orderByDesc('count')
            ->pluck('count', 'type_name');

        $bySector = (clone $baseQuery)
            ->selectRaw('COALESCE(NULLIF(recipient_sector, ""), "غير محدد") as sector_name, count(*) as count')
            ->groupBy('sector_name')
            ->orderByDesc('count')
            ->pluck('count', 'sector_name');

        // Paginated table data
        $requests = (clone $baseQuery)
            ->with(['user', 'mp', 'requestStatus', 'requestType', 'requestPriority'])
            ->latest('id')
            ->paginate($this->perPage);

        return [
            'requests' => $requests,
            'totalCount' => $totalCount,
            'completedCount' => $completedCount,
            'inProgressCount' => $inProgressCount,
            'urgentCount' => $urgentCount,
            'byType' => $byType,
            'bySector' => $bySector,
            'mpsList' => Mp::with('user:id,name')->select('id', 'user_id', 'title')->get(),
            'statusesList' => RequestStatus::select('id', 'name')->get(),
            'typesList' => RequestType::select('id', 'name')->get(),
            'prioritiesList' => RequestPriority::select('id', 'name')->get(),
            'governoratesList' => Governorate::orderBy('name_ar')->get(['id', 'name_ar']),
        ];
    }
}
