<?php

namespace App\Notifications;

use App\Models\MpSubscription;
use App\Services\EmailTemplateService;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class SubscriptionExpiresSoon extends Notification
{
    use Queueable;

    public function __construct(public MpSubscription $subscription)
    {
    }

    public function via(object $notifiable): array
    {
        $channels = ['database'];

        if (
            filled($notifiable->email)
            && (EmailTemplateService::get('subscription_expiring')?->is_enabled ?? true)
        ) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toMail(object $notifiable): MailMessage
    {
        $date = $this->subscription->ends_at->translatedFormat('d F Y');
        $settings = app(\App\Settings\GeneralSettings::class);

        $variables = [
            'name' => $notifiable->name ?? '',
            'email' => $notifiable->email ?? '',
            'date' => $date,
            'ends_at' => $this->subscription->ends_at->toDateString(),
            'site_name' => $settings->site_name ?? 'منصة صوتنا',
        ];

        $template = EmailTemplateService::render(
            'subscription_expiring',
            $variables,
            [
                'subject' => 'تنبيه قرب انتهاء الاشتراك',
                'greeting' => 'مرحبًا {name}',
                'body_html' =>
                    'سينتهي اشتراكك في {date}.<br><br>' .
                    'يرجى التواصل مع الإدارة لتجديد الاشتراك قبل انتهائه.',
                'button_text' => '',
                'button_url' => '',
                'footer' => 'هذه رسالة آلية من {site_name}.',
            ]
        );

        $mail = (new MailMessage)
            ->subject($template['subject'])
            ->greeting($template['greeting'])
            ->line($template['body_html']);

        if (filled($template['button_text']) && filled($template['button_url'])) {
            $mail->action($template['button_text'], $template['button_url']);
        }

        if (filled($template['footer'])) {
            $mail->line($template['footer']);
        }

        return $mail;
    }

    public function toArray(object $notifiable): array
    {
        return [
            'title' => 'تنبيه قرب انتهاء الاشتراك',
            'message' => 'سينتهي اشتراكك بتاريخ ' . $this->subscription->ends_at->format('Y-m-d') . '.',
            'subscription_id' => $this->subscription->id,
            'ends_at' => $this->subscription->ends_at->toDateString(),
        ];
    }
}
