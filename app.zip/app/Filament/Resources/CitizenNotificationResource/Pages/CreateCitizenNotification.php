<?php
namespace App\Filament\Resources\CitizenNotificationResource\Pages;
use App\Filament\Resources\CitizenNotificationResource;
use App\Notifications\ImportantCitizenNotification;
use App\Notifications\PlatformMessageNotification;
use Filament\Resources\Pages\CreateRecord;
class CreateCitizenNotification extends CreateRecord{
 protected static string $resource=CitizenNotificationResource::class;
 protected function mutateFormDataBeforeCreate(array $data):array{$data['created_by']=auth('admin')->id();$data['sent_at']=now();return $data;}
 protected function afterCreate():void{$u=$this->record->user;if(!$u)return;$url=$this->record->url?:route('important-notifications.index');$notification=$this->record->is_important?new ImportantCitizenNotification($this->record->title,$this->record->message,$url):new PlatformMessageNotification($this->record->title,$this->record->message,$url);$u->notify($notification);}
}
