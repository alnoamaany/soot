<?php

namespace App\Console\Commands;

use App\Models\MpSubscription;
use App\Notifications\SubscriptionExpiresSoon;
use Illuminate\Console\Command;

class SendSubscriptionExpiryReminders extends Command
{
    protected $signature = 'subscriptions:send-expiry-reminders';
    protected $description = 'Send email and in-site notifications seven days before subscriptions expire';

    public function handle(): int
    {
        MpSubscription::query()
            ->with('mp.user')
            ->where('status', 'active')
            ->whereNull('reminder_sent_at')
            ->whereBetween('ends_at', [today(), today()->copy()->addDays(7)])
            ->each(function (MpSubscription $subscription): void {
                $user = $subscription->mp?->user;

                if (! $user) {
                    return;
                }

                $user->notify(new SubscriptionExpiresSoon($subscription));
                $subscription->updateQuietly(['reminder_sent_at' => now()]);
            });

        MpSubscription::query()
            ->where('status', 'active')
            ->whereDate('ends_at', '<', today())
            ->update(['status' => 'expired']);

        return self::SUCCESS;
    }
}
