<?php

namespace App\Filament\Widgets;

// This widget was replaced by AdminStatsOverview.
// Making it abstract so Filament does not auto-discover it.
abstract class AdminStatsWidget
{
}
