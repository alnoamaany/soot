<?php

namespace App\Helper\Traits\Filamentv4;

trait FilamentCountBadgeResource
{
    // For Resources
    public static function getNavigationBadge(): ?string
    {
        return number_format(self::getEloquentQuery()->count());
    }

    // For Resources
    public static function getNavigationBadgeColor(): string|array|null
    {
        return self::getEloquentQuery()->exists() ? 'primary' : 'danger';
    }
}
