<?php

namespace App\Notifications;

use App\Models\MpRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class RequestActivityNotification extends Notification
{
    use Queueable;

    public function __construct(
        public MpRequest $request,
        public string $title,
        public string $message,
        public string $url,
        public string $event,
    ) {
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'title' => $this->title,
            'message' => $this->message,
            'url' => $this->url,
            'event' => $this->event,
            'request_id' => $this->request->id,
            'reference_number' => $this->request->reference_number,
        ];
    }
}
