<?php

namespace App\Filament\Pages\Reports;

use App\Models\Area;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\User;
use Filament\Pages\Page;

class GeographicDistributionReport extends Page
{
    protected string $view = 'filament.pages.reports.geographic-distribution-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-map-pin';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 5;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير التوزيع الجغرافي والمناطق';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير التوزيع الجغرافي للمحافظات والمراكز والأحياء';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير التوزيع الجغرافي';
    }

    public ?string $selectedGovernorateId = 'all';

    public function resetFilters(): void
    {
        $this->selectedGovernorateId = 'all';
    }

    public function getViewData(): array
    {
        $govQuery = Governorate::query()->withCount(['users', 'areas', 'markazes']);

        if ($this->selectedGovernorateId && $this->selectedGovernorateId !== 'all') {
            $govQuery->where('id', $this->selectedGovernorateId);
            $govQuery->with(['markazes.areas']);
        }

        $governorates = $govQuery->orderBy('name_ar')->get();

        $totalGovernorates = Governorate::count();
        $totalMarkazes = Markaz::count();
        $totalAreas = Area::count();
        $totalCitizens = User::where('role', 'citizen')->count();

        // Efficient single-query group-by aggregation across all governorates (0 N+1 overhead)
        $requestsByGov = MpRequest::join('users', 'mp_requests.user_id', '=', 'users.id')
            ->selectRaw('users.governorate_id, count(*) as count')
            ->whereNotNull('users.governorate_id')
            ->groupBy('users.governorate_id')
            ->pluck('count', 'governorate_id');

        $mpsByGov = Mp::join('users', 'mps.user_id', '=', 'users.id')
            ->selectRaw('users.governorate_id, count(*) as count')
            ->whereNotNull('users.governorate_id')
            ->groupBy('users.governorate_id')
            ->pluck('count', 'governorate_id');

        $governoratesData = $governorates->map(function ($gov) use ($requestsByGov, $mpsByGov) {
            return [
                'id' => $gov->id,
                'name' => $gov->name_ar,
                'users_count' => $gov->users_count,
                'areas_count' => $gov->areas_count,
                'markazes_count' => $gov->markazes_count ?? $gov->markazes?->count() ?? 0,
                'mps_count' => $mpsByGov->get($gov->id, 0),
                'requests_count' => $requestsByGov->get($gov->id, 0),
                'markazes' => $gov->relationLoaded('markazes') ? $gov->markazes : collect(),
            ];
        });

        return [
            'governoratesData' => $governoratesData,
            'totalGovernorates' => $totalGovernorates,
            'totalMarkazes' => $totalMarkazes,
            'totalAreas' => $totalAreas,
            'totalCitizens' => $totalCitizens,
            'allGovernorates' => Governorate::orderBy('name_ar')->get(['id', 'name_ar']),
        ];
    }
}
