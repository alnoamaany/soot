<?php
namespace App\Filament\Resources;
use App\Filament\Resources\CitizenNotificationResource\Pages;
use App\Models\CitizenNotification;use App\Models\User;use App\Notifications\PlatformMessageNotification;
use Filament\Resources\Resource;use Filament\Schemas\Schema;use Filament\Schemas\Components\Section;use Filament\Forms\Components\Select;use Filament\Forms\Components\TextInput;use Filament\Forms\Components\Textarea;use Filament\Forms\Components\Toggle;use Filament\Tables\Table;use Filament\Tables\Columns\TextColumn;use Filament\Tables\Columns\IconColumn;use Filament\Actions;use Filament\Infolists\Components\TextEntry;
class CitizenNotificationResource extends Resource{
 protected static ?string $model=CitizenNotification::class;protected static string|\BackedEnum|null $navigationIcon='heroicon-o-bell-alert';
 public static function getNavigationGroup():?string{return 'الدعم والاتصالات';}public static function getModelLabel():string{return 'إشعار لمواطن';}public static function getPluralModelLabel():string{return 'إرسال إشعار لمواطن';}
 public static function form(Schema $schema):Schema{return $schema->components([Section::make('بيانات الإشعار')->schema([
  Select::make('user_id')->label('المواطن')->options(fn()=>User::where(function($q){$q->where('role','citizen')->orWhereNull('role');})->orderBy('name')->pluck('name','id'))->searchable()->required(),
  TextInput::make('title')->label('عنوان الإشعار')->required()->maxLength(255),Textarea::make('message')->label('نص الإشعار')->required()->rows(7)->maxLength(5000)->columnSpanFull(),TextInput::make('url')->label('رابط عند الضغط (اختياري)')->maxLength(1000),Toggle::make('is_important')->label('يظهر داخل لوحة الإشعارات المهمة')->default(true)
  ])->columns(2)]);}
 public static function table(Table $table):Table{return $table->columns([TextColumn::make('user.name')->label('المواطن')->searchable(),TextColumn::make('title')->label('العنوان')->searchable(),IconColumn::make('is_important')->label('مهم')->boolean(),TextColumn::make('sent_at')->label('تاريخ الإرسال')->dateTime()->sortable()])->recordActions([Actions\ViewAction::make(),Actions\DeleteAction::make()]);}
 public static function infolist(Schema $schema):Schema{return $schema->components([Section::make('تفاصيل الإشعار')->schema([TextEntry::make('user.name')->label('المواطن'),TextEntry::make('title')->label('العنوان'),TextEntry::make('message')->label('النص')->columnSpanFull(),TextEntry::make('sent_at')->label('تاريخ الإرسال')->dateTime()])]);}
 public static function getPages():array{return ['index'=>Pages\ListCitizenNotifications::route('/'),'create'=>Pages\CreateCitizenNotification::route('/create'),'view'=>Pages\ViewCitizenNotification::route('/{record}')];}
}
