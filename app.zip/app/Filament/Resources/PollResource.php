<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PollResource\Pages;
use App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
use App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
use App\Models\Poll;
use Filament\Actions;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

use Filament\Infolists;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\RepeatableEntry;
use Filament\Infolists\Infolist;

class PollResource extends Resource
{
    use FilamentTranslatedLabelResource;
    use FilamentCountBadgeResource;

    protected static ?string $model = Poll::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-presentation-chart-bar';

    protected static ?int $navigationSort = 1;

    public static function getModelLabel(): string
    {
        return 'استطلاع';
    }

    public static function getPluralModelLabel(): string
    {
        return 'الاستطلاعات';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'الاستطلاعات والتفاعلات';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([


                            Section::make(__('General Information'))
                                ->schema([
                                    TextInput::make('title')
                                        ->translateLabel()
                                        ->required()
                                        ->maxLength(255)
                                        ->placeholder(__('Enter poll title')),

                                    Textarea::make('description')
                                        ->translateLabel()
                                        ->rows(3)
                                        ->placeholder(__('Enter poll description')),
                                ])->columnSpanFull(),


                            Section::make(__('Poll Options'))
                            ->columnSpanFull()
                                ->schema([
                                    Repeater::make('options')
                                        ->relationship('options')
                                        ->schema([
                                            TextInput::make('label')
                                                ->translateLabel()
                                                ->required()
                                                ->placeholder(__('Enter option text')),

                                            TextInput::make('votes_count')
                                                ->translateLabel()
                                                ->numeric()
                                                ->default(0)
                                                ->disabled()
                                                ->dehydrated(false)
                                                ->hint(__('Read-only')),
                                        ])
                                        ->columns(2)
                                        ->minItems(2)
                                        ->addActionLabel(__('Add Option'))
                                        ->reorderable(true)
                                        ->itemLabel(fn (array $state): ?string => $state['label'] ?? null),
                                ]),

                            Section::make(__('Settings'))
                                ->schema([
                                    Select::make('mp_id')
                                        ->relationship('mp.user', 'name')
                                        ->label('النائب صاحب الاستطلاع')
                                        ->placeholder('عام (للمنصة العامة)')
                                        ->searchable()
                                        ->preload()
                                        ->nullable(),

                                    Select::make('type')
                                        ->label('نوع الاستطلاع')
                                        ->options([
                                            'regular' => 'استطلاع عادي',
                                            'featured' => 'استطلاع مميز',
                                        ])
                                        ->default('regular')
                                        ->required(),

                                    Toggle::make('is_active')
                                        ->translateLabel()
                                        ->default(true)
                                        ->helperText(__('Toggle poll visibility')),

                                    DateTimePicker::make('starts_at')
                                        ->translateLabel()
                                        ->placeholder(__('Selection start date')),

                                    DateTimePicker::make('ends_at')
                                        ->translateLabel()
                                        ->placeholder(__('Selection end date')),
                                ]),

            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('title')
                    ->translateLabel()
                    ->searchable()
                    ->sortable(),

                TextColumn::make('type')
                    ->label('النوع')
                    ->badge()
                    ->color(fn (?string $state): string => match ($state) {
                        'featured' => 'warning',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn (?string $state): string => match ($state) {
                        'featured' => 'استطلاع مميز',
                        default => 'عادي',
                    })
                    ->sortable(),

                IconColumn::make('is_active')
                    ->translateLabel()
                    ->boolean()
                    ->sortable(),

                TextColumn::make('options_count')
                    ->translateLabel()
                    ->counts('options')
                    ->badge()
                    ->color('info'),

                TextColumn::make('votes_count')
                    ->translateLabel()
                    ->counts('votes')
                    ->badge()
                    ->color('success'),

                TextColumn::make('starts_at')
                    ->translateLabel()
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('ends_at')
                    ->translateLabel()
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('created_at')
                    ->translateLabel()
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                TernaryFilter::make('is_active')
                    ->label(__('Active Status'))
                    ->placeholder(__('All'))
                    ->trueLabel(__('Active Only'))
                    ->falseLabel(__('Inactive Only')),
            ])
            ->recordActions([
               Actions\ViewAction::make(),
               Actions\EditAction::make(),
               Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
               Actions\BulkActionGroup::make([
                   Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make(__('Basic Information'))
                    ->icon('heroicon-o-information-circle')
                    ->columns(3)
                    ->schema([
                        TextEntry::make('title')
                            ->translateLabel()
                            ->icon('heroicon-o-presentation-chart-bar')
                            ->columnSpanFull(),
                        TextEntry::make('options_count')
                            ->translateLabel()
                            ->badge()
                            ->color('info'),
                        TextEntry::make('votes_count')
                            ->translateLabel()
                            ->badge()
                            ->color('success'),
                    ]),

                Section::make(__('Details'))
                    ->icon('heroicon-o-document-text')
                    ->columns(1)
                    ->schema([
                        TextEntry::make('description')
                            ->translateLabel()
                            ->html()
                            ->columnSpanFull(),
                    ]),

                Section::make(__('Relations'))
                    ->icon('heroicon-o-link')
                    ->schema([
                        RepeatableEntry::make('options')
                            ->translateLabel()
                            ->schema([
                                TextEntry::make('label')
                                    ->translateLabel(),
                                TextEntry::make('votes_count')
                                    ->translateLabel()
                                    ->badge(),
                            ])
                            ->columns(2),
                    ]),

                Section::make(__('Status & Settings'))
                    ->icon('heroicon-o-cog-6-tooth')
                    ->columns(3)
                    ->schema([
                        IconEntry::make('is_active')
                            ->translateLabel()
                            ->boolean(),
                        TextEntry::make('starts_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                        TextEntry::make('ends_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                    ]),

                Section::make(__('Timestamps'))
                    ->icon('heroicon-o-clock')
                    ->columns(2)
                    ->collapsed()
                    ->schema([
                        TextEntry::make('created_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                        TextEntry::make('updated_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-arrow-path'),
                    ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPolls::route('/'),
            'create' => Pages\CreatePoll::route('/create'),
            'edit' => Pages\EditPoll::route('/{record}/edit'),
            'view' => Pages\ViewPoll::route('/{record}'),
        ];
    }
}
