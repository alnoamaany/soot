<?php

namespace App\Filament\Widgets;

use App\Models\User;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Facades\DB;

class UsersGovernorateChart extends ChartWidget
{
    protected ?string $heading = 'توزيع المستخدمين حسب المحافظة';
    
    protected static ?int $sort = 3;
    
    protected int | string | array $columnSpan = [
        'md' => 1,
        'xl' => 1,
    ];

    protected function getData(): array
    {
        $rows = User::select('governorate_id', DB::raw('count(*) as total'))
            ->groupBy('governorate_id')
            ->with('governorate')
            ->get();

        $labels = [];
        $values = [];

        foreach ($rows as $row) {
            $labels[] = $row->governorate?->name_ar ?? $row->city ?? 'غير محدد';
            $values[] = (int) $row->total;
        }

        return [
            'datasets' => [
                [
                    'label' => 'عدد المستخدمين',
                    'data' => $values,
                    'backgroundColor' => '#3B82F6',
                ],
            ],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }
}
