<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PendingCitizenResource\Pages;
use App\Models\User;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Area;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Actions\Action;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Components\Section;
use Filament\Notifications\Notification;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;

class PendingCitizenResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;

    protected static ?string $model = User::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-user-plus';
    protected static ?int $navigationSort = 2;

    public static function getModelLabel(): string
    {
        return 'مواطن بانتظار الموافقة';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المواطنون بانتظار الموافقة';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة المستخدمين والأعضاء';
    }

    public static function getNavigationBadge(): ?string
    {
        $count = static::getEloquentQuery()->count();
        return $count > 0 ? (string) $count : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'warning';
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('is_approved', false)
            ->where(function ($query) {
                $query->where('role', '!=', 'mp')
                    ->orWhereNull('role');
            })
            ->whereDoesntHave('mp');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات المواطن والحساب')
                ->schema([
                    SpatieMediaLibraryFileUpload::make('avatar')
                        ->collection('avatar')
                        ->label('الصورة الشخصية')
                        ->image()
                        ->avatar()
                        ->columnSpanFull(),
                    TextInput::make('name')
                        ->label('الاسم الكامل')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('phone')
                        ->label('رقم الهاتف')
                        ->required()
                        ->unique(table: 'users', column: 'phone', ignorable: fn (?User $record) => $record)
                        ->rules([new \App\Rules\EgyptianPhone()])
                        ->maxLength(64),
                    TextInput::make('password')
                        ->label('كلمة المرور')
                        ->password()
                        ->revealable()
                        ->required(fn (string $operation): bool => $operation === 'create')
                        ->dehydrated(fn (?string $state): bool => filled($state))
                        ->dehydrateStateUsing(fn (string $state): string => \Illuminate\Support\Facades\Hash::make($state))
                        ->minLength(8)
                        ->helperText(fn (string $operation): ?string => $operation === 'edit' ? 'اتركها فارغة للإبقاء على كلمة المرور الحالية' : null),
                    TextInput::make('national_id')
                        ->label('الرقم القومي (اختياري)')
                        ->unique(table: 'users', column: 'national_id', ignorable: fn (?User $record) => $record)
                        ->nullable()
                        ->length(14),
                    TextInput::make('email')
                        ->label('البريد الإلكتروني')
                        ->email()
                        ->unique(table: 'users', column: 'email', ignorable: fn (?User $record) => $record)
                        ->nullable()
                        ->maxLength(255),
                    Select::make('governorate_id')
                        ->label('المحافظة')
                        ->options(fn () => Governorate::orderBy('name_ar')->pluck('name_ar', 'id'))
                        ->searchable()
                        ->preload()
                        ->reactive()
                        ->afterStateUpdated(function (callable $set): void {
                            $set('markaz_id', null);
                            $set('area_id', null);
                        }),
                    Select::make('markaz_id')
                        ->label('المركز / القسم')
                        ->options(fn (callable $get) => filled($get('governorate_id'))
                            ? Markaz::where('governorate_id', $get('governorate_id'))->orderBy('name_ar')->pluck('name_ar', 'id')
                            : [])
                        ->searchable()
                        ->preload()
                        ->disabled(fn (callable $get): bool => blank($get('governorate_id')))
                        ->reactive()
                        ->afterStateUpdated(fn (callable $set) => $set('area_id', null)),
                    Select::make('area_id')
                        ->label('المنطقة / الحي')
                        ->options(fn (callable $get) => filled($get('markaz_id'))
                            ? Area::where('markaz_id', $get('markaz_id'))->orderBy('name_ar')->pluck('name_ar', 'id')
                            : [])
                        ->searchable()
                        ->preload()
                        ->disabled(fn (callable $get): bool => blank($get('markaz_id'))),
                    Textarea::make('detailed_address')
                        ->label('العنوان التفصيلي')
                        ->rows(3)
                        ->maxLength(1000)
                        ->columnSpanFull(),
                    Toggle::make('is_approved')
                        ->label('حساب مُفعّل ومعتمد')
                        ->default(false)
                        ->columnSpanFull(),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            SpatieMediaLibraryImageColumn::make('avatar')->collection('avatar')->label('الصورة'),
            TextColumn::make('name')->label('الاسم')->searchable()->sortable(),
            TextColumn::make('phone')->label('الهاتف')->searchable(),
            TextColumn::make('national_id')->label('الرقم القومي')->searchable()->placeholder('—'),
            TextColumn::make('email')->label('البريد الإلكتروني')->searchable(),
            TextColumn::make('governorate.name_ar')->label('المحافظة')->sortable(),
            TextColumn::make('markazModel.name_ar')->label('المركز'),
            IconColumn::make('is_approved')
                ->boolean()
                ->label('الحالة')
                ->trueIcon('heroicon-o-check-circle')
                ->falseIcon('heroicon-o-clock')
                ->trueColor('success')
                ->falseColor('warning'),
            TextColumn::make('created_at')->label('تاريخ التسجيل')->dateTime()->sortable(),
        ])
        ->recordActions([
            Action::make('approve')
                ->label('اعتماد وتفعيل')
                ->icon('heroicon-o-check-circle')
                ->color('success')
                ->requiresConfirmation()
                ->modalHeading('اعتماد حساب المواطن')
                ->modalDescription(fn (User $record) => "هل أنت متأكد من رغبتك في اعتماد وتفعيل حساب المواطن ({$record->name})؟ سيتمكن فوراً من تسجيل الدخول وتقديم الطلبات.")
                ->modalSubmitActionLabel('نعم، اعتمد الحساب')
                ->action(function (User $record): void {
                    $record->update(['is_approved' => true]);
                    Notification::make()
                        ->title('تم اعتماد وتفعيل حساب المواطن بنجاح')
                        ->success()
                        ->send();
                }),
            Actions\ViewAction::make(),
            Actions\EditAction::make(),
            Actions\DeleteAction::make()->label('رفض وحذف'),
        ])
        ->toolbarActions([
            Actions\BulkActionGroup::make([
                Actions\BulkAction::make('approve_selected')
                    ->label('اعتماد وتفعيل الحسابات المحددة')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->requiresConfirmation()
                    ->modalHeading('اعتماد الحسابات المحددة')
                    ->modalDescription('هل أنت متأكد من رغبتك في اعتماد وتفعيل جميع حسابات المواطنين المحددة؟')
                    ->modalSubmitActionLabel('نعم، اعتمد الكل')
                    ->action(function (Collection $records): void {
                        $records->each->update(['is_approved' => true]);
                        Notification::make()
                            ->title('تم اعتماد الحسابات المحددة بنجاح')
                            ->success()
                            ->send();
                    }),
                Actions\DeleteBulkAction::make()->label('حذف المحدد'),
            ]),
        ])
        ->filters([]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('المعلومات الأساسية')->schema([
                TextEntry::make('name')->label('الاسم الكامل'),
                TextEntry::make('phone')->label('رقم الهاتف'),
                TextEntry::make('national_id')->label('الرقم القومي')->placeholder('غير محدد'),
                TextEntry::make('email')->label('البريد الإلكتروني'),
                TextEntry::make('governorate.name_ar')->label('المحافظة'),
                TextEntry::make('markazModel.name_ar')->label('المركز/القسم'),
                TextEntry::make('areaModel.name_ar')->label('المنطقة/الحي'),
                TextEntry::make('detailed_address')->label('العنوان التفصيلي')->placeholder('—'),
                TextEntry::make('is_approved')
                    ->label('حالة الاعتماد')
                    ->badge()
                    ->color(fn ($state) => $state ? 'success' : 'warning')
                    ->formatStateUsing(fn ($state) => $state ? 'مُفعّل ومعتمد' : 'بانتظار الموافقة'),
                TextEntry::make('created_at')->label('تاريخ التسجيل')->dateTime(),
            ]),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPendingCitizens::route('/'),
            'edit' => Pages\EditPendingCitizen::route('/{record}/edit'),
            'view' => Pages\ViewPendingCitizen::route('/{record}'),
        ];
    }
}
