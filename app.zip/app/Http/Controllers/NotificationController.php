<?php

namespace App\Http\Controllers;

use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Str;

class NotificationController extends Controller
{
    public function read(DatabaseNotification $notification)
    {
        $notification = auth()->user()
            ->notifications()
            ->whereKey($notification->id)
            ->firstOrFail();

        $notification->markAsRead();

        $url = $notification->data['url'] ?? route('home');

        return Str::startsWith($url, url('/')) || (Str::startsWith($url, '/') && ! Str::startsWith($url, '//'))
            ? redirect()->to($url)
            : redirect()->route('home');
    }
}
