<?php
namespace App\Filament\Resources\DeletedMpVideoResource\Pages;
use App\Filament\Resources\DeletedMpVideoResource; use Filament\Resources\Pages\ListRecords;
class ListDeletedMpVideoResources extends ListRecords {protected static string $resource=DeletedMpVideoResource::class;}
