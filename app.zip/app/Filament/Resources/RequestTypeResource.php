<?php

namespace App\Filament\Resources;

use App\Filament\Resources\RequestTypeResource\Pages;
use App\Models\RequestType;
use Filament\Actions;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class RequestTypeResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = RequestType::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-tag';
    public static function getNavigationGroup(): ?string { return 'إعدادات الطلبات'; }
    public static function getModelLabel(): string { return 'نوع طلب'; }
    public static function getPluralModelLabel(): string { return 'أنواع الطلبات'; }
    public static function getEloquentQuery(): Builder { return parent::getEloquentQuery()->withCount('requests'); }
    public static function form(Schema $schema): Schema { return $schema->components([TextInput::make('name')->label('اسم النوع')->required()->unique(ignoreRecord: true)->maxLength(255), TextInput::make('sort_order')->label('ترتيب العرض')->numeric()->default(0)->required(), Toggle::make('is_active')->label('نشط')->default(true)]); }
    public static function table(Table $table): Table { return $table->columns([TextColumn::make('name')->label('النوع')->searchable()->sortable(), TextColumn::make('requests_count')->label('عدد الطلبات')->badge()->color('primary')->sortable(), TextColumn::make('sort_order')->label('الترتيب')->sortable(), IconColumn::make('is_active')->label('نشط')->boolean()])->recordActions([Actions\EditAction::make(), Actions\DeleteAction::make()->disabled(fn (RequestType $record): bool => $record->requests()->exists())->tooltip('لا يمكن حذف نوع مرتبط بطلبات.')]); }
    public static function getPages(): array { return ['index' => Pages\ListRequestTypes::route('/'), 'create' => Pages\CreateRequestType::route('/create'), 'edit' => Pages\EditRequestType::route('/{record}/edit')]; }
}
