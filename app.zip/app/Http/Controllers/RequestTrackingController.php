<?php

namespace App\Http\Controllers;

use App\Models\MpRequest;
use App\Rules\EgyptianPhone;
use Illuminate\Http\Request;

class RequestTrackingController extends Controller
{
    public function show(Request $request)
    {
        $input = trim($request->input('reference_number') ?? $request->input('phone') ?? $request->input('query') ?? $request->input('search_term') ?? '');

        if (empty($input)) {
            return back()
                ->withInput()
                ->withErrors(['reference_number' => 'يرجى إدخال الرقم المرجعي للطلب أو رقم الهاتف المسجل به الطلب.']);
        }

        $normalizedPhone = EgyptianPhone::normalize($input);
        $requests = collect();

        // 1. Try search by phone if it looks like a phone number (all digits or starts with 01)
        if (preg_match('/^01[0125][0-9]{8}$/', $normalizedPhone) || (is_numeric($input) && strlen($input) >= 10)) {
            $requests = MpRequest::with(['mp.user', 'replies.user'])
                ->whereHas('user', function ($q) use ($normalizedPhone, $input) {
                    $q->where('phone', $normalizedPhone)
                      ->orWhere('phone', $input);
                })
                ->latest()
                ->get();
        }

        // 2. If not found by phone, search by reference number or ID
        if ($requests->isEmpty()) {
            $cleanedRef = strtoupper($input);
            $refWithHash = str_starts_with($cleanedRef, '#') ? $cleanedRef : '#' . $cleanedRef;

            $single = MpRequest::with(['mp.user', 'replies.user'])
                ->where('reference_number', $refWithHash)
                ->orWhere('reference_number', $cleanedRef)
                ->orWhere('id', is_numeric($input) ? (int)$input : 0)
                ->first();

            if ($single) {
                $requests = collect([$single]);
            }
        }

        if ($requests->isEmpty()) {
            return back()
                ->withInput()
                ->withErrors(['reference_number' => 'لم يتم العثور على أي طلب مطابق للرقم المرجعي أو رقم الهاتف المدخل.']);
        }

        // If specific request_id requested from the list
        $selectedId = $request->input('request_id');
        $requestModel = $selectedId ? $requests->firstWhere('id', $selectedId) : $requests->first();
        if (!$requestModel) {
            $requestModel = $requests->first();
        }

        $searchTerm = $input;

        return view('pages.track_request', compact('requestModel', 'requests', 'searchTerm'));
    }
}

