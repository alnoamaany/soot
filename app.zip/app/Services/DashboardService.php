<?php

namespace App\Services;

use App\Models\MpRequest;
use App\Models\Mp;
use App\Models\Post;
use App\Models\Library;
use App\Models\Poll;
use App\Models\User;
use Illuminate\Support\Arr;

class DashboardService
{
    public function summaryCards(): array
    {
        return [
            'users' => User::count(),
            'mps' => Mp::count(),
            'posts' => Post::count(),
            'libraries' => Library::count(),
            'polls' => Poll::count(),
            'open_requests' => MpRequest::where('status', 'open')->count(),
        ];
    }

    public function requestsByStatus(): array
    {
        return MpRequest::select('status')
            ->selectRaw('count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status')
            ->toArray();
    }

    public function usersByGovernorate(): array
    {
        $rows = User::select('governorate_id')
            ->selectRaw('count(*) as total')
            ->groupBy('governorate_id')
            ->get();

        $result = [];
        foreach ($rows as $r) {
            $label = $r->governorate?->name ?? $r->governorate_id;
            $result[$label] = (int) $r->total;
        }

        return $result;
    }
}
