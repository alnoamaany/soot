<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Library;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Display the home page with featured posts and libraries.
     */
    public function index()
    {
        $posts = Post::with(['category', 'media'])
            ->where('is_published', true)
            ->whereNull('mp_id')
            ->latest()
            ->take(6)
            ->get();

        $libraries = Library::with(['media', 'category', 'mp'])
            ->where('is_active', true)
            ->latest()
            ->take(8)
            ->get();

        $featuredLibraries = Library::with(['media', 'category', 'mp'])
            ->where('is_active', true)
            ->where('is_featured', true)
            ->where(function ($query) {
                $query->whereNull('published_at')->orWhere('published_at', '<=', now());
            })
            ->latest('published_at')
            ->take(8)
            ->get();

        if ($featuredLibraries->isEmpty()) {
            $featuredLibraries = $libraries;
        }

        if ($libraries->isEmpty()) {
            $libraries = Library::with('media')->latest()->take(8)->get();
        }

        // Featured MPs for the Hero right section
        $featuredMps = \App\Models\Mp::with(['user.media', 'user.governorate', 'user.areaModel'])
            ->where('is_active', true)
            ->where('is_featured', true)
            ->latest()
            ->take(12)
            ->get();

        if ($featuredMps->isEmpty()) {
            $featuredMps = \App\Models\Mp::with(['user.media', 'user.governorate', 'user.areaModel'])
                ->where('is_active', true)
                ->latest()
                ->take(12)
                ->get();
        }

        // All active MPs for the bottom slider
        $mps = \App\Models\Mp::with(['user.media', 'user.governorate', 'user.areaModel'])
            ->where('is_active', true)
            ->latest()
            ->take(20)
            ->get();

        $mediaCategories = \App\Models\Category::withCount('posts')
            ->orderByDesc('posts_count')
            ->take(6)
            ->get();

        $pressReleases = Post::with(['category', 'media', 'mp.user'])
            ->where('is_published', true)
            ->latest('published_at')
            ->take(6)
            ->get();

        $totalProcessedRequests = \App\Models\MpRequest::whereIn('status', ['completed', 'approved', 'in_progress'])->count() ?: 0;
        $activeMpsCount = \App\Models\Mp::where('is_active', true)->count() ?: 0;
        $govsCount = \App\Models\Mp::whereNotNull('district')->distinct('district')->count() ?: 0;

        return view('pages.home', compact(
            'posts', 
            'libraries',
            'featuredLibraries',
            'featuredMps',
            'mps', 
            'totalProcessedRequests', 
            'activeMpsCount', 
            'govsCount',
            'mediaCategories',
            'pressReleases'
        ));
    }
}
