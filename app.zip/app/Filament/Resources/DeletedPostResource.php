<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DeletedPostResource\Pages;
use App\Models\Post;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class DeletedPostResource extends Resource
{
    protected static ?string $model = Post::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-trash';
    protected static ?int $navigationSort = 90;

    public static function getNavigationGroup(): ?string { return 'المركز الإعلامي'; }
    public static function getModelLabel(): string { return 'محذوفات النواب'; }
    public static function getPluralModelLabel(): string { return 'محذوفات النواب'; }
    public static function canCreate(): bool { return false; }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->whereNotNull('deleted_by_mp_at');
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('title')->label('الخبر')->searchable(),
            TextColumn::make('mp_id')->label('النائب'),
            TextColumn::make('deleted_by_mp_reason')->label('السبب')->wrap(),
            TextColumn::make('deleted_by_mp_at')->label('تاريخ الحذف')->dateTime(),
        ])->recordActions([
            Actions\EditAction::make()->visible(false),
            Actions\DeleteAction::make()->label('حذف نهائي')->requiresConfirmation(),
            Actions\Action::make('restore')->label('استعادة')->icon('heroicon-o-arrow-uturn-left')->color('success')->requiresConfirmation()->action(function (Post $record) {
                $record->update([
                    'deleted_by_mp_at' => null,
                    'deleted_by_mp_id' => null,
                    'deleted_by_mp_reason' => null,
                    'is_published' => true,
                ]);
                Notification::make()->title('تمت الاستعادة')->success()->send();
            }),
        ]);
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListDeletedPostResources::route('/')];
    }
}
