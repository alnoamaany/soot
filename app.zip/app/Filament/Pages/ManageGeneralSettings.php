<?php

namespace App\Filament\Pages;

use App\Services\WelcomeEmailService;
use App\Settings\GeneralSettings;
use Filament\Actions\Action;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Pages\SettingsPage;

class ManageGeneralSettings extends SettingsPage
{
    protected static string $settings = GeneralSettings::class;

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-cog-6-tooth';
    }

    public static function getNavigationSort(): ?int
    {
        return 100;
    }

    public static function getNavigationGroup(): ?string
    {
        return 'الإعدادات';
    }

    public static function getNavigationLabel(): string
    {
        return 'إعدادات الموقع والصفحات';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'إعدادات الموقع والصفحات';
    }

    public static function getBreadcrumb(): string
    {
        return 'إعدادات الموقع والصفحات';
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('send_test_email')
                ->label('إرسال بريد تجريبي (اختبار)')
                ->icon('heroicon-o-paper-airplane')
                ->color('success')
                ->modalHeading('إرسال بريد إلكتروني تجريبي')
                ->modalDescription('أدخل البريد الإلكتروني الذي ترغب في إرسال رسالة تجريبية إليه لاختبار إعدادات SMTP وصحة الإرسال وتنسيق القوالب.')
                ->modalSubmitActionLabel('إرسال الآن')
                ->form([
                    Select::make('test_type')
                        ->label('نوع الرسالة المراد اختبارها')
                        ->options([
                            'welcome' => 'رسالة الترحيب عند تسجيل المواطن',
                            'approval' => 'رسالة تفعيل واعتماد حساب المواطن',
                        ])
                        ->default('welcome')
                        ->required(),
                    TextInput::make('test_email')
                        ->label('البريد الإلكتروني المستهدف للاختبار')
                        ->email()
                        ->required()
                        ->placeholder('user@example.com'),
                    TextInput::make('test_subject')
                        ->label('عنوان الرسالة التجريبية (اختياري)')
                        ->placeholder('اتركه فارغاً لاستخدام العنوان المحدد في الإعدادات')
                        ->helperText('إذا تركته فارغاً سيتم استخدام العنوان المحفوظ في الإعدادات حسب نوع الرسالة.'),
                ])
                ->action(function (array $data): void {
                    $email = trim($data['test_email'] ?? '');
                    $subject = !empty($data['test_subject']) ? trim($data['test_subject']) : null;
                    $type = $data['test_type'] ?? 'welcome';

                    $result = WelcomeEmailService::sendTestEmail($email, $subject, $type);

                    if ($result['success']) {
                        Notification::make()
                            ->title('تم إرسال البريد التجريبي بنجاح!')
                            ->body($result['message'])
                            ->success()
                            ->duration(7000)
                            ->send();
                    } else {
                        Notification::make()
                            ->title('فشل إرسال البريد التجريبي')
                            ->body($result['message'])
                            ->danger()
                            ->persistent()
                            ->send();
                    }
                }),
        ];
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('البيانات الأساسية للموقع')
                    ->description('اسم المنصة الشعار والأيقونة الرسمية')
                    ->collapsible()
                    ->schema([
                        TextInput::make('site_name')
                            ->label('اسم الموقع')
                            ->required(),
                        TextInput::make('site_slogan')
                            ->label('شعار الموقع')
                            ->helperText('يظهر أسفل اسم الموقع في رأس الواجهة.')
                            ->maxLength(255)
                            ->placeholder('مثال: مجلس الشعب المصري'),

                        TextInput::make('featured_notice')
                            ->label('إشعار مميز')
                            ->helperText('يظهر في الشريط العلوي للموقع ويمكن تغييره من هنا.')
                            ->maxLength(255)
                            ->placeholder('مثال: البوابة الرسمية — مجلس الشعب المصري'),

                        FileUpload::make('site_logo')
                            ->label('شعار الموقع (Logo)')
                            ->image()
                            ->directory('settings'),
                        FileUpload::make('site_favicon')
                            ->label('أيقونة المتصفح (Favicon)')
                            ->image()
                            ->directory('settings'),
                    ]),
                Section::make('أمان الحسابات والأجهزة')
                    ->description('التحكم في مدة جلسة الدخول وعدد الأجهزة المسموح بها لكل حساب والكلمات المحظورة.')
                    ->collapsible()
                    ->schema([
                        TextInput::make('session_lifetime')->label('مدة الجلسة لكل جهاز (بالدقائق)')->numeric()->minValue(5)->maxValue(43200)->default(120)->required(),
                        TextInput::make('max_devices_per_user')->label('الحد الأقصى لعدد الأجهزة لكل مستخدم')->numeric()->minValue(1)->maxValue(20)->default(3)->required(),
                        Textarea::make('blocked_words')->label('الكلمات المحظورة في المنصة')->rows(4)->helperText('اكتب الكلمات مفصولة بفواصل أو كل كلمة في سطر مستقل.')->columnSpanFull(),
                    ])->columns(2),
                Section::make('إعدادات ظهور إحصائيات صفحة النائب')
                    ->description('تحكم مستقل في إظهار أرقام صفحة النائب على الواجهة.')
                    ->collapsible()
                    ->schema([
                        Toggle::make('mp_show_followers')->label('إظهار متابع بالدائرة')->default(true),
                        Toggle::make('mp_show_completed_requests')->label('إظهار طلب تم إنجازه')->default(true),
                        Toggle::make('mp_show_recorded_videos')->label('إظهار فيديو ولقاء مسجل')->default(true),
                        Toggle::make('mp_show_response_rate')->label('إظهار معدل الاستجابة والمتابعة')->default(true),
                    ])->columns(2),
                Section::make('إشعارات البريد الإلكتروني للمواطنين')
                    ->description('إرسال نسخة بريدية من إشعارات المنصة للمواطن المسجل ببريد إلكتروني.')
                    ->collapsible()
                    ->schema([
                        Toggle::make('email_notify_new_request')->label('إشعار البريد عند فتح طلب جديد')->default(true),
                        Toggle::make('email_notify_request_status')->label('إشعار البريد عند تحديث حالة الطلب')->default(true),
                        Toggle::make('email_notify_important_notifications')->label('إشعارات البريد للإشعارات المهمة')->default(true),
                    ])->columns(2),
                Section::make('التنبيهات الإدارية للمنصة')
                    ->description('إرسال تنبيه لمديري المنصة عند حدوث الأحداث الإدارية المهمة، مع إمكانية إيقاف قناة معينة دون تعطيل الأخرى.')
                    ->collapsible()
                    ->schema([
                        Toggle::make('admin_notifications_enabled')
                            ->label('تفعيل قائمة الإشعارات الإدارية')
                            ->helperText('عند التفعيل، تُحفظ الأحداث المهمة في قائمة إشعارات لوحة الإدارة.')
                            ->default(true),
                        Toggle::make('admin_email_notifications_enabled')
                            ->label('إرسال التنبيهات الإدارية بالبريد')
                            ->helperText('عند التفعيل، تُرسل نسخة من الأحداث المهمة إلى بريد كل مدير منصة نشط.')
                            ->default(true),
                        TextInput::make('admin_notification_email')
                            ->label('البريد الإلكتروني لتلقي إشعارات الإدارة')
                            ->email()
                            ->nullable()
                            ->placeholder('admin@example.com')
                            ->helperText('إذا تم إدخال بريد هنا، تُرسل إليه جميع التنبيهات الإدارية البريدية كعنوان مركزي واحد.')
                            ->columnSpanFull(),
                    ])->columns(2),
                Section::make('العلامة المائية للصور')
                    ->description('إعدادات العلامة المائية للصور المنشورة في المنصة.')
                    ->collapsible()
                    ->schema([
                        Toggle::make('watermark_enabled')->label('تفعيل العلامة المائية')->default(false)->columnSpanFull(),
                        FileUpload::make('watermark_image')->label('صورة العلامة المائية')->image()->directory('settings/watermark'),
                        Select::make('watermark_position')->label('موضع العلامة')->options([
                            'top-left'=>'أعلى اليسار','top-center'=>'أعلى المنتصف','top-right'=>'أعلى اليمين',
                            'middle-left'=>'منتصف اليسار','center'=>'المنتصف','middle-right'=>'منتصف اليمين',
                            'bottom-left'=>'أسفل اليسار','bottom-center'=>'أسفل المنتصف','bottom-right'=>'أسفل اليمين',
                        ])->default('bottom-right'),
                        Select::make('watermark_motion')->label('حركة العلامة')->options(['static'=>'ثابتة','moving'=>'متحركة تلقائياً'])->default('static'),
                        TextInput::make('watermark_opacity')->label('نسبة الشفافية (%)')->numeric()->minValue(0)->maxValue(100)->default(35),
                    ])->columns(2),
                Section::make('إعدادات الفوتر')
                    ->description('عدّل نص حقوق النشر الذي يظهر للزوار في أسفل الموقع.')
                    ->collapsible()
                    ->schema([
                        TextInput::make('footer_copyright')
                            ->label('نص حقوق النشر')
                            ->maxLength(255)
                            ->placeholder('© 2026 مجلس النواب المصري - جميع الحقوق محفوظة'),
                    ]),
Section::make('ظهور طلبات المواطنين')                    ->description('يمكن إظهار أو إخفاء قسم طلبات المواطنين من قائمة الإدارة دون حذف الطلبات أو بياناتها.')                    ->collapsible()                    ->schema([                        Toggle::make('citizen_requests_enabled')                            ->label('إظهار طلبات المواطنين في لوحة الإدارة')                            ->default(true),                        Toggle::make('latest_requests_widget_enabled')                            ->label('إظهار أحدث الطلبات المقدمة في لوحة الإدارة')                            ->helperText('تفعيل أو إخفاء قسم أحدث الطلبات المقدمة من الصفحة الرئيسية للوحة الإدارة.')                            ->default(true),                    ]),                Section::make('ضوابط طلبات واعتماد المواطنين')
                    ->description('التحكم في اعتماد حسابات المواطنين والحد الأقصى لعدد الطلبات المسموح بتقديمها.')
                    ->collapsible()
                    ->schema([
                        Toggle::make('auto_approve_citizens')
                            ->label('الموافقة التلقائية على تسجيل المواطنين')
                            ->helperText('عند تفعيل هذا الخيار، يتم تفعيل واعتماد حساب المواطن الجديد فور تسجيله دون انتظار موافقة الإدارة. عند التعطيل، يظل الحساب قيد المراجعة حتى يعتمده الأدمن.')
                            ->default(false)
                            ->columnSpanFull(),
                        TextInput::make('citizen_monthly_request_limit')
                            ->label('الحد الأقصى لطلبات المواطن شهرياً')
                            ->helperText('عدد الطلبات المتاح للمواطن تقديمها في الشهر (يتجدد رصيده تلقائياً بداية كل شهر). اكتب 0 إذا كنت تريد السماح بعدد غير محدود.')
                            ->numeric()
                            ->minValue(0)
                            ->default(0)
                            ->required(),
                        TextInput::make('citizen_max_active_requests')
                            ->label('الحد الأقصى للطلبات المفتوحة معاً (في نفس الوقت)')
                            ->helperText('أقصى عدد للطلبات الجارية/قيد المتابعة التي يمكن للمواطن فتحها بالتوازي قبل إتمامها. اكتب 0 للسماح بأي عدد متزامن.')
                            ->numeric()
                            ->minValue(0)
                            ->default(0)
                            ->required(),
                    ])->columns(2),
                Section::make('إعدادات بريد SMTP')
                    ->description('تُستخدم هذه الإعدادات لإرسال رسائل المنصة، مثل استعادة كلمة المرور والتنبيهات.')
                    ->collapsible()
                    ->schema([
                        Toggle::make('smtp_enabled')
                            ->label('تفعيل إعدادات SMTP من لوحة التحكم')
                            ->helperText('عند الإيقاف، يستخدم الموقع إعدادات البريد الموجودة في ملف البيئة.'),
                        TextInput::make('smtp_host')
                            ->label('خادم SMTP')
                            ->placeholder('smtp.example.com')
                            ->required(fn (callable $get): bool => (bool) $get('smtp_enabled')),
                        TextInput::make('smtp_port')
                            ->label('المنفذ')
                            ->numeric()
                            ->minValue(1)
                            ->maxValue(65535)
                            ->default(587)
                            ->required(fn (callable $get): bool => (bool) $get('smtp_enabled')),
                        TextInput::make('smtp_username')
                            ->label('اسم المستخدم')
                            ->maxLength(255),
                        TextInput::make('smtp_password')
                            ->label('كلمة المرور')
                            ->password()
                            ->revealable()
                            ->maxLength(255),
                        Select::make('smtp_encryption')
                            ->label('التشفير')
                            ->options([
                                'tls' => 'TLS',
                                'ssl' => 'SSL',
                                'none' => 'بدون تشفير',
                            ])
                            ->default('tls')
                            ->required(),
                        TextInput::make('smtp_from_address')
                            ->label('بريد المُرسل')
                            ->email()
                            ->maxLength(255)
                            ->required(fn (callable $get): bool => (bool) $get('smtp_enabled')),
                        TextInput::make('smtp_from_name')
                            ->label('اسم المُرسل')
                            ->maxLength(255)
                            ->placeholder('اسم الموقع'),
                    ])->columns(2),
                Section::make('إعدادات رسائل البريد الإلكتروني للمواطنين (الترحيب والتفعيل)')
                    ->description('التحكم في صياغة وإرسال رسائل الترحيب عند التسجيل، ورسائل إشعار المواطن بتفعيل واعتماد حسابه.')
                    ->collapsible()
                    ->schema([
                        Tabs::make('أنواع رسائل البريد')
                            ->tabs([
                                Tab::make('رسالة الترحيب عند التسجيل')
                                    ->icon('heroicon-o-sparkles')
                                    ->schema([
                                        Toggle::make('welcome_email_enabled')
                                            ->label('تفعيل إرسال رسالة ترحيبية بالبريد الإلكتروني عند تسجيل المواطن')
                                            ->helperText('عند التفعيل، سيتم إرسال بريد ترحيبي فوري لأي مواطن يسجل بريداً إلكترونياً صحيحاً.')
                                            ->default(true)
                                            ->columnSpanFull(),
                                        TextInput::make('welcome_email_subject')
                                            ->label('عنوان / موضوع الرسالة الترحيبية')
                                            ->placeholder('مرحباً بك في منصة {site_name}')
                                            ->helperText('يمكنك استخدام المتغيرات: {name}, {site_name}')
                                            ->columnSpanFull(),
                                        RichEditor::make('welcome_email_body')
                                            ->label('محتوى وتصميم الرسالة الترحيبية')
                                            ->helperText('المتغيرات المتاحة: {name}, {phone}, {email}, {site_name}, {status}, {login_url}')
                                            ->columnSpanFull(),
                                    ]),
                                Tab::make('رسالة اعتماد وتفعيل الحساب')
                                    ->icon('heroicon-o-check-badge')
                                    ->schema([
                                        Toggle::make('approval_email_enabled')
                                            ->label('تفعيل إرسال بريد إلكتروني عند اعتماد وتفعيل حساب المواطن')
                                            ->helperText('عند اعتماد حساب المواطن من لوحة التحكم، يتم إرسال بريد إلكتروني فوري لإبلاغه بتفعيل حسابه وإمكانية تسجيل الدخول وتقديم الطلبات.')
                                            ->default(true)
                                            ->columnSpanFull(),
                                        TextInput::make('approval_email_subject')
                                            ->label('عنوان / موضوع رسالة التفعيل')
                                            ->placeholder('تهانينا! تم تفعيل واعتماد حسابكم في منصة {site_name}')
                                            ->helperText('يمكنك استخدام المتغيرات: {name}, {site_name}')
                                            ->columnSpanFull(),
                                        RichEditor::make('approval_email_body')
                                            ->label('محتوى وتصميم رسالة التفعيل')
                                            ->helperText('المتغيرات المتاحة: {name}, {phone}, {email}, {site_name}, {login_url}')
                                            ->columnSpanFull(),
                                    ]),
                            ])
                            ->columnSpanFull(),
                    ]),
                Tabs::make('محتوى الصفحات التعريفية والقانونية')
                    ->tabs([
                        Tab::make('عن المنصة (من نحن)')
                            ->icon('heroicon-o-information-circle')
                            ->schema([
                                RichEditor::make('about_us')
                                    ->label('محتوى صفحة من نحن')
                                    ->helperText('اكتب وتصمّم المحتوى الذي يظهر في صفحة /about مباشرة')
                                    ->columnSpanFull(),
                            ]),
                        Tab::make('سياسة الخصوصية')
                            ->icon('heroicon-o-shield-check')
                            ->schema([
                                RichEditor::make('privacy_policy')
                                    ->label('محتوى صفحة سياسة الخصوصية')
                                    ->helperText('اكتب وتصمّم المحتوى الذي يظهر في صفحة /privacy مباشرة')
                                    ->columnSpanFull(),
                            ]),
                        Tab::make('شروط الاستخدام')
                            ->icon('heroicon-o-document-text')
                            ->schema([
                                RichEditor::make('terms_of_use')
                                    ->label('محتوى صفحة شروط الاستخدام')
                                    ->helperText('اكتب وتصمّم المحتوى الذي يظهر في صفحة /terms مباشرة')
                                    ->columnSpanFull(),
                            ]),
                        Tab::make('صفحة تواصل معنا وبيانات الاتصال')
                            ->icon('heroicon-o-phone')
                            ->schema([
                                TextInput::make('contact_phone')
                                    ->label('رقم الهاتف المعروض للتواصل')
                                    ->placeholder('+20 2 1234 5678')
                                    ->helperText('يظهر في بطاقة بيانات التواصل في صفحة تواصل معنا /contact'),
                                TextInput::make('contact_email')
                                    ->label('البريد الإلكتروني للتواصل')
                                    ->email()
                                    ->placeholder('info@parliament.gov.eg')
                                    ->helperText('يظهر كبريد رسمي للتواصل للزوار في صفحة تواصل معنا'),
                                TextInput::make('contact_address')
                                    ->label('العنوان والمقر المعروض')
                                    ->placeholder('مجلس النواب المصري، شارع قصر العيني، القاهرة، مصر')
                                    ->helperText('يظهر في بطاقة العنوان في صفحة تواصل معنا')
                                    ->columnSpanFull(),
                                Textarea::make('contact_intro')
                                    ->label('نص مقدمة صفحة تواصل معنا')
                                    ->rows(3)
                                    ->placeholder('نحن هنا للاستماع لاستفساراتك ومقترحاتك...')
                                    ->helperText('النص التوضيحي الذي يظهر أسفل عنوان صفحة تواصل معنا مباشرة.')
                                    ->columnSpanFull(),
                            ])->columns(2),
                        Tab::make('الإعلانات العادية (الصفحة الرئيسية)')
                            ->icon('heroicon-o-photo')
                            ->schema([
                                Tabs::make('أماكن الإعلانات المخصصة')
                                    ->tabs([
                                        static::makeBannerAdTab('below_ticker', '1. تحت شريط عاجل'),
                                        static::makeBannerAdTab('below_hero', '2. تحت قسم الهيرو الرئيسي'),
                                        static::makeBannerAdTab('below_track', '3. تحت تتبّع واستعلام عن طلبك'),
                                        static::makeBannerAdTab('below_request_banner', '4. تحت هل لديك طلب أو شكوى؟'),
                                        static::makeBannerAdTab('below_members', '5. تحت قسم الأعضاء'),
                                        static::makeBannerAdTab('below_news', '6. تحت أحدث الأخبار'),
                                        static::makeBannerAdTab('below_polls', '7. تحت استطلاعات الرأي'),
                                        static::makeBannerAdTab('below_library', '8. تحت المكتبة المرئية'),
                                    ])
                                    ->columnSpanFull(),
                            ]),
                        Tab::make('إعلانات جوجل (Google Ads)')
                            ->icon('heroicon-o-megaphone')
                            ->schema([
                                Toggle::make('google_adsense_enabled')
                                    ->label('تفعيل إعلانات جوجل في المنصة (Google AdSense)')
                                    ->helperText('تشغيل أو إيقاف ظهور المساحات الإعلانية عبر كامل الموقع'),

                                TextInput::make('google_adsense_client_id')
                                    ->label('معرف العميل (Publisher Client ID)')
                                    ->placeholder('ca-pub-XXXXXXXXXXXXXXXX')
                                    ->helperText('كود الناشر الخاص بحسابك في Google AdSense'),

                                Toggle::make('google_ads_auto_ads')
                                    ->label('تفعيل الإعلانات التلقائية (Auto Ads)')
                                    ->helperText('السماح لجوجل بوضع الإعلانات التلقائية في الأماكن المناسبة للزائر'),

                                Textarea::make('google_ads_header_code')
                                    ->label('كود الهيدر المخصص (Header Script Code)')
                                    ->rows(3)
                                    ->placeholder('<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-..." crossorigin="anonymous"></script>')
                                    ->helperText('كود السكريبت الرئيسي المباشر من جوجل لمنطقة <head>'),

                                Section::make('أكواد ومساحات الإعلانات المخصصة (Ad Units)')
                                    ->description('يمكنك وضع كود الإعلان المخصص (Responsive Ad Code) لكل مساحة')
                                    ->schema([
                                        Textarea::make('google_ad_slot_top')
                                            ->label('إعلان أعلى الصفحات (Top Header Banner)')
                                            ->rows(3)
                                            ->placeholder('<ins class="adsbygoogle" ...></ins>'),

                                        Textarea::make('google_ad_slot_sidebar')
                                            ->label('إعلان الشريط الجانبي (Sidebar Ad Banner)')
                                            ->rows(3)
                                            ->placeholder('<ins class="adsbygoogle" ...></ins>'),

                                        Textarea::make('google_ad_slot_in_article')
                                            ->label('إعلان داخل المقالات والأخبار (In-Article Ad Banner)')
                                            ->rows(3)
                                            ->placeholder('<ins class="adsbygoogle" ...></ins>'),

                                        Textarea::make('google_ad_slot_footer')
                                            ->label('إعلان أسفل الصفحات (Footer Banner)')
                                            ->rows(3)
                                            ->placeholder('<ins class="adsbygoogle" ...></ins>'),
                                    ])->columns(2),
                            ]),
                        Tab::make('محركات البحث والـ SEO (Google Search Console)')
                            ->icon('heroicon-o-magnifying-glass')
                            ->schema([
                                TextInput::make('google_site_verification')
                                    ->label('كود إثبات ملكية الموقع (Google Site Verification)')
                                    ->placeholder('مثال: XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')
                                    ->helperText('ضع كود التحقق من Google Search Console وسيتم تضمينه في وسم <meta> في هيدر الموقع تلقائياً'),

                                TextInput::make('google_analytics_id')
                                    ->label('معرف تتبع إحصائيات جوجل (Google Analytics 4 ID)')
                                    ->placeholder('G-XXXXXXXXXX')
                                    ->helperText('معرف القياس التابع لحساب Google Analytics لتتبع الزوار وسلوكيات البحث'),

                                Textarea::make('meta_description')
                                    ->label('الوصف الافتراضي للموقع في محركات البحث (Meta Description)')
                                    ->rows(3)
                                    ->placeholder('المنصة البرلمانية الرسمية للتواصل المباشر مع أعضاء مجلس النواب المصري...')
                                    ->helperText('النص التوضيحي الذي يظهر أسفل عنوان الموقع في نتائج بحث جوجل')
                                    ->columnSpanFull(),

                                TextInput::make('meta_keywords')
                                    ->label('الكلمات المفتاحية والدلالية للموقع (Meta Keywords)')
                                    ->placeholder('مجلس النواب, البرلمان المصري, نواب الشعب, الدوائر الانتخابية')
                                    ->helperText('كلمات مفصولة بفواصل تعبر عن أنشطة الموقع ونوابه')
                                    ->columnSpanFull(),

                                FileUpload::make('og_image')
                                    ->label('صورة المشاركة الافتراضية على السوشيال ومحركات البحث (OpenGraph Image)')
                                    ->image()
                                    ->directory('seo')
                                    ->helperText('الصورة التي تظهر عند مشاركة رابط الموقع على واتساب وفيسبوك ومنصات التواصل (المقاس المقترح: 1200x630)')
                                    ->columnSpanFull(),
                            ])->columns(2),
                    ])
                    ->columnSpanFull(),
            ]);
    }

    protected static function makeBannerAdTab(string $key, string $title): Tab
    {
        return Tab::make($title)
            ->schema([
                Toggle::make("home_banner_ads.{$key}.enabled")
                    ->label("تفعيل الإعلان في هذا المكان ({$title})")
                    ->helperText("إظهار أو إخفاء الإعلان في موضع {$title}")
                    ->columnSpanFull(),
                FileUpload::make("home_banner_ads.{$key}.image")
                    ->label("صورة الإعلان الخاص بموضع ({$title})")
                    ->image()
                    ->directory('ads')
                    ->helperText('ارفع صورة الإعلان المخصصة لهذا الموضع (المقاس المثالي: 1200x250 بكسل أو نسبة 4:1)'),
                TextInput::make("home_banner_ads.{$key}.url")
                    ->label('رابط الإعلان (الوجهة عند الضغط)')
                    ->placeholder('https://example.com/target-page')
                    ->url()
                    ->helperText('الرابط الخارجي أو الداخلي الذي يتم التوجيه إليه عند النقر'),
                TextInput::make("home_banner_ads.{$key}.title")
                    ->label('عنوان الإعلان الرئيسي')
                    ->placeholder('المساحة الإعلانية الرسمية')
                    ->helperText('يظهر كعنوان رئيسي للإعلان أو كنص بديل للصورة'),
                TextInput::make("home_banner_ads.{$key}.subtitle")
                    ->label('النص الفرعي للإعلان')
                    ->placeholder('انضم وتواصل مع نواب ومواطني جمهوريتك عبر المنصة البرلمانية الرائدة')
                    ->helperText('النص التوضيحي الذي يظهر أسفل العنوان'),
                Textarea::make("home_banner_ads.{$key}.code")
                    ->label('أو كود HTML مخصص لهذا الموضع (اختياري)')
                    ->rows(3)
                    ->placeholder('<a href="..."><img src="..." /></a>')
                    ->helperText('إذا أردت وضع كود برمجي مخصص أو سكريبت مباشر بدلاً من الصورة في هذا المكان')
                    ->columnSpanFull(),
            ])->columns(2);
    }
}

