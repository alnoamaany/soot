<?php

namespace App\Filament\Pages\Reports;

use App\Models\Governorate;
use App\Models\Mp;
use App\Models\MpFollower;
use App\Models\MpRequest;
use App\Models\MpVideo;
use Filament\Pages\Page;
use Livewire\WithPagination;

class MpsPerformanceReport extends Page
{
    use WithPagination;

    protected string $view = 'filament.pages.reports.mps-performance-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-identification';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 3;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير أداء النواب والدائرة';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير كفاءة وأداء أعضاء مجلس النواب';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير أداء النواب';
    }

    public ?string $search = '';
    public ?string $party = 'all';
    public ?string $governorate = 'all';
    public ?string $status = 'all';
    public int $perPage = 25;

    public function updatingSearch(): void { $this->resetPage(); }
    public function updatingParty(): void { $this->resetPage(); }
    public function updatingGovernorate(): void { $this->resetPage(); }
    public function updatingStatus(): void { $this->resetPage(); }
    public function updatingPerPage(): void { $this->resetPage(); }

    public function resetFilters(): void
    {
        $this->search = '';
        $this->party = 'all';
        $this->governorate = 'all';
        $this->status = 'all';
        $this->perPage = 25;
        $this->resetPage();
    }

    public function getViewData(): array
    {
        $baseQuery = Mp::query();

        if ($this->search) {
            $term = '%' . trim($this->search) . '%';
            $baseQuery->where(function ($q) use ($term) {
                $q->where('title', 'like', $term)
                    ->orWhere('district', 'like', $term)
                    ->orWhere('party', 'like', $term)
                    ->orWhereHas('user', fn ($u) => $u->where('name', 'like', $term)->orWhere('email', 'like', $term)->orWhere('phone', 'like', $term));
            });
        }

        if ($this->party && $this->party !== 'all') {
            $baseQuery->where('party', $this->party);
        }
        if ($this->governorate && $this->governorate !== 'all') {
            $baseQuery->whereHas('user', function ($q) {
                $q->where('city', $this->governorate)
                    ->orWhereHas('governorate', fn ($g) => $g->where('name_ar', $this->governorate));
            });
        }
        if ($this->status === 'active') {
            $baseQuery->where('is_active', true);
        } elseif ($this->status === 'featured') {
            $baseQuery->where('is_featured', true);
        }

        // Totals calculated efficiently
        $totalMps = (clone $baseQuery)->count();
        $filteredMpIds = (clone $baseQuery)->pluck('id');

        $totalRequestsHandled = MpRequest::whereIn('mp_id', $filteredMpIds)->count();
        $totalVideosPublished = MpVideo::whereIn('mp_id', $filteredMpIds)->count();
        $totalFollowers = MpFollower::whereIn('mp_id', $filteredMpIds)->count();

        // Paginated list with count relations only (no heavy collections in memory)
        $mps = (clone $baseQuery)
            ->with(['user.governorate', 'activeSubscription.plan'])
            ->withCount(['requests', 'videos', 'followers'])
            ->latest('id')
            ->paginate($this->perPage);

        $partiesList = Mp::whereNotNull('party')->where('party', '!=', '')->distinct()->pluck('party');
        $governoratesList = Governorate::orderBy('name_ar')->get(['id', 'name_ar']);

        return [
            'mps' => $mps,
            'totalMps' => $totalMps,
            'totalRequestsHandled' => $totalRequestsHandled,
            'totalVideosPublished' => $totalVideosPublished,
            'totalFollowers' => $totalFollowers,
            'partiesList' => $partiesList,
            'governoratesList' => $governoratesList,
        ];
    }
}
