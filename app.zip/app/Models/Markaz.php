<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Markaz extends Model
{
    use HasFactory;

    protected $table = 'markazes';

    protected $fillable = ['governorate_id', 'name_ar', 'name_en'];

    public function governorate()
    {
        return $this->belongsTo(Governorate::class);
    }

    public function areas()
    {
        return $this->hasMany(Area::class);
    }
}
