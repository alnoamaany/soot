<?php

namespace App\Filament\Resources\UserResource\RelationManagers;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Illuminate\Database\Eloquent\Model;

class RequestsRelationManager extends RelationManager
{
    protected static string $relationship = 'requests';

    public static function getTitle(Model $ownerRecord, string $pageClass): string
    {
        return 'طلبات المواطن (' . $ownerRecord->requests()->count() . ')';
    }

    public static function getModelLabel(): string
    {
        return 'طلب';
    }

    public static function getPluralModelLabel(): string
    {
        return 'الطلبات';
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('reference_number')
                    ->label('الرقم المرجعي')
                    ->placeholder('يتم التوليد تلقائياً')
                    ->disabled()
                    ->degraded(),

                TextInput::make('title')
                    ->label('عنوان الطلب')
                    ->required()
                    ->maxLength(255),

                Select::make('type')
                    ->label('نوع الطلب')
                    ->options([
                        'خدمي' => 'طلب خدمي',
                        'شكوى' => 'شكوى',
                        'مقترح' => 'مقترح',
                        'عام' => 'عام',
                    ])
                    ->default('خدمي')
                    ->required(),

                Select::make('mp_id')
                    ->label('النائب الموجه له الطلب')
                    ->relationship('mp', 'name')
                    ->searchable()
                    ->preload()
                    ->required(),

                Select::make('status')
                    ->label('حالة الطلب')
                    ->options([
                        'pending' => 'قيد الانتظار',
                        'in_progress' => 'قيد المعالجة',
                        'completed' => 'تم الرد والإنجاز',
                        'rejected' => 'مرفوض',
                    ])
                    ->default('pending')
                    ->required(),

                Textarea::make('content')
                    ->label('تفاصيل ونص الطلب')
                    ->rows(4)
                    ->required()
                    ->columnSpanFull(),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('title')
            ->columns([
                TextColumn::make('reference_number')
                    ->label('الرقم المرجعي')
                    ->searchable()
                    ->sortable()
                    ->copyable()
                    ->badge(),

                TextColumn::make('title')
                    ->label('عنوان الطلب')
                    ->searchable()
                    ->sortable()
                    ->weight('bold')
                    ->wrap(),

                TextColumn::make('type')
                    ->label('نوع الطلب')
                    ->badge()
                    ->sortable(),

                TextColumn::make('mp.user.name')
                    ->label('النائب الموجه له')
                    ->formatStateUsing(fn ($state, MpRequest $record) => $record->mp?->display_name ?: ($state ?: 'طلب عام'))
                    ->placeholder('طلب عام')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('status')
                    ->label('الحالة')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'pending' => 'warning',
                        'in_progress' => 'info',
                        'completed' => 'success',
                        'rejected' => 'danger',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'pending' => 'قيد الانتظار',
                        'in_progress' => 'قيد المعالجة',
                        'completed' => 'تم الرد والإنهاء',
                        'rejected' => 'مرفوض',
                        default => $state,
                    })
                    ->sortable(),

                TextColumn::make('created_at')
                    ->label('تاريخ التقديم')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([])
            ->headerActions([
                Actions\CreateAction::make()->label('إضافة طلب جديد للمواطن'),
            ])
            ->recordActions([
                Actions\ViewAction::make()->label('عرض'),
                Actions\EditAction::make()->label('تعديل'),
                Actions\DeleteAction::make()->label('حذف'),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
