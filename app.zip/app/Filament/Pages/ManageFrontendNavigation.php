<?php
namespace App\Filament\Pages;
use App\Settings\GeneralSettings;
use Filament\Pages\SettingsPage;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
class ManageFrontendNavigation extends SettingsPage {
 protected static string $settings=GeneralSettings::class;
 public static function getNavigationIcon():string{return 'heroicon-o-list-bullet';}
 public static function getNavigationGroup():?string{return 'القائمة الرئيسية والصفحات';}
 public static function getNavigationSort():?int{return 1;}
 public static function getNavigationLabel():string{return 'القائمة الرئيسية';}
 public function getTitle():string{return 'القائمة الرئيسية';}
 public function form(Schema $schema):Schema{return $schema->components([
  Section::make('عناصر الرئيسية')->schema([
   Repeater::make('frontend_main_navigation')->label('العناصر')
    ->schema([
      TextInput::make('label')->label('الاسم')->required(),
      TextInput::make('route')->label('اسم Route')->required(),
      Toggle::make('visible')->label('إظهار')->default(true),
    ])->columns(3)->reorderable(true)->addActionLabel('إضافة عنصر')
  ])
 ]);}
}