<?php

namespace App\Filament\Resources\MemberAds\Schemas;

use App\Models\User;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;

class MemberAdForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([

                Section::make('بيانات الإعلان')
                    ->schema([

                        Select::make('member_id')
                            ->label('النائب / العضو')
                            ->relationship('member', 'name')
                            ->searchable()
                            ->preload()
                            ->required(),

                        TextInput::make('title')
                            ->label('عنوان الإعلان')
                            ->required()
                            ->maxLength(255),

                        TextInput::make('subtitle')
                            ->label('الوصف المختصر')
                            ->maxLength(255),

                        FileUpload::make('image')
    ->visible(fn ($get) => $get('ad_type') === 'image')
    ->required(fn ($get) => $get('ad_type') === 'image')
                            ->label('صورة الإعلان')
                            ->image()
                            ->directory('member-ads')
                            ->required(fn () => ('ad_type') === 'image')
                            ->visible(fn () => ('ad_type') === 'image'),

                        TextInput::make('url')
                            ->label('رابط الإعلان')
                            ->url(),

                        Select::make('ad_type')
                            ->live()
                            ->label('نوع الإعلان')
                            ->options([
                                'image' => 'صورة',
                                'html' => 'كود HTML',
                            ])
                            ->default('image')
                            ->required(),

                        Textarea::make('code')
    ->visible(fn ($get) => $get('ad_type') === 'html')
    ->required(fn ($get) => $get('ad_type') === 'html')
                            ->label('كود HTML')
                            ->rows(5)
                            ->columnSpanFull(),

                    ])
                    ->columns(2)
                    ->columnSpanFull(),


                Section::make('مكان ظهور الإعلان داخل صفحة العضو')
                    ->schema([

                        Select::make('position')
                            ->label('موضع الإعلان')
                            ->options([
                                'top' => 'أعلى صفحة العضو',
                                'below_profile' => 'أسفل بيانات العضو',
                                'below_news' => 'أسفل أخبار العضو',
                                'below_requests' => 'أسفل الطلبات',
                                'bottom' => 'أسفل الصفحة',
                            ])
                            ->default('top')
                            ->required(),

                        TextInput::make('priority')
                            ->label('الأولوية')
                            ->numeric()
                            ->default(0)
                            ->helperText('الأرقام الأقل تظهر أولاً'),

                        Toggle::make('enabled')
                            ->label('الإعلان مفعل')
                            ->default(true),

                    ])
                    ->columns(3)
                    ->columnSpanFull(),


                Section::make('جدولة الإعلان')
                    ->schema([

                        DateTimePicker::make('start_date')
                            ->label('يبدأ من'),

                        DateTimePicker::make('end_date')
                            ->label('ينتهي في'),

                    ])
                    ->columns(2)
                    ->columnSpanFull(),



                Section::make('إعدادات المقاسات والاستجابة')
                    ->schema([

                        TextInput::make('settings.desktop_width')
                            ->label('عرض الكمبيوتر Desktop')
                            ->numeric()
                            ->default(1200),

                        TextInput::make('settings.desktop_height')
                            ->label('ارتفاع الكمبيوتر Desktop')
                            ->numeric()
                            ->default(320),


                        TextInput::make('settings.tablet_width')
                            ->label('عرض التابلت Tablet')
                            ->numeric()
                            ->default(768),

                        TextInput::make('settings.tablet_height')
                            ->label('ارتفاع التابلت Tablet')
                            ->numeric()
                            ->default(240),


                        TextInput::make('settings.mobile_width')
                            ->label('عرض الهاتف Mobile')
                            ->numeric()
                            ->default(360),

                        TextInput::make('settings.mobile_height')
                            ->label('ارتفاع الهاتف Mobile')
                            ->numeric()
                            ->default(180),


                        Select::make('settings.fit')
                            ->label('طريقة ملء الصورة')
                            ->options([
                                'cover'=>'Cover',
                                'contain'=>'Contain',
                                'fill'=>'Fill',
                            ])
                            ->default('cover'),


                        Select::make('settings.position')
                            ->label('محاذاة الصورة')
                            ->options([
                                'center'=>'Center',
                                'top'=>'Top',
                                'bottom'=>'Bottom',
                            ])
                            ->default('center'),

                    ])
                    ->columns(3)
                    ->columnSpanFull(),
                Section::make('حدود العرض والإحصائيات')
                    ->schema([

                        TextInput::make('max_views')
                            ->label('الحد الأقصى للمشاهدات')
                            ->numeric()
                            ->helperText('اتركه فارغاً لعرض غير محدود'),

                        TextInput::make('views')
                            ->label('عدد المشاهدات')
                            ->numeric()
                            ->default(0)
                            ->disabled(),

                        TextInput::make('clicks')
                            ->label('عدد الضغطات')
                            ->numeric()
                            ->default(0)
                            ->disabled(),

                    ])
                    ->columns(3)
                    ->columnSpanFull(),


            ]);
    }
}
