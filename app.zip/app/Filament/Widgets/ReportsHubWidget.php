<?php

namespace App\Filament\Widgets;

use App\Models\Governorate;
use App\Models\Library;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\MpSubscription;
use App\Models\Poll;
use App\Models\User;
use Filament\Widgets\Widget;

class ReportsHubWidget extends Widget
{
    protected string $view = 'filament.widgets.reports-hub-widget';

    protected static ?int $sort = 2;

    protected int | string | array $columnSpan = 'full';

    public function getReports(): array
    {
        return [
            [
                'title' => 'التقرير التنفيذي الشامل',
                'description' => 'مؤشرات الأداء العامة، نسب الإنجاز، وملخص الأنشطة البرلمانية',
                'url' => route('filament.admin.pages.general-executive-report'),
                'icon' => 'heroicon-o-presentation-chart-line',
                'badge' => 'تقرير شامل',
                'stat' => '100% متكامل',
                'stat_label' => 'حالة المؤشرات',
                'color' => 'amber',
            ],
            [
                'title' => 'تقرير الطلبات والشكاوى',
                'description' => 'متابعة تصنيفات الحالات، الأولويات، وسرعة الرد على المواطنين',
                'url' => route('filament.admin.pages.requests-report'),
                'icon' => 'heroicon-o-clipboard-document-check',
                'badge' => 'الطلبات',
                'stat' => MpRequest::count(),
                'stat_label' => 'إجمالي الطلبات',
                'color' => 'emerald',
            ],
            [
                'title' => 'تقرير أداء النواب والدوائر',
                'description' => 'إحصائيات إنجاز كل نائب، حجم التفاعل، ومقاطع الفيديو المنشورة',
                'url' => route('filament.admin.pages.mps-performance-report'),
                'icon' => 'heroicon-o-user-group',
                'badge' => 'النواب',
                'stat' => Mp::where('is_active', true)->count(),
                'stat_label' => 'نائب نشط',
                'color' => 'blue',
            ],
            [
                'title' => 'تقرير الاشتراكات والإيرادات',
                'description' => 'بيانات الباقات البرلمانية، الفواتير المحصلة، والخطط الفعالة',
                'url' => route('filament.admin.pages.subscriptions-financial-report'),
                'icon' => 'heroicon-o-credit-card',
                'badge' => 'المالية',
                'stat' => MpSubscription::where('status', 'active')->count(),
                'stat_label' => 'اشتراك ساري',
                'color' => 'purple',
            ],
            [
                'title' => 'تقرير التوزيع الجغرافي',
                'description' => 'توزيع الطلبات والمستخدمين على المحافظات والمراكز والأحياء',
                'url' => route('filament.admin.pages.geographic-distribution-report'),
                'icon' => 'heroicon-o-map-pin',
                'badge' => 'الجغرافيا',
                'stat' => Governorate::count(),
                'stat_label' => 'محافظة مغطاة',
                'color' => 'rose',
            ],
            [
                'title' => 'تقرير استطلاعات الرأي',
                'description' => 'نتائج التصويتات الشعبية، نسب المشاركة، والخيارات الأكثر تفاعلاً',
                'url' => route('filament.admin.pages.polls-and-votes-report'),
                'icon' => 'heroicon-o-chart-bar',
                'badge' => 'الاستطلاعات',
                'stat' => Poll::count(),
                'stat_label' => 'استطلاع رأي',
                'color' => 'amber',
            ],
            [
                'title' => 'تقرير المكتبات المرئية',
                'description' => 'إحصائيات الفيديوهات، الوثائق، والمحتوى الرقمي البرلماني',
                'url' => route('filament.admin.pages.media-and-videos-report'),
                'icon' => 'heroicon-o-film',
                'badge' => 'المرئيات',
                'stat' => Library::count(),
                'stat_label' => 'مادة مرئية',
                'color' => 'cyan',
            ],
            [
                'title' => 'تقرير المواطنين والمستخدمين',
                'description' => 'سجلات التسجيل، الأنشطة، والتفاعل مع الخدمات البرلمانية',
                'url' => route('filament.admin.pages.citizens-report'),
                'icon' => 'heroicon-o-users',
                'badge' => 'المستخدمون',
                'stat' => User::where('role', 'citizen')->count(),
                'stat_label' => 'مواطن مسجل',
                'color' => 'indigo',
            ],
        ];
    }
}
