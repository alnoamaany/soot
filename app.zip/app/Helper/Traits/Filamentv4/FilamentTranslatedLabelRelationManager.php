<?php

namespace App\Helper\Traits\Filamentv4;

use Illuminate\Database\Eloquent\Model;

trait FilamentTranslatedLabelRelationManager
{
    // For Relation Managers
    public static function getTitle(Model $ownerRecord, string $pageClass): string
    {
        return __(
            str(static::getRelationshipName())
                ->kebab()
                ->replace('-', ' ')
                ->headline()
                ->toString()
        );
    }
}
