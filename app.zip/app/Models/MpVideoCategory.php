<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MpVideoCategory extends Model
{
    use HasFactory;

    protected $fillable = ['mp_id', 'name'];

    public function mp()
    {
        return $this->belongsTo(Mp::class);
    }

    public function videos()
    {
        return $this->hasMany(MpVideo::class, 'mp_video_category_id');
    }
}
