<?php
namespace App\Filament\Resources\MpSubscriptionResource\Pages;
use App\Filament\Resources\MpSubscriptionResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
class ListMpSubscriptions extends ListRecords { protected static string $resource = MpSubscriptionResource::class; protected function getHeaderActions(): array { return [Actions\CreateAction::make()]; } }
