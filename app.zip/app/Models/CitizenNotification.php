<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class CitizenNotification extends Model {protected $fillable=['user_id','title','message','url','is_important','sent_at','created_by'];protected $casts=['is_important'=>'boolean','sent_at'=>'datetime'];public function user(){return $this->belongsTo(User::class);}public function admin(){return $this->belongsTo(Admin::class,'created_by');}}
