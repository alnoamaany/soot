<?php

namespace App\Filament\Resources\MemberAds\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;

class MemberAdsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([

                ImageColumn::make('image')
                    ->label('الإعلان')
                    ->disk('public')
                    ->square(),

                TextColumn::make('member.name')
                    ->label('العضو / النائب')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('title')
                    ->label('العنوان')
                    ->searchable()
                    ->limit(40),

                TextColumn::make('position')
                    ->label('مكان الظهور')
                    ->formatStateUsing(fn ($state) => match ($state) {
                        'top' => 'أعلى الصفحة',
                        'below_profile' => 'أسفل البيانات',
                        'below_news' => 'أسفل الأخبار',
                        'below_requests' => 'أسفل الطلبات',
                        'bottom' => 'أسفل الصفحة',
                        default => $state,
                    }),

                TextColumn::make('start_date')
                    ->label('يبدأ')
                    ->dateTime('Y-m-d H:i'),

                TextColumn::make('end_date')
                    ->label('ينتهي')
                    ->dateTime('Y-m-d H:i'),

                TextColumn::make('status')
                    ->label('الحالة')
                    ->badge()
                    ->color(fn ($state) => match ($state) {
                        'نشط' => 'success',
                        'مجدول' => 'warning',
                        'منتهي' => 'danger',
                        default => 'gray',
                    }),

                TextColumn::make('views')
                    ->label('المشاهدات')
                    ->numeric()
                    ->sortable(),

                TextColumn::make('clicks')
                    ->label('الضغطات')
                    ->numeric()
                    ->sortable(),

                IconColumn::make('enabled')
                    ->label('مفعل')
                    ->boolean(),

            ])
            ->filters([

                SelectFilter::make('position')
                    ->label('مكان الظهور')
                    ->options([
                        'top' => 'أعلى الصفحة',
                        'below_profile' => 'أسفل البيانات',
                        'below_news' => 'أسفل الأخبار',
                        'below_requests' => 'أسفل الطلبات',
                        'bottom' => 'أسفل الصفحة',
                    ]),

                TernaryFilter::make('enabled')
                    ->label('حالة التفعيل'),

            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
