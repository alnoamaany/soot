<?php

namespace App\Filament\Resources\MpResource\Pages;

use App\Filament\Resources\MpResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Actions;

class ListMps extends ListRecords
{
    protected static string $resource = MpResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
