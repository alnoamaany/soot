<?php

namespace App\Services;

use App\Mail\AccountApprovedEmail;
use App\Mail\WelcomeEmail;
use App\Models\User;
use App\Settings\GeneralSettings;
use App\Services\EmailTemplateService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Throwable;

class WelcomeEmailService
{
    /**
     * Check if the provided email is a valid, sendable email address.
     */
    public static function isValidSendableEmail(?string $email, ?string $phone = null): bool
    {
        if (blank($email)) {
            return false;
        }

        $email = trim($email);

        // Filter validate format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        // Avoid sending to auto-generated dummy system fallback emails
        if ($phone && strtolower($email) === strtolower($phone . '@parliament.gov.eg')) {
            return false;
        }

        // Basic domain validation
        $parts = explode('@', $email);
        $domain = end($parts);
        if (empty($domain) || !str_contains($domain, '.')) {
            return false;
        }

        return true;
    }

    /**
     * Apply SMTP settings dynamically if enabled.
     */
    public static function configureSmtp(): void
    {
        try {
            $settings = app(GeneralSettings::class);
            if ($settings->smtp_enabled && filled($settings->smtp_host)) {
                config([
                    'mail.default' => 'smtp',
                    'mail.mailers.smtp.host' => $settings->smtp_host,
                    'mail.mailers.smtp.port' => $settings->smtp_port,
                    'mail.mailers.smtp.username' => filled($settings->smtp_username) ? $settings->smtp_username : null,
                    'mail.mailers.smtp.password' => filled($settings->smtp_password) ? $settings->smtp_password : null,
                    'mail.mailers.smtp.scheme' => match ($settings->smtp_encryption) {
                        'ssl' => 'smtps',
                        'tls' => 'smtp',
                        default => null,
                    },
                    'mail.from.address' => filled($settings->smtp_from_address)
                        ? $settings->smtp_from_address
                        : config('mail.from.address'),
                    'mail.from.name' => filled($settings->smtp_from_name)
                        ? $settings->smtp_from_name
                        : ($settings->site_name ?: config('mail.from.name')),
                ]);
            }
        } catch (Throwable $e) {
            Log::warning('Failed to configure dynamic SMTP settings: ' . $e->getMessage());
        }
    }

    /**
     * Send welcome email to a newly registered user if eligible.
     */
    public static function sendWelcomeEmail(User $user): bool
    {
        try {
            $settings = app(GeneralSettings::class);

            if (
                !$settings->welcome_email_enabled
                || !(EmailTemplateService::get('welcome')?->is_enabled ?? true)
            ) {
                return false;
            }

            if (!self::isValidSendableEmail($user->email, $user->phone)) {
                return false;
            }

            self::configureSmtp();

            Mail::to($user->email)->send(new WelcomeEmail(
                userName: $user->name,
                userPhone: $user->phone,
                userEmail: $user->email,
                isApproved: (bool) $user->is_approved,
            ));

            Log::info("Welcome email sent successfully to user {$user->id} ({$user->email}).");
            return true;
        } catch (Throwable $e) {
            Log::error("Failed to send welcome email to user {$user->id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send account approval email to a citizen upon account activation.
     */
    public static function sendApprovalEmail(User $user): bool
    {
        try {
            $settings = app(GeneralSettings::class);

            if (
                !$settings->approval_email_enabled
                || !(EmailTemplateService::get('account_approved')?->is_enabled ?? true)
            ) {
                return false;
            }

            if (!self::isValidSendableEmail($user->email, $user->phone)) {
                return false;
            }

            self::configureSmtp();

            Mail::to($user->email)->send(new AccountApprovedEmail(
                userName: $user->name,
                userPhone: $user->phone,
                userEmail: $user->email,
            ));

            Log::info("Account approval email sent successfully to user {$user->id} ({$user->email}).");
            return true;
        } catch (Throwable $e) {
            Log::error("Failed to send approval email to user {$user->id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send a test email to verify SMTP and template functionality.
     *
     * @return array{success: bool, message: string}
     */
    public static function sendTestEmail(string $targetEmail, ?string $subject = null, string $type = 'welcome'): array
    {
        if (!self::isValidSendableEmail($targetEmail)) {
            return [
                'success' => false,
                'message' => 'صيغة البريد الإلكتروني المدخل غير صالحة.',
            ];
        }

        try {
            self::configureSmtp();

            if ($type === 'approval') {
                Mail::to($targetEmail)->send(new AccountApprovedEmail(
                    userName: 'مستخدم تجريبي',
                    userPhone: '01012345678',
                    userEmail: $targetEmail,
                    customSubject: $subject ?: 'اختبار إرسال بريد تفعيل الحساب — منصة صوتنا',
                ));
            } else {
                Mail::to($targetEmail)->send(new WelcomeEmail(
                    userName: 'مستخدم تجريبي',
                    userPhone: '01012345678',
                    userEmail: $targetEmail,
                    isApproved: true,
                    customSubject: $subject ?: 'اختبار إرسال البريد — منصة صوتنا',
                ));
            }

            return [
                'success' => true,
                'message' => "تم إرسال البريد التجريبي بنجاح إلى ({$targetEmail}). يرجى فحص صندوق الوارد أو الرسائل غير المرغوب فيها (Spam).",
            ];
        } catch (Throwable $e) {
            Log::error('SMTP Test Send Failed: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'فشل إرسال البريد: ' . $e->getMessage(),
            ];
        }
    }
}
