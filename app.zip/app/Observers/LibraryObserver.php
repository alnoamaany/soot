<?php
namespace App\Observers;

use App\Models\Library;
use App\Services\AdminAlertService;

class LibraryObserver
{
    public function created(Library $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');
        AdminAlertService::notify(
            'library_item_created',
            'إضافة مادة جديدة للمكتبة',
            str_replace(['{title}'], [$title], 'تمت إضافة المادة "{title}" إلى المكتبة.'),
            $model,
            meta: ['library_id' => $model->id],
        );
    }
}
