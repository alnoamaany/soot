<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PlatformImportantNotificationResource\Pages;
use App\Models\PlatformImportantNotification;
use App\Models\User;
use App\Notifications\ImportantPlatformNotification;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class PlatformImportantNotificationResource extends Resource
{
    protected static ?string $model = PlatformImportantNotification::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-megaphone';
    protected static ?int $navigationSort = 6;

    public static function getNavigationGroup(): ?string { return 'الدعم والدليل'; }
    public static function getModelLabel(): string { return 'إشعار مهم'; }
    public static function getPluralModelLabel(): string { return 'الإشعارات المهمة'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات الإشعار')->schema([
                TextInput::make('title')->label('العنوان')->required()->maxLength(255),
                Textarea::make('body')->label('نص الإشعار')->required()->rows(7)->columnSpanFull(),
                Select::make('recipient_scope')->label('المستلمون')->options([
                    'all' => 'كل المواطنين والنواب',
                    'citizens' => 'المواطنون فقط',
                    'mps' => 'النواب فقط',
                    'user' => 'مستخدم محدد',
                ])->default('all')->required()->live(),
                Select::make('recipient_user_id')->label('المستخدم المحدد')
                    ->options(fn () => User::orderBy('name')->pluck('name', 'id'))
                    ->searchable()->preload()
                    ->visible(fn (callable $get): bool => $get('recipient_scope') === 'user')
                    ->required(fn (callable $get): bool => $get('recipient_scope') === 'user'),
                Toggle::make('is_active')->label('نشط ويظهر للمستلمين')->default(true),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->defaultSort('sent_at', 'desc')->columns([
            TextColumn::make('title')->label('العنوان')->searchable()->wrap(),
            TextColumn::make('recipient_scope')->label('المستلمون')->formatStateUsing(fn (string $state) => match ($state) {
                'all' => 'الجميع', 'citizens' => 'المواطنون', 'mps' => 'النواب', 'user' => 'مستخدم محدد', default => $state,
            })->badge(),
            IconColumn::make('is_active')->label('نشط')->boolean(),
            TextColumn::make('sent_at')->label('وقت الإرسال')->dateTime()->sortable(),
        ])->recordActions([
            Actions\EditAction::make(),
            Actions\DeleteAction::make()->requiresConfirmation(),
        ])->toolbarActions([
            Actions\CreateAction::make()
                ->after(function (PlatformImportantNotification $record): void {
                    $record->update(['admin_id' => auth('admin')->id(), 'sent_at' => now()]);

                    $users = match ($record->recipient_scope) {
                        'citizens' => User::where(function ($q) { $q->where('role', '!=', 'mp')->orWhereNull('role'); })->get(),
                        'mps' => User::where('role', 'mp')->whereHas('mp')->get(),
                        'user' => User::whereKey($record->recipient_user_id)->get(),
                        default => User::query()->get(),
                    };

                    foreach ($users as $user) {
                        $user->notify(new ImportantPlatformNotification($record));
                    }

                    Notification::make()->title('تم إرسال الإشعار المهم')->success()->send();
                }),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPlatformImportantNotifications::route('/'),
            'create' => Pages\CreatePlatformImportantNotification::route('/create'),
            'edit' => Pages\EditPlatformImportantNotification::route('/{record}/edit'),
        ];
    }
}
