<?php

namespace App\Filament\Pages\Reports;

use App\Models\Poll;
use App\Models\PollVote;
use Filament\Pages\Page;

class PollsAndVotesReport extends Page
{
    protected string $view = 'filament.pages.reports.polls-and-votes-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-chart-pie';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 7;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير استطلاعات الرأي والتصويت';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير نتائج استطلاعات الرأي ومشاركات المواطنين';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير استطلاعات الرأي';
    }

    public ?string $pollType = 'all';

    public function resetFilters(): void
    {
        $this->pollType = 'all';
    }

    public function getViewData(): array
    {
        $pQuery = Poll::with(['options', 'votes.user']);

        if ($this->pollType && $this->pollType !== 'all') {
            $pQuery->where('type', $this->pollType);
        }

        $polls = $pQuery->latest()->get();

        $totalPolls = $polls->count();
        $activePolls = $polls->where('is_active', true)->count();
        $totalVotes = $polls->sum(fn ($p) => $p->options->sum('votes_count'));

        return [
            'polls' => $polls,
            'totalPolls' => $totalPolls,
            'activePolls' => $activePolls,
            'totalVotes' => $totalVotes,
        ];
    }
}
