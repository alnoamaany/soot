<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\Http;

class Turnstile implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string, ?string=): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (empty($value)) {
            $fail('يرجى تأكيد التحقق الأمني .');
            return;
        }

        $response = Http::asForm()->post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
            'secret' => config('services.cloudflare.turnstile.secret'),
            'response' => $value,
            'remoteip' => request()->ip(),
        ]);

        if (!$response->ok() || !$response->json('success')) {
            $fail('فشل التحقق الأمني. يرجى المحاولة مرة أخرى.');
        }
    }
}
