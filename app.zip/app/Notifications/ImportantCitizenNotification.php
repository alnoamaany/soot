<?php

namespace App\Notifications;

use App\Services\EmailTemplateService;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class ImportantCitizenNotification extends Notification
{
    use Queueable;

    public function __construct(
        public string $title,
        public string $message,
        public string $url
    ) {
    }

    public function via(object $notifiable): array
    {
        $settings = app(\App\Settings\GeneralSettings::class);

        $channels = ['database'];

        if (
            ($settings->email_important_notifications ?? true)
            && filled($notifiable->email)
            && (EmailTemplateService::get('important_citizen_notification')?->is_enabled ?? true)
        ) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toMail(object $notifiable): MailMessage
    {
        $variables = [
            'name' => $notifiable->name ?? '',
            'email' => $notifiable->email ?? '',
            'title' => $this->title,
            'message' => $this->message,
            'url' => $this->url,
            'site_name' => app(\App\Settings\GeneralSettings::class)->site_name ?? 'منصة صوتنا',
        ];

        $template = EmailTemplateService::render(
            'important_citizen_notification',
            $variables,
            [
                'subject' => $this->title,
                'greeting' => 'مرحباً {name}،',
                'body_html' => '{message}',
                'button_text' => 'فتح الإشعار',
                'button_url' => '{url}',
                'footer' => 'هذه رسالة آلية من {site_name}.',
            ]
        );

        return (new MailMessage)
            ->subject($template['subject'] ?: $this->title)
            ->greeting($template['greeting'] ?: 'مرحباً ' . ($notifiable->name ?? ''))
            ->line($template['body_html'] ?: $this->message)
            ->when(
                filled($template['button_text']) && filled($template['button_url']),
                fn ($mail) => $mail->action($template['button_text'], $template['button_url'])
            )
            ->line($template['footer'] ?: '');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'title' => $this->title,
            'message' => $this->message,
            'url' => $this->url,
            'event' => 'important_citizen_notification',
        ];
    }
}
