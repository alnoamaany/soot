<?php

namespace App\Helper\Traits\Scopes;

use App\Models\SpatieMedia;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Support\Str;

use Spatie\MediaLibrary\InteractsWithMedia;

/**
 * @property-read SpatieMedia $image
 * @property-read ?string $primaryMediaCollection
 * @property-read ?string $primaryMediaCollectionDisk
 * @property-read ?array $allowedMimeTypes
 * @property-read ?bool $responsiveImagesEnabled
 * @property-read ?bool $isSingleMediaFile
 */
trait HasPrimaryImage
{
    use InteractsWithMedia;

    /**
     * Defining Media Collections for Images.
     */
    public function registerMediaCollections(): void
    {
        $this->registerPrimaryMediaCollection();
    }

    /**
     * Defining Media Collections for Images.
     */
    public function registerPrimaryMediaCollection(): void
    {
        $mediaCollection = $this
            ->addMediaCollection($this->getPrimaryMediaCollection())
            ->acceptsMimeTypes($this->getAllowedMimeTypes())
            ->withResponsiveImagesIf($this->getIsResponsiveImagesEnabled());

        if ($this->getPrimaryMediaCollectionDisk()) {
            $mediaCollection->useDisk($this->getPrimaryMediaCollectionDisk());
        }

        if ($this->getIsSingleMediaFile()) {
            $mediaCollection->singleFile();
        }
    }

    /**
     * Get Primary Media Collection (using class name).
     */
    public function getPrimaryMediaCollection(): string
    {
        return $this->primaryMediaCollection ?? (Str::snake(Str::pluralStudly(class_basename($this))) . '_primary_images');
    }

    /**
     * Get Primary Media Collection (using class name).
     */
    public function getIsSingleMediaFile(): bool
    {
        return $this->isSingleMediaFile ?? true;
    }

    /**
     * Get Primary Media Collection (using class name).
     */
    public function getPrimaryMediaCollectionDisk(): ?string
    {
        return $this->primaryMediaCollectionDisk ?? null;
    }

    /**
     * Get Allowed Mime Types.
     */
    public function getAllowedMimeTypes(): array
    {
        return $this->allowedMimeTypes ?? ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    }

    /**
     * Get Is Responsive Images Required.
     */
    public function getIsResponsiveImagesEnabled(): bool
    {
        return $this->responsiveImagesEnabled ?? true;
    }

    /**
     * Main Image Morph Relation.
     */
    public function image(): MorphOne
    {
        return $this->images()->one();
    }

    /**
     * Main Images Morph Relation.
     */
    public function images(): MorphMany
    {
        return $this->morphMany(config('media-library.media_model'), 'model')
            ->where('collection_name', $this->getPrimaryMediaCollection())
            ->ordered();
    }
}
