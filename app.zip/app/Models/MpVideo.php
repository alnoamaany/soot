<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class MpVideo extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    protected $fillable = [
        'mp_id', 'mp_video_category_id', 'title', 'description', 'video_url', 'is_active', 'published_at',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'published_at' => 'datetime'];
    }

    public function mp()
    {
        return $this->belongsTo(Mp::class);
    }

    public function category()
    {
        return $this->belongsTo(MpVideoCategory::class, 'mp_video_category_id');
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('thumbnail')->singleFile();
        $this->addMediaCollection('video_file')->singleFile();
    }
}
