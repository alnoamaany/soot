<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Area;
use App\Rules\EgyptianPhone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function store(Request $request)
    {
        if ($request->has('phone')) {
            $request->merge(['phone' => EgyptianPhone::normalize($request->phone)]);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => ['required', 'string', new EgyptianPhone(), 'unique:users,phone'],
            'national_id' => 'nullable|string|size:14|unique:users,national_id',
            'email' => 'required|string|email|max:255|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'city' => 'nullable|string|max:255',
            'markaz' => 'required_without:markaz_id|string|max:255',
            'area' => 'required_without:area_id|string|max:255',
            'governorate_id' => 'nullable|integer|exists:governorates,id',
            'markaz_id' => 'nullable|integer|exists:markazes,id',
            'area_id' => 'nullable|integer|exists:areas,id',
            'detailed_address' => 'nullable|string|max:1000',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'avatar' => 'nullable|image|max:2048',
            'cf-turnstile-response' => ['required', new \App\Rules\Turnstile()],
        ], [
            'name.required' => 'الاسم الكامل مطلوب.',
            'phone.required' => 'رقم الهاتف مطلوب.',
            'phone.unique' => 'رقم الهاتف المدخل مسجل مسبقاً لدينا.',
            'national_id.size' => 'الرقم القومي يجب أن يتكون من 14 رقماً.',
            'national_id.unique' => 'الرقم القومي المدخل مسجل مسبقاً لدينا.',
            'email.required' => 'البريد الإلكتروني مطلوب.',
            'email.email' => 'البريد الإلكتروني المدخل غير صحيح.',
            'email.unique' => 'البريد الإلكتروني المدخل مسجل مسبقاً لدينا.',
            'password.required' => 'كلمة المرور مطلوبة.',
            'password.min' => 'كلمة المرور يجب أن لا تقل عن 8 أحرف.',
            'password.confirmed' => 'تأكيد كلمة المرور غير متطابق.',
            'cf-turnstile-response.required' => 'يرجى تأكيد التحقق الأمني (الكابتشا).',
        ]);

        // If IDs are provided, prefer them and derive city/markaz/area names from DB
        $cityName = $request->city;
        $markazName = $request->markaz;
        $areaName = $request->area;
        $govId = $request->governorate_id;
        $markazId = $request->markaz_id;
        $areaId = $request->area_id;

        if ($govId) {
            $g = Governorate::find($govId);
            if ($g) $cityName = $g->name_ar;
        }
        if ($markazId) {
            $m = Markaz::find($markazId);
            if ($m) $markazName = $m->name_ar;
        }
        if ($areaId) {
            $a = Area::find($areaId);
            if ($a) $areaName = $a->name_ar;
        }

        $generalSettings = app(\App\Settings\GeneralSettings::class);
        $isApproved = (bool) ($generalSettings->auto_approve_citizens ?? false);

        $user = User::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'national_id' => $request->national_id ?: null,
            'email' => $request->email ?: ($request->phone . '@parliament.gov.eg'),
            'password' => Hash::make($request->password),
            'role' => 'citizen',
            'is_approved' => $isApproved,
            'city' => $cityName,
            'markaz' => $markazName,
            'area' => $areaName,
            'governorate_id' => $govId,
            'markaz_id' => $markazId,
            'area_id' => $areaId,
            'detailed_address' => $request->detailed_address,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
        ]);

        if ($request->hasFile('avatar')) {
            $user->addMediaFromRequest('avatar')->toMediaCollection('avatar');
        }

        // Send welcome email if citizen provided a valid email address
        \App\Services\WelcomeEmailService::sendWelcomeEmail($user);

        $successMessage = $isApproved
            ? 'تم إنشاء وتفعيل حسابك بنجاح! يمكنك الآن تسجيل الدخول مباشرة.'
            : 'تم إنشاء الحساب بنجاح. حسابك حالياً قيد المراجعة والموافقة من قبل إدارة المنصة وسيتم تفعيله قريباً.';

        return redirect()->route('login')->with('success', $successMessage);
    }
}

