<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AccessBan extends Model {
    protected $fillable=['ip_address','country','reason','is_active','created_by_admin_id'];
    protected $casts=['is_active'=>'boolean'];
    public function admin(){return $this->belongsTo(Admin::class,'created_by_admin_id');}
}
