<?php

namespace App\Notifications;

use App\Services\EmailTemplateService;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class AdminContentActionNotification extends Notification
{
    use Queueable;

    public function __construct(
        public string $title,
        public string $message,
        public ?string $url = null
    ) {
    }

    public function via(object $notifiable): array
    {
        $channels = ['database'];

        if (
            filled($notifiable->email)
            && (EmailTemplateService::get('admin_content_action')?->is_enabled ?? true)
        ) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toArray(object $notifiable): array
    {
        return [
            'title' => $this->title,
            'message' => $this->message,
            'url' => $this->url,
            'event' => 'admin_action',
        ];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $settings = app(\App\Settings\GeneralSettings::class);

        $template = EmailTemplateService::render(
            'admin_content_action',
            [
                'name' => $notifiable->name ?? 'مدير المنصة',
                'email' => $notifiable->email ?? '',
                'title' => $this->title,
                'message' => $this->message,
                'url' => $this->url ?? '',
                'site_name' => $settings->site_name ?? 'منصة صوتنا',
            ],
            [
                'subject' => '{title}',
                'greeting' => 'مرحبًا {name}',
                'body_html' => '{message}',
                'button_text' => 'فتح لوحة الإدارة',
                'button_url' => '{url}',
                'footer' => 'هذا إشعار إداري آلي من {site_name}.',
            ]
        );

        $mail = (new MailMessage)
            ->subject($template['subject'] ?: $this->title)
            ->greeting($template['greeting'] ?: 'مرحبًا')
            ->line($template['body_html'] ?: $this->message);

        if (filled($template['button_text']) && filled($template['button_url'])) {
            $mail->action($template['button_text'], $template['button_url']);
        }

        if (filled($template['footer'])) {
            $mail->line($template['footer']);
        }

        return $mail;
    }
}
