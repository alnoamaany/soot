<?php

namespace App\Filament\Resources\MpResource\Pages;

use App\Filament\Resources\MpResource;
use App\Models\Mp;
use App\Models\MpSubscription;
use App\Models\User;
use App\Models\Markaz;
use App\Models\Area;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CreateMp extends CreateRecord
{
    protected static string $resource = MpResource::class;

    private ?int $subscriptionPlanId = null;
    private array $userData = [];
    private ?string $avatarPath = null;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $this->subscriptionPlanId = !empty($data['subscription_plan_id']) ? (int) $data['subscription_plan_id'] : null;

        if ($this->subscriptionPlanId) {
            $plan = \App\Models\SubscriptionPlan::find($this->subscriptionPlanId);
            if ($plan) {
                if (empty($data['request_limit']) || (int)$data['request_limit'] === 0) {
                    $data['request_limit'] = (int) $plan->request_limit;
                }
                if (empty($data['limit_period'])) {
                    $data['limit_period'] = $plan->limit_period ?: 'daily';
                }
            }
        }

        $governorateName = !empty($data['user_governorate_id']) ? \App\Models\Governorate::where('id', $data['user_governorate_id'])->value('name_ar') : null;
        $markazName = !empty($data['user_markaz_id']) ? Markaz::where('id', $data['user_markaz_id'])->value('name_ar') : null;
        $areaName = !empty($data['user_area_id']) ? Area::where('id', $data['user_area_id'])->value('name_ar') : null;

        $this->userData = [
            'name' => $data['user_name'],
            'email' => $data['user_email'],
            'phone' => \App\Rules\EgyptianPhone::normalize($data['user_phone']),
            'national_id' => $data['user_national_id'] ?? null,
            'password' => $data['user_password'],
            'city' => $governorateName,
            'markaz' => $markazName,
            'area' => $areaName,
            'governorate_id' => $data['user_governorate_id'] ?? null,
            'markaz_id' => $data['user_markaz_id'] ?? null,
            'area_id' => $data['user_area_id'] ?? null,
            'detailed_address' => $data['user_detailed_address'] ?? null,
            'role' => 'mp',
            'is_approved' => true,
        ];
        $this->avatarPath = is_string($data['user_avatar'] ?? null) ? $data['user_avatar'] : null;

        $this->ensureLocationHierarchy();

        unset(
            $data['subscription_plan_id'],
            $data['user_name'],
            $data['user_email'],
            $data['user_phone'],
            $data['user_national_id'],
            $data['user_password'],
            $data['user_governorate_id'],
            $data['user_markaz_id'],
            $data['user_area_id'],
            $data['user_detailed_address'],
            $data['user_avatar'],
        );

        return $data;
    }

    private function ensureLocationHierarchy(): void
    {
        $governorateId = $this->userData['governorate_id'];
        $markazId = $this->userData['markaz_id'];
        $areaId = $this->userData['area_id'];

        if ($markazId && ! Markaz::whereKey($markazId)->where('governorate_id', $governorateId)->exists()) {
            throw ValidationException::withMessages([
                'user_markaz_id' => 'المركز المختار لا يتبع المحافظة المختارة.',
            ]);
        }

        if ($areaId && ! Area::whereKey($areaId)->where('markaz_id', $markazId)->where('governorate_id', $governorateId)->exists()) {
            throw ValidationException::withMessages([
                'user_area_id' => 'المنطقة المختارة لا تتبع المركز والمحافظة المختارين.',
            ]);
        }
    }

    protected function handleRecordCreation(array $data): Model
    {
        return DB::transaction(function () use ($data): Model {
            $user = User::create($this->userData);

            if ($this->avatarPath) {
                $user->addMediaFromDisk($this->avatarPath, 'public')->toMediaCollection('avatar');
            }

            $data['user_id'] = $user->id;

            return Mp::create($data);
        });
    }

    protected function afterCreate(): void
    {
        MpSubscription::create([
            'mp_id' => $this->record->id,
            'subscription_plan_id' => $this->subscriptionPlanId,
            'status' => 'active',
        ]);
    }
}
