<?php
namespace App\Filament\Resources\DeletedCitizenResource\Pages;
use App\Filament\Resources\DeletedCitizenResource; use Filament\Resources\Pages\ListRecords;
class ListDeletedCitizenResources extends ListRecords {protected static string $resource=DeletedCitizenResource::class;}
