<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AdminResource\Pages;
use App\Models\Admin;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Infolists\Components\SpatieMediaLibraryImageEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Components\Section;
use Illuminate\Support\Facades\Hash;

class AdminResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = Admin::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-shield-check';
    protected static ?int $navigationSort = 3;

    public static function getModelLabel(): string
    {
        return 'مدير نظام';
    }

    public static function getPluralModelLabel(): string
    {
        return 'مديرو النظام (الأدمن)';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة الحسابات';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات مدير النظام')
                ->schema([
                    TextInput::make('name')
                        ->label('الاسم الكامل')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('email')
                        ->label('البريد الإلكتروني')
                        ->email()
                        ->required()
                        ->unique(ignoreRecord: true)
                        ->maxLength(255),
                    TextInput::make('password')
                        ->label('كلمة المرور')
                        ->password()
                        ->dehydrated(fn ($state) => filled($state))
                        ->dehydrateStateUsing(fn ($state) => Hash::make($state))
                        ->required(fn (string $operation): bool => $operation === 'create')
                        ->maxLength(255),
                    TextInput::make('phone')
                        ->label('رقم الهاتف')
                        ->maxLength(64),
                    Select::make('roles')
                        ->label('الأدوار والصلاحيات (Roles)')
                        ->relationship('roles', 'name')
                        ->multiple()
                        ->preload()
                        ->searchable(),
                    Toggle::make('is_active')
                        ->label('حساب نشط ويستطيع الدخول للوحة التحكم')
                        ->default(true),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            SpatieMediaLibraryImageColumn::make('avatar')->collection('avatar')->label('الصورة'),
            TextColumn::make('name')->label('الاسم')->searchable()->sortable(),
            TextColumn::make('email')->label('البريد الإلكتروني')->searchable()->sortable(),
            TextColumn::make('phone')->label('الهاتف')->searchable(),
            TextColumn::make('roles.name')->label('الأدوار')->badge(),
            IconColumn::make('is_active')->boolean()->label('نشط'),
            TextColumn::make('created_at')->label('تاريخ الإنشاء')->dateTime()->sortable(),
        ])
        ->recordActions([
            Actions\ViewAction::make(),
            Actions\EditAction::make(),
        ])
        ->filters([]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('تفاصيل مدير النظام')
                ->schema([
                    TextEntry::make('name')->label('الاسم الكامل'),
                    TextEntry::make('email')->label('البريد الإلكتروني'),
                    TextEntry::make('phone')->label('رقم الهاتف'),
                    TextEntry::make('roles.name')->label('الأدوار والصلاحيات')->badge(),
                    TextEntry::make('is_active')
                        ->label('حالة الحساب')
                        ->formatStateUsing(fn ($state) => $state ? 'نشط ومفعل' : 'موقف'),
                    TextEntry::make('created_at')->label('تاريخ الإنشاء')->dateTime(),
                ]),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAdmins::route('/'),
            'create' => Pages\CreateAdmin::route('/create'),
            'edit' => Pages\EditAdmin::route('/{record}/edit'),
            'view' => Pages\ViewAdmin::route('/{record}'),
        ];
    }
}
