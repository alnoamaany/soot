<?php
namespace App\Filament\Resources\MpRequestResource\Pages;
use App\Filament\Resources\MpRequestResource;
use Filament\Resources\Pages\CreateRecord;
class CreateMpRequest extends CreateRecord { protected static string $resource = MpRequestResource::class; }
