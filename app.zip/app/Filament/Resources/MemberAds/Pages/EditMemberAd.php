<?php

namespace App\Filament\Resources\MemberAds\Pages;

use App\Filament\Resources\MemberAds\MemberAdResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditMemberAd extends EditRecord
{
    protected static string $resource = MemberAdResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}
