<?php
namespace App\Observers;

use App\Models\User;
use App\Services\AdminAlertService;

class UserObserver
{
    public function created(User $user): void
    {
        if (! $user->is_approved) {
            AdminAlertService::notify(
                'citizen_pending_activation',
                'مواطن جديد بحاجة إلى تفعيل الحساب',
                "تم تسجيل المواطن {$user->name} ويحتاج إلى تفعيل حسابه.",
                $user,
                meta: ['user_id' => $user->id, 'email' => $user->email, 'phone' => $user->phone],
            );
        } else {
            AdminAlertService::notify(
                'citizen_registered',
                'تسجيل مواطن جديد',
                "تم تسجيل المواطن {$user->name} وتفعيل حسابه تلقائيًا.",
                $user,
                meta: ['user_id' => $user->id],
            );
        }
    }

    public function updated(User $user): void
    {
        if ($user->wasChanged('password')) {
            AdminAlertService::notify(
                'citizen_password_changed',
                'تغيير كلمة مرور مواطن',
                "تم تغيير كلمة مرور المواطن {$user->name}.",
                $user,
                meta: ['user_id' => $user->id],
            );
        }

        if ($user->wasChanged('is_approved')) {
            AdminAlertService::notify(
                $user->is_approved ? 'citizen_approved' : 'citizen_deactivated',
                $user->is_approved ? 'تم تفعيل حساب مواطن' : 'تم إلغاء تفعيل حساب مواطن',
                $user->is_approved
                    ? "تم تفعيل حساب المواطن {$user->name}."
                    : "تم إلغاء تفعيل حساب المواطن {$user->name}.",
                $user,
                meta: ['user_id' => $user->id, 'is_approved' => (bool) $user->is_approved],
            );
        }
    }
}
