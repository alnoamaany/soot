<?php
namespace App\Filament\Pages;
use App\Settings\GeneralSettings;
use Filament\Pages\SettingsPage;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
class ManageGoogleAds extends SettingsPage {
 protected static string $settings=GeneralSettings::class;
 public static function getNavigationIcon():string{return 'heroicon-o-megaphone';}
 public static function getNavigationGroup():?string{return 'الدعاية والإعلان';}
 public static function getNavigationSort():?int{return 2;}
 public static function getNavigationLabel():string{return 'إعلانات جوجل (Google Ads)';}
 public function getTitle():string{return 'إعلانات جوجل (Google Ads)';}
 public function form(Schema $schema):Schema{return $schema->components([
  Section::make('Google AdSense')->schema([
   Toggle::make('google_adsense_enabled')->label('تفعيل Google AdSense'),
   Toggle::make('google_ads_auto_ads')->label('الإعلانات التلقائية'),
   TextInput::make('google_adsense_client_id')->label('Publisher / Client ID'),
   TextInput::make('google_ad_slot_top')->label('Slot أعلى الصفحة'),
   TextInput::make('google_ad_slot_sidebar')->label('Slot جانبي'),
   TextInput::make('google_ad_slot_in_article')->label('Slot داخل المقال'),
   TextInput::make('google_ad_slot_footer')->label('Slot الفوتر'),
   Textarea::make('google_ads_header_code')->label('كود AdSense المخصص')->rows(7)->columnSpanFull(),
  ])->columns(2)
 ]);}
}