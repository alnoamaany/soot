<?php

namespace App\Providers\Filament;

use Filament\Support\Enums\Width;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages\Dashboard;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Widgets\AccountWidget;
use Filament\Widgets\FilamentInfoWidget;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

use BezhanSalleh\FilamentShield\FilamentShieldPlugin;
use Filament\View\PanelsRenderHook;
use Illuminate\Support\Facades\Blade;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->maxContentWidth(Width::Full)
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->authGuard('admin')
            ->colors([
                'primary' => Color::Amber,
            ])
            ->renderHook(
                PanelsRenderHook::HEAD_END,
                fn (): string => Blade::render('
                    <link rel="preconnect" href="https://fonts.googleapis.com">
                    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
                    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
                    <link rel="stylesheet" href="{{ versioned_asset(\'css/filament-custom.css\') }}" />
                    <style>
                        * { font-family: "Tajawal", sans-serif; }
                        .material-symbols-outlined { font-family: "Material Symbols Outlined" !important; font-style: normal; }
                        /* Dark Mode Styling */
                        .dark body.fi-body {
                            background: linear-gradient(135deg, #0B0707 0%, #1c1414 35%, #180e22 70%, #0c0e18 100%) !important;
                            background-attachment: fixed !important;
                            color: #e2e8f0 !important;
                        }
                        .dark .fi-sidebar {
                            background: linear-gradient(180deg, rgba(11, 7, 7, 0.96) 0%, rgba(18, 14, 14, 0.98) 100%) !important;
                            border-inline-end-color: rgba(200, 168, 75, 0.25) !important;
                        }
                        .dark .fi-topbar {
                            background: rgba(11, 7, 7, 0.85) !important;
                            backdrop-filter: blur(16px) !important;
                            border-bottom-color: rgba(200, 168, 75, 0.25) !important;
                        }
                        .dark .fi-main {
                            background: transparent !important;
                        }
                        .dark .fi-section, .dark .fi-widget, .dark .fi-ta-ctn, .dark .fi-sc-ctn {
                            background: rgba(18, 14, 14, 0.8) !important;
                            backdrop-filter: blur(12px) !important;
                            border: 1px solid rgba(200, 168, 75, 0.2) !important;
                            box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.6) !important;
                        }

                        /* Light Mode Styling */
                        html:not(.dark) body.fi-body {
                            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 50%, #e2e8f0 100%) !important;
                            background-attachment: fixed !important;
                            color: #0f172a !important;
                        }
                        html:not(.dark) .fi-sidebar {
                            background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%) !important;
                            border-inline-end-color: rgba(200, 168, 75, 0.3) !important;
                        }
                        html:not(.dark) .fi-topbar {
                            background: rgba(255, 255, 255, 0.9) !important;
                            backdrop-filter: blur(16px) !important;
                            border-bottom-color: rgba(200, 168, 75, 0.3) !important;
                        }
                        html:not(.dark) .fi-main {
                            background: transparent !important;
                        }
                        html:not(.dark) .fi-section, 
                        html:not(.dark) .fi-widget, 
                        html:not(.dark) .fi-ta-ctn, 
                        html:not(.dark) .fi-sc-ctn {
                            background: rgba(255, 255, 255, 0.95) !important;
                            border: 1px solid rgba(200, 168, 75, 0.25) !important;
                            box-shadow: 0 4px 20px -5px rgba(0, 0, 0, 0.08) !important;
                        }
                    </style>
                ')
            )
            ->plugins([
                FilamentShieldPlugin::make(),
            ])
            ->navigationGroups([
                \Filament\Navigation\NavigationGroup::make()
                    ->label('التقارير والإحصائيات البرلمانية')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('طلبات المواطنين')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('إدارة المستخدمين والأعضاء')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('الاستطلاعات والتفاعلات')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('المركز الإعلامي')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('المحتوى والوسائط')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('إدارة الجغرافيا والمناطق')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('الاشتراكات')
                    ->collapsed(false),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('إعدادات الطلبات')
                    ->collapsed(true),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('الدعم والاتصالات')
                    ->collapsed(true),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('الدعم والدليل')
                    ->collapsed(true),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('إدارة الحسابات')
                    ->collapsed(true),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('إدارة الوصول')
                    ->collapsed(true),
                \Filament\Navigation\NavigationGroup::make()
                    ->label('الإعدادات')
                    ->collapsed(true),
            ])
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\Filament\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\Filament\Pages')
            ->pages([
                Dashboard::class,
                \App\Filament\Pages\Reports\GeneralExecutiveReport::class,
                \App\Filament\Pages\Reports\RequestsReport::class,
                \App\Filament\Pages\Reports\MpsPerformanceReport::class,
                \App\Filament\Pages\Reports\SubscriptionsFinancialReport::class,
                \App\Filament\Pages\Reports\GeographicDistributionReport::class,
                \App\Filament\Pages\Reports\MediaAndVideosReport::class,
                \App\Filament\Pages\Reports\PollsAndVotesReport::class,
                \App\Filament\Pages\Reports\CitizensReport::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\Filament\Widgets')
            ->widgets([
                \App\Filament\Widgets\ReportsHubWidget::class,
                \App\Filament\Widgets\AdminStatsOverview::class,
                \App\Filament\Widgets\RequestsStatusChart::class,
                \App\Filament\Widgets\UsersGovernorateChart::class,
                \App\Filament\Widgets\LatestRequestsWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                PreventRequestForgery::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }
}
