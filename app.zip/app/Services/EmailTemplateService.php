<?php

namespace App\Services;

use App\Models\EmailTemplate;

class EmailTemplateService
{
    public static function get(string $key): ?EmailTemplate
    {
        return EmailTemplate::where('key', $key)->first();
    }

    public static function render(
        string $key,
        array $variables = [],
        array $defaults = []
    ): array {
        $template = self::get($key);

        $values = [];
        foreach ($variables as $name => $value) {
            $values['{' . $name . '}'] = (string) ($value ?? '');
        }

        $replace = static function (?string $text) use ($values): ?string {
            if ($text === null) {
                return null;
            }

            return strtr($text, $values);
        };

        return [
            'enabled' => $template?->is_enabled ?? true,
            'subject' => $replace(
                $template?->subject ?? $defaults['subject'] ?? ''
            ),
            'greeting' => $replace(
                $template?->greeting ?? $defaults['greeting'] ?? ''
            ),
            'body_html' => $replace(
                $template?->body_html ?? $defaults['body_html'] ?? ''
            ),
            'button_text' => $replace(
                $template?->button_text ?? $defaults['button_text'] ?? ''
            ),
            'button_url' => $replace(
                $template?->button_url ?? $defaults['button_url'] ?? ''
            ),
            'footer' => $replace(
                $template?->footer ?? $defaults['footer'] ?? ''
            ),
        ];
    }

    public static function variables(array $variables): string
    {
        return implode(', ', array_map(
            fn ($key) => '{' . $key . '}',
            array_keys($variables)
        ));
    }
}
