<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;

#[Fillable(['user_id', 'title', 'party', 'district', 'reception_hours', 'bio', 'is_active', 'is_featured', 'request_limit', 'limit_period', 'followers_stat_mode', 'followers_stat_manual', 'completed_requests_stat_mode', 'completed_requests_stat_manual', 'recorded_videos_stat_mode', 'recorded_videos_stat_manual', 'response_rate_stat_mode', 'response_rate_stat_manual'])]
class Mp extends Model 
{
    use HasFactory;

    /**
     * Get the user that owns the MP profile.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /** The public name, with the optional title shown after name with a dash. */
    public function getDisplayNameAttribute(): string
    {
        $name = trim($this->user?->name ?? '');
        $title = trim($this->title ?? '');

        if ($name !== '' && $title !== '') {
            return "{$name} - {$title}";
        }

        return $name !== '' ? $name : $title;
    }

    /**
     * The followers (citizens) of this MP.
     */
    public function followers()
    {
        return $this->belongsToMany(User::class, 'mp_followers', 'mp_id', 'user_id')->withTimestamps();
    }

    /**
     * The requests directed to this MP.
     */
    public function requests()
    {
        return $this->hasMany(MpRequest::class, 'mp_id');
    }

    public function libraryVideos()
    {
        return $this->hasMany(Library::class, 'mp_id');
    }

    public function videos()
    {
        return $this->hasMany(MpVideo::class, 'mp_id');
    }

    public function videoCategories()
    {
        return $this->hasMany(MpVideoCategory::class, 'mp_id');
    }

    public function platformMessages()
    {
        return $this->hasMany(PlatformMessage::class, 'mp_id');
    }

    public function subscriptions()
    {
        return $this->hasMany(MpSubscription::class, 'mp_id');
    }

    public function posts()
    {
        return $this->hasMany(Post::class, 'mp_id');
    }

    public function polls()
    {
        return $this->hasMany(Poll::class, 'mp_id');
    }

    public function activeSubscription()
    {
        return $this->hasOne(MpSubscription::class)
            ->where('status', 'active')
            ->where(function ($query) {
                $query->whereNull('ends_at')->orWhereDate('ends_at', '>=', today());
            })
            ->latestOfMany('ends_at');
    }

    /**
     * Check if MP has an active, non-expired subscription.
     */
    public function hasValidSubscription(): bool
    {
        return $this->subscriptions()
            ->where('status', 'active')
            ->where(function ($query) {
                $query->whereNull('ends_at')->orWhereDate('ends_at', '>=', today());
            })
            ->exists();
    }

    /** Whether the active plan permits a feature for this member. */
    public function canUseFeature(string $feature): bool
    {
        $column = [
            'polls' => 'allows_polls',
            'videos' => 'allows_videos',
            'news' => 'allows_news',
        ][$feature] ?? null;

        if (! $column) {
            return false;
        }

        return $this->activeSubscription()
            ->whereHas('plan', fn ($query) => $query->where($column, true))
            ->exists();
    }

    /**
     * Get effective request limit from active subscription plan and MP customization.
     */
    public function getEffectiveRequestLimit(): int
    {
        $plan = $this->activeSubscription?->plan;
        $planLimit = $plan ? (int) ($plan->request_limit ?? 0) : 0;
        $mpLimit = $this->request_limit !== null ? (int) $this->request_limit : 0;

        // If the subscription plan defines a specific limit (> 0)
        if ($planLimit > 0) {
            if ($mpLimit > 0) {
                // If MP specified a custom limit, cap it at the plan's maximum limit
                return min($mpLimit, $planLimit);
            }
            return $planLimit;
        }

        // If the plan allows unlimited (0) or no plan, return MP's custom limit
        return $mpLimit;
    }

    /**
     * Get effective limit period from active subscription plan or MP settings.
     */
    public function getEffectiveLimitPeriod(): string
    {
        $plan = $this->activeSubscription?->plan;
        if ($plan && !empty($plan->limit_period) && (int) ($plan->request_limit ?? 0) > 0) {
            return $plan->limit_period;
        }

        if (!empty($this->limit_period)) {
            return $this->limit_period;
        }

        if ($plan && !empty($plan->limit_period)) {
            return $plan->limit_period;
        }

        return 'daily';
    }

    /**
     * Check if MP reached request limit for the period.
     */
    public function hasReachedRequestLimit(): bool
    {
        $limit = $this->getEffectiveRequestLimit();
        if ($limit <= 0) {
            return false;
        }

        $period = $this->getEffectiveLimitPeriod();
        $periodStart = match ($period) {
            'weekly' => now()->startOfWeek(),
            'monthly' => now()->startOfMonth(),
            default => now()->startOfDay(),
        };

        $count = $this->requests()->where('created_at', '>=', $periodStart)->count();

        return $count >= $limit;
    }

    /**
     * Get human-readable Arabic time remaining until request limit reset.
     */
    public function getTimeUntilLimitReset(): string
    {
        $period = $this->getEffectiveLimitPeriod();
        $resetTime = match ($period) {
            'weekly' => now()->endOfWeek(),
            'monthly' => now()->endOfMonth(),
            default => now()->endOfDay(),
        };

        $diff = now()->diff($resetTime);

        $parts = [];
        if ($diff->d > 0) {
            $parts[] = $diff->d . ' ' . ($diff->d === 1 ? 'يوم' : ($diff->d === 2 ? 'يومين' : ($diff->d <= 10 ? 'أيام' : 'يوم')));
        }
        if ($diff->h > 0) {
            $parts[] = $diff->h . ' ' . ($diff->h === 1 ? 'ساعة' : ($diff->h === 2 ? 'ساعتين' : ($diff->h <= 10 ? 'ساعات' : 'ساعة')));
        }
        if (empty($parts) && $diff->i > 0) {
            $parts[] = $diff->i . ' ' . ($diff->i === 1 ? 'دقيقة' : ($diff->i === 2 ? 'دقيقتين' : ($diff->i <= 10 ? 'دقائق' : 'دقيقة')));
        }

        return !empty($parts) ? implode(' و ', $parts) : 'قريباً جداً';
    }
}
