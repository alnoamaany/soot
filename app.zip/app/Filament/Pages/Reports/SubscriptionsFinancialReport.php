<?php

namespace App\Filament\Pages\Reports;

use App\Models\MpSubscription;
use App\Models\SubscriptionPlan;
use Filament\Pages\Page;
use Livewire\WithPagination;

class SubscriptionsFinancialReport extends Page
{
    use WithPagination;

    protected string $view = 'filament.pages.reports.subscriptions-financial-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-banknotes';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 4;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير الاشتراكات والإيرادات';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير الاشتراكات البرلمانية والإيرادات المالية';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير الاشتراكات والإيرادات';
    }

    public ?string $planId = 'all';
    public ?string $status = 'all';
    public int $perPage = 25;

    public function updatingPlanId(): void { $this->resetPage(); }
    public function updatingStatus(): void { $this->resetPage(); }
    public function updatingPerPage(): void { $this->resetPage(); }

    public function resetFilters(): void
    {
        $this->planId = 'all';
        $this->status = 'all';
        $this->perPage = 25;
        $this->resetPage();
    }

    public function getViewData(): array
    {
        $baseQuery = MpSubscription::query();

        if ($this->planId && $this->planId !== 'all') {
            $baseQuery->where('subscription_plan_id', $this->planId);
        }
        if ($this->status && $this->status !== 'all') {
            $baseQuery->where('status', $this->status);
        }

        // DB level metrics calculation
        $totalRevenue = (clone $baseQuery)->where('status', 'active')->sum('price');
        $activeCount = (clone $baseQuery)->where('status', 'active')->count();
        $expiredCount = (clone $baseQuery)->where('status', 'expired')->count();

        // Paginated subscriptions list
        $subscriptions = (clone $baseQuery)
            ->with(['mp.user', 'plan'])
            ->latest('starts_at')
            ->paginate($this->perPage);

        $plansList = SubscriptionPlan::select('id', 'name')->get();

        // Revenue Breakdown per Plan
        $plansRevenue = SubscriptionPlan::withCount(['subscriptions' => fn ($q) => $q->where('status', 'active')])
            ->get()
            ->map(function ($plan) {
                return [
                    'name' => $plan->name,
                    'price' => $plan->price,
                    'duration' => $plan->duration_months,
                    'active_count' => $plan->subscriptions_count,
                    'total' => $plan->subscriptions_count * $plan->price,
                ];
            });

        return [
            'subscriptions' => $subscriptions,
            'totalRevenue' => $totalRevenue,
            'activeCount' => $activeCount,
            'expiredCount' => $expiredCount,
            'plansList' => $plansList,
            'plansRevenue' => $plansRevenue,
        ];
    }
}
