<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MarkazResource\Pages;
use App\Models\Markaz;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Schemas\Components\Section;

class MarkazResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = Markaz::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-building-office-2';

    protected static ?int $navigationSort = 2;

    public static function getModelLabel(): string
    {
        return 'مركز / قسم';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المراكز والأقسام';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة الجغرافيا والمناطق';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات المركز / القسم')
                ->schema([
                    Select::make('governorate_id')
                        ->label('المحافظة التابع لها')
                        ->relationship('governorate', 'name_ar')
                        ->searchable()
                        ->preload()
                        ->required(),

                    TextInput::make('name_ar')
                        ->label('اسم المركز / القسم (بالعربية)')
                        ->required()
                        ->maxLength(255)
                        ->unique(
                            table: 'markazes',
                            column: 'name_ar',
                            ignoreRecord: true,
                            modifyRuleUsing: function ($rule, $get) {
                                $govId = $get('governorate_id');
                                return $govId ? $rule->where('governorate_id', $govId) : $rule;
                            }
                        )
                        ->validationMessages([
                            'unique' => 'اسم المركز أو القسم مسجل مسبقاً في هذه المحافظة.',
                        ]),

                    TextInput::make('name_en')
                        ->label('اسم المركز / القسم (بالإنجليزية)')
                        ->maxLength(255),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('#')
                    ->sortable(),

                TextColumn::make('name_ar')
                    ->label('المركز / القسم (بالعربية)')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),

                TextColumn::make('governorate.name_ar')
                    ->label('المحافظة')
                    ->searchable()
                    ->sortable()
                    ->badge(),

                TextColumn::make('name_en')
                    ->label('بالإنجليزية')
                    ->searchable()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('areas_count')
                    ->label('عدد المناطق/الأحياء التابعة')
                    ->counts('areas')
                    ->badge()
                    ->color('success'),

                TextColumn::make('created_at')
                    ->label('تاريخ الإنشاء')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('governorate_id')
                    ->label('تصفية حسب المحافظة')
                    ->relationship('governorate', 'name_ar')
                    ->searchable()
                    ->preload(),
            ])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMarkazes::route('/'),
            'create' => Pages\CreateMarkaz::route('/create'),
            'edit' => Pages\EditMarkaz::route('/{record}/edit'),
        ];
    }
}
