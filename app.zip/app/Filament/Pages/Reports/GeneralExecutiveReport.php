<?php

namespace App\Filament\Pages\Reports;

use App\Models\Area;
use App\Models\Governorate;
use App\Models\Library;
use App\Models\Markaz;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\MpSubscription;
use App\Models\MpVideo;
use App\Models\Poll;
use App\Models\PollOption;
use App\Models\PollVote;
use App\Models\RequestStatus;
use App\Models\SubscriptionPlan;
use App\Models\User;
use Filament\Pages\Page;

class GeneralExecutiveReport extends Page
{
    protected string $view = 'filament.pages.reports.general-executive-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-presentation-chart-line';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 1;
    }

    public static function getNavigationLabel(): string
    {
        return 'التقرير التنفيذي الشامل';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'التقرير التنفيذي الشامل للمنصة';
    }

    public static function getBreadcrumb(): string
    {
        return 'التقرير التنفيذي الشامل';
    }

    public ?string $dateFrom = null;
    public ?string $dateTo = null;
    public ?string $governorate = 'all';

    public function mount(): void
    {
        $this->dateFrom = now()->subYear()->format('Y-m-d');
        $this->dateTo = now()->format('Y-m-d');
    }

    public function resetFilters(): void
    {
        $this->dateFrom = now()->subYear()->format('Y-m-d');
        $this->dateTo = now()->format('Y-m-d');
        $this->governorate = 'all';
    }

    public function getViewData(): array
    {
        $reqQuery = MpRequest::query();
        if ($this->dateFrom) {
            $reqQuery->whereDate('created_at', '>=', $this->dateFrom);
        }
        if ($this->dateTo) {
            $reqQuery->whereDate('created_at', '<=', $this->dateTo);
        }
        if ($this->governorate && $this->governorate !== 'all') {
            $reqQuery->whereHas('user', function ($q) {
                $q->where('city', $this->governorate)
                    ->orWhereHas('governorate', fn ($g) => $g->where('name_ar', $this->governorate));
            });
        }

        $totalRequests = (clone $reqQuery)->count();
        $completedRequests = (clone $reqQuery)->where(function ($q) {
            $q->where('status', 'completed')
                ->orWhereHas('requestStatus', fn ($s) => $s->where('name', 'like', '%مكتمل%'));
        })->count();
        $inProgressRequests = (clone $reqQuery)->where(function ($q) {
            $q->whereIn('status', ['in_progress', 'approved', 'received', 'final_review'])
                ->orWhereHas('requestStatus', fn ($s) => $s->where('name', 'not like', '%مكتمل%'));
        })->count();

        $completionRate = $totalRequests > 0 ? round(($completedRequests / $totalRequests) * 100, 1) : 0;

        // MPs Stats
        $totalMps = Mp::count();
        $activeMps = Mp::where('is_active', true)->count();
        $featuredMps = Mp::where('is_featured', true)->count();

        // Subscriptions & Financials
        $totalRevenue = MpSubscription::where('status', 'active')->sum('price');
        $activeSubscriptions = MpSubscription::where('status', 'active')->count();

        // Users & Citizens
        $totalCitizens = User::where('role', 'citizen')->count();
        $verifiedCitizens = User::where('role', 'citizen')->whereNotNull('email_verified_at')->count();

        // Videos & Multimedia
        $totalVideos = MpVideo::count();
        $totalLibraryItems = Library::count();

        // Polls & Votes
        $totalPolls = Poll::count();
        $totalVotes = (int) PollOption::sum('votes_count') + (int) PollVote::count();

        // Governorates breakdown
        $governoratesList = Governorate::orderBy('name_ar')->get(['id', 'name_ar']);
        $topGovernorates = Governorate::withCount(['users', 'areas'])
            ->orderByDesc('users_count')
            ->take(8)
            ->get();

        // Requests by Status breakdown
        $statusBreakdown = RequestStatus::withCount(['requests' => function ($q) {
            if ($this->dateFrom) $q->whereDate('created_at', '>=', $this->dateFrom);
            if ($this->dateTo) $q->whereDate('created_at', '<=', $this->dateTo);
        }])->get();

        // Top Performing MPs with database ordering and limit
        $topMps = Mp::with(['user.governorate'])
            ->withCount(['requests', 'followers', 'videos'])
            ->orderByDesc('requests_count')
            ->take(6)
            ->get();

        return [
            'totalRequests' => $totalRequests,
            'completedRequests' => $completedRequests,
            'inProgressRequests' => $inProgressRequests,
            'completionRate' => $completionRate,
            'totalMps' => $totalMps,
            'activeMps' => $activeMps,
            'featuredMps' => $featuredMps,
            'totalRevenue' => $totalRevenue,
            'activeSubscriptions' => $activeSubscriptions,
            'totalCitizens' => $totalCitizens,
            'verifiedCitizens' => $verifiedCitizens,
            'totalVideos' => $totalVideos,
            'totalLibraryItems' => $totalLibraryItems,
            'totalPolls' => $totalPolls,
            'totalVotes' => $totalVotes,
            'governoratesList' => $governoratesList,
            'topGovernorates' => $topGovernorates,
            'statusBreakdown' => $statusBreakdown,
            'topMps' => $topMps,
        ];
    }
}
