<?php

namespace App\Filament\Resources\PendingCitizenResource\Pages;

use App\Filament\Resources\PendingCitizenResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewPendingCitizen extends ViewRecord
{
    protected static string $resource = PendingCitizenResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('approve')
                ->label('اعتماد وتفعيل الحساب')
                ->icon('heroicon-o-check-circle')
                ->color('success')
                ->requiresConfirmation()
                ->modalHeading('اعتماد حساب المواطن')
                ->modalDescription(fn () => "هل أنت متأكد من اعتماد حساب ({$this->record->name})؟")
                ->action(function (): void {
                    $this->record->update(['is_approved' => true]);
                    $this->notify('success', 'تم اعتماد وتفعيل الحساب بنجاح.');
                    $this->redirect(PendingCitizenResource::getUrl('index'));
                }),
            Actions\EditAction::make(),
            Actions\DeleteAction::make()->label('رفض وحذف'),
        ];
    }
}
