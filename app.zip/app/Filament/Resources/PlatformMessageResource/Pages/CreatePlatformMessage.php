<?php
namespace App\Filament\Resources\PlatformMessageResource\Pages;
use App\Filament\Resources\PlatformMessageResource;
use App\Models\Admin;
use App\Models\User;
use App\Notifications\PlatformMessageNotification;
use Filament\Resources\Pages\CreateRecord;
class CreatePlatformMessage extends CreateRecord {
 protected static string $resource=PlatformMessageResource::class;
 protected function mutateFormDataBeforeCreate(array $data):array{$kind=$data['recipient_kind']??'user';unset($data['recipient_kind']);$data['recipient_type']=$kind==='admin'?Admin::class:User::class;$data['sender_type']=Admin::class;$data['sender_id']=auth('admin')->id();return $data;}
 protected function afterCreate():void{$r=$this->record->recipient;if($r){$url=$r instanceof User?route('member.messages'):url('/admin/platform-messages');$r->notify(new PlatformMessageNotification($this->record->subject?:'رسالة جديدة',$this->record->message,$url));}}
}
