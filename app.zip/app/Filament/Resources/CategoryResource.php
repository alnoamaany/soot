<?php

namespace App\Filament\Resources;

use App\Filament\Resources\CategoryResource\Pages;
use App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
use App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
use App\Models\Category;
use App\Rules\NoBlockedWords;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Infolists\Components\TextEntry;
use Illuminate\Validation\ValidationException;

class CategoryResource extends Resource
{
    use FilamentTranslatedLabelResource;
    use FilamentCountBadgeResource;

    protected static ?string $model = Category::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-tag';
    protected static ?int $navigationSort = 1;

    public static function getModelLabel(): string { return 'تصنيف'; }
    public static function getPluralModelLabel(): string { return 'التصنيفات'; }
    public static function getNavigationGroup(): ?string { return 'المركز الإعلامي'; }

    private static function parentOptions(?Category $record = null): array
    {
        $all = Category::query()->orderBy('sort_order')->orderBy('name')->get();
        $excluded = [];

        if ($record) {
            $excluded[] = $record->id;
            $pending = [$record->id];
            while ($pending) {
                $parentId = array_pop($pending);
                $children = $all->where('parent_id', $parentId)->pluck('id')->all();
                foreach ($children as $childId) {
                    $excluded[] = $childId;
                    $pending[] = $childId;
                }
            }
        }

        $options = [];
        $add = function ($parentId, string $prefix = '') use (&$add, &$options, $all, $excluded): void {
            foreach ($all->where('parent_id', $parentId)->sortBy([['sort_order', 'asc'], ['name', 'asc']]) as $category) {
                if (in_array($category->id, $excluded, true)) {
                    continue;
                }
                $options[$category->id] = $prefix . $category->name;
                $add($category->id, $prefix . '— ');
            }
        };

        $add(null);
        return $options;
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Grid::make(['default' => 1, 'md' => 1, 'xl' => 12])->schema([
                Section::make('معلومات التصنيف')
                    ->description('البيانات الأساسية للتصنيف')
                    ->schema([
                        TextInput::make('name')
                            ->label('اسم التصنيف')
                            ->required()
                            ->maxLength(255)
                            ->rules([new NoBlockedWords()]),
                        Textarea::make('description')
                            ->label('وصف التصنيف')
                            ->rows(5)
                            ->maxLength(65535)
                            ->rules([new NoBlockedWords()]),
                    ])
                    ->columns(1)
                    ->columnSpan(['xl' => 7]),
                Section::make('هيكل وترتيب التصنيف')
                    ->description('حدد التصنيف الأب ورقم الظهور والرابط المختصر')
                    ->schema([
                        Select::make('parent_id')
                            ->label('التصنيف الأب')
                            ->options(fn (?Category $record): array => static::parentOptions($record))
                            ->searchable()
                            ->preload()
                            ->nullable()
                            ->placeholder('تصنيف رئيسي — بدون أب')
                            ->helperText('اتركه فارغاً لإنشاء تصنيف رئيسي. يمكن إنشاء تصنيف فرعي باختيار تصنيف أب.')
                            ->columnSpanFull(),
                        Grid::make(['default' => 1, 'md' => 2])->schema([
                            TextInput::make('sort_order')
                                ->label('الترتيب')
                                ->numeric()
                                ->integer()
                                ->minValue(1)
                                ->default(fn (): int => (int) Category::query()->max('sort_order') + 1)
                                ->required()
                                ->unique(ignoreRecord: true)
                                ->helperText('رقم فريد لا يتكرر داخل هذا النوع من التصنيفات، والأرقام الأصغر تظهر أولاً.'),
                            TextInput::make('slug')
                                ->label('الرابط المختصر')
                                ->helperText('يُنشأ تلقائياً من الاسم إذا تُرك فارغاً.')
                                ->maxLength(255)
                                ->unique(ignoreRecord: true),
                        ])->columnSpanFull(),
                    ])
                    ->columns(1)
                    ->columnSpan(['xl' => 5]),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('sort_order')
            ->reorderable('sort_order')
            ->columns([
                TextColumn::make('sort_order')->label('الترتيب')->sortable()->badge(),
                TextColumn::make('name')->label('التصنيف')->searchable()->sortable(),
                TextColumn::make('parent.name')->label('التصنيف الأب')->placeholder('رئيسي')->searchable(),
                TextColumn::make('children_count')->label('التصنيفات الفرعية')->counts('children')->badge()->sortable(),
                TextColumn::make('posts_count')->label('عدد المحتوى')->counts('posts')->badge()->sortable(),
                TextColumn::make('slug')->label('الرابط')->searchable()->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('created_at')->label('تاريخ الإنشاء')->dateTime()->sortable()->toggleable(isToggledHiddenByDefault: true),
            ])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make()->before(function (Category $record): void {
                    if ($record->children()->exists() || $record->posts()->exists()) {
                        throw ValidationException::withMessages([
                            'record' => 'لا يمكن حذف هذا التصنيف لأنه يحتوي على تصنيفات فرعية أو محتوى مرتبط به. انقل المحتوى والتصنيفات الفرعية أولاً.',
                        ]);
                    }
                }),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('معلومات التصنيف')->columns(3)->schema([
                TextEntry::make('name')->label('اسم التصنيف'),
                TextEntry::make('parent.name')->label('التصنيف الأب')->placeholder('تصنيف رئيسي'),
                TextEntry::make('sort_order')->label('الترتيب'),
                TextEntry::make('slug')->label('الرابط'),
                TextEntry::make('children_count')->label('التصنيفات الفرعية')->state(fn (Category $record): int => $record->children()->count()),
                TextEntry::make('posts_count')->label('عدد المحتوى')->state(fn (Category $record): int => $record->posts()->count()),
                TextEntry::make('description')->label('الوصف')->placeholder('لا يوجد وصف')->columnSpanFull(),
            ]),
        ]);
    }

    public static function getRelations(): array { return []; }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCategories::route('/'),
            'create' => Pages\CreateCategory::route('/create'),
            'edit' => Pages\EditCategory::route('/{record}/edit'),
            'view' => Pages\ViewCategory::route('/{record}'),
        ];
    }
}
