<?php
namespace App\Filament\Resources\RequestPriorityResource\Pages;
use App\Filament\Resources\RequestPriorityResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
class ListRequestPriorities extends ListRecords { protected static string $resource = RequestPriorityResource::class; protected function getHeaderActions(): array { return [Actions\CreateAction::make()]; } }
