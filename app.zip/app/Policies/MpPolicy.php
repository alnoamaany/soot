<?php

declare(strict_types=1);

namespace App\Policies;

use Illuminate\Foundation\Auth\User as AuthUser;
use App\Models\Mp;
use Illuminate\Auth\Access\HandlesAuthorization;

class MpPolicy
{
    use HandlesAuthorization;
    
    public function viewAny(AuthUser $authUser): bool
    {
        return $authUser->can('ViewAny:Mp');
    }

    public function view(AuthUser $authUser, Mp $mp): bool
    {
        return $authUser->can('View:Mp');
    }

    public function create(AuthUser $authUser): bool
    {
        return $authUser->can('Create:Mp');
    }

    public function update(AuthUser $authUser, Mp $mp): bool
    {
        return $authUser->can('Update:Mp');
    }

    public function delete(AuthUser $authUser, Mp $mp): bool
    {
        return $authUser->can('Delete:Mp');
    }

    public function deleteAny(AuthUser $authUser): bool
    {
        return $authUser->can('DeleteAny:Mp');
    }

    public function restore(AuthUser $authUser, Mp $mp): bool
    {
        return $authUser->can('Restore:Mp');
    }

    public function forceDelete(AuthUser $authUser, Mp $mp): bool
    {
        return $authUser->can('ForceDelete:Mp');
    }

    public function forceDeleteAny(AuthUser $authUser): bool
    {
        return $authUser->can('ForceDeleteAny:Mp');
    }

    public function restoreAny(AuthUser $authUser): bool
    {
        return $authUser->can('RestoreAny:Mp');
    }

    public function replicate(AuthUser $authUser, Mp $mp): bool
    {
        return $authUser->can('Replicate:Mp');
    }

    public function reorder(AuthUser $authUser): bool
    {
        return $authUser->can('Reorder:Mp');
    }

}