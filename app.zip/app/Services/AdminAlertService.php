<?php

namespace App\Services;

use App\Models\Admin;
use App\Notifications\AdminActivityNotification;
use App\Settings\GeneralSettings;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\AnonymousNotifiable;
use Illuminate\Support\Facades\Log;
use Throwable;

class AdminAlertService
{
    public static function notify(
        string $event,
        string $title,
        string $message,
        ?Model $subject = null,
        ?string $url = null,
        array $meta = [],
    ): void {
        try {
            $settings = app(GeneralSettings::class);

            $databaseEnabled = (bool) ($settings->admin_notifications_enabled ?? true);
            $emailEnabled = (bool) ($settings->admin_email_notifications_enabled ?? true);
            $notificationEmail = trim((string) ($settings->admin_notification_email ?? ''));

            if (! $databaseEnabled && ! $emailEnabled) {
                return;
            }

            $resolvedUrl = $url ?: self::resolveUrl($subject);

            // حفظ الإشعار داخل لوحة الإدارة لكل مدير نشط.
            if ($databaseEnabled) {
                $databaseNotification = new AdminActivityNotification(
                    event: $event,
                    title: $title,
                    message: $message,
                    url: $resolvedUrl,
                    meta: $meta,
                    sendEmail: false,
                    saveToDatabase: true,
                );

                Admin::query()
                    ->where('is_active', true)
                    ->each(function (Admin $admin) use ($databaseNotification): void {
                        $admin->notify($databaseNotification);
                    });
            }

            // إذا تم تحديد بريد مركزي في الإعدادات، استخدمه وحده.
            if ($emailEnabled && filled($notificationEmail)) {
                $emailNotification = new AdminActivityNotification(
                    event: $event,
                    title: $title,
                    message: $message,
                    url: $resolvedUrl,
                    meta: $meta,
                    sendEmail: true,
                    saveToDatabase: false,
                );

                (new AnonymousNotifiable())->route('mail', $notificationEmail)
                    ->notify($emailNotification);

                return;
            }

            // توافق رجعي: إذا لم يتم تحديد بريد مركزي بعد،
            // يستمر السلوك السابق بإرسال البريد للمديرين النشطين.
            if ($emailEnabled) {
                $fallbackNotification = new AdminActivityNotification(
                    event: $event,
                    title: $title,
                    message: $message,
                    url: $resolvedUrl,
                    meta: $meta,
                    sendEmail: true,
                    saveToDatabase: false,
                );

                Admin::query()
                    ->where('is_active', true)
                    ->whereNotNull('email')
                    ->where('email', '!=', '')
                    ->each(function (Admin $admin) use ($fallbackNotification): void {
                        $admin->notify($fallbackNotification);
                    });
            }
        } catch (Throwable $e) {
            // فشل التنبيه لا يجب أن يمنع العملية الأصلية من الاكتمال.
            Log::error('Admin alert failed.', [
                'event' => $event,
                'error' => $e->getMessage(),
            ]);
        }
    }

    private static function resolveUrl(?Model $subject): ?string
    {
        if (! $subject) {
            return null;
        }

        $resource = match ($subject::class) {
            \App\Models\User::class => \App\Filament\Resources\UserResource::class,
            \App\Models\Post::class => \App\Filament\Resources\PostResource::class,
            \App\Models\MpVideo::class => \App\Filament\Resources\MpVideoResource::class,
            \App\Models\Library::class => \App\Filament\Resources\LibraryResource::class,
            \App\Models\MpRequest::class => \App\Filament\Resources\MpRequestResource::class,
            \App\Models\ContactMessage::class => \App\Filament\Resources\ContactMessageResource::class,
            \App\Models\PlatformMessage::class => \App\Filament\Resources\PlatformMessageResource::class,
            \App\Models\Faq::class => \App\Filament\Resources\FaqResource::class,
            \App\Models\Poll::class => \App\Filament\Resources\PollResource::class,
            \App\Models\Admin::class => \App\Filament\Resources\AdminResource::class,
            default => null,
        };

        if (! $resource || ! method_exists($resource, 'getUrl')) {
            return null;
        }

        try {
            return $resource::getUrl('edit', ['record' => $subject]);
        } catch (Throwable) {
            try {
                return $resource::getUrl('index');
            } catch (Throwable) {
                return null;
            }
        }
    }
}
