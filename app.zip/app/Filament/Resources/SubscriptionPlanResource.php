<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SubscriptionPlanResource\Pages;
use App\Models\SubscriptionPlan;
use Filament\Actions;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class SubscriptionPlanResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = SubscriptionPlan::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-credit-card';
    protected static ?int $navigationSort = 4;

    public static function getNavigationGroup(): ?string { return 'الاشتراكات'; }
    public static function getModelLabel(): string { return 'خطة اشتراك'; }
    public static function getPluralModelLabel(): string { return 'خطط الاشتراك'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات الخطة')->schema([
                TextInput::make('name')->label('اسم الخطة')->required()->maxLength(255),
                Hidden::make('period')->default('monthly'),
                TextInput::make('duration_months')
                    ->label('المدة (بالشهور)')
                    ->numeric()
                    ->minValue(1)
                    ->default(1)
                    ->required(),
                TextInput::make('price')->label('السعر')->numeric()->prefix('ج.م')->default(0)->required(),
                TextInput::make('free_days')->label('مدة مجانية إضافية (بالأيام)')->numeric()->minValue(0)->default(0)->required(),
                TextInput::make('request_limit')
                    ->label('الحد الأقصى للطلبات المسموح بها')
                    ->helperText('ضع 0 للسماح بعدد غير محدود من الطلبات للنائب')
                    ->numeric()
                    ->default(0)
                    ->required(),
                \Filament\Forms\Components\Select::make('limit_period')
                    ->label('فترة تحديد حد الطلبات')
                    ->options([
                        'daily' => 'يومي (تجدد يومياً)',
                        'weekly' => 'أسبوعي (تجدد أسبوعياً)',
                        'monthly' => 'شهري (تجدد شهرياً)',
                    ])
                    ->default('daily')
                    ->required(),
                Toggle::make('allows_polls')->label('السماح بإضافة الاستطلاعات')->default(false),
                Toggle::make('allows_videos')->label('السماح بإضافة الفيديوهات')->default(false),
                Toggle::make('allows_news')->label('السماح بإضافة الأخبار')->default(false),
                Toggle::make('is_active')->label('الخطة متاحة للاشتراك')->default(true),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->label('الخطة')->searchable()->sortable(),
            TextColumn::make('duration_months')->label('المدة (بالشهور)'),
            TextColumn::make('price')->label('السعر')->money('EGP'),
            TextColumn::make('free_days')->label('أيام مجانية'),
            TextColumn::make('request_limit')
                ->label('حد الطلبات')
                ->formatStateUsing(fn ($record) => $record->request_limit > 0 ? "{$record->request_limit} / " . match($record->limit_period) { 'weekly' => 'أسبوع', 'monthly' => 'شهر', default => 'يوم' } : 'غير محدود')
                ->badge()
                ->color(fn ($record) => $record->request_limit > 0 ? 'warning' : 'success'),
            IconColumn::make('allows_polls')->label('استطلاعات')->boolean(),
            IconColumn::make('allows_videos')->label('فيديوهات')->boolean(),
            IconColumn::make('allows_news')->label('أخبار')->boolean(),
            IconColumn::make('is_active')->label('متاحة')->boolean(),
        ])->recordActions([Actions\EditAction::make(), Actions\DeleteAction::make()]);
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListSubscriptionPlans::route('/'), 'create' => Pages\CreateSubscriptionPlan::route('/create'), 'edit' => Pages\EditSubscriptionPlan::route('/{record}/edit')];
    }
}
