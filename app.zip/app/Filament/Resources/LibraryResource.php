<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LibraryResource\Pages;
use App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
use App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
use App\Models\Library;
use Filament\Actions;
use Filament\Resources\Resource;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;

use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

use Filament\Infolists;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\SpatieMediaLibraryImageEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Infolist;

class LibraryResource extends Resource
{
    use FilamentTranslatedLabelResource;
    use FilamentCountBadgeResource;

    protected static ?string $model = Library::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-video-camera';

    protected static ?int $navigationSort = 2;

    public static function getModelLabel(): string
    {
        return 'عنصر مكتبة';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المكتبة المرئية';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'المحتوى والوسائط';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('معلومات الفيديو الأساسية')
                    ->schema([
                        TextInput::make('title')
                            ->label('عنوان الفيديو')
                            ->required()
                            ->maxLength(255),
                        Textarea::make('description')
                            ->label('وصف وتفاصيل الفيديو')
                            ->rows(3)
                            ->maxLength(65535)
                            ->columnSpanFull(),
                    ]),

                Section::make('مصدر الفيديو (رابط خارجي أو رفع ملف)')
                    ->description('تستطيع استخدام إما رابط فيديو خارجي (مثل YouTube / Vimeo) أو رفع ملف فيديو من جهازك.')
                    ->schema([
                        TextInput::make('video_url')
                            ->label('رابط الفيديو الخارجي (YouTube / Vimeo / MP4 Link)')
                            ->placeholder('https://www.youtube.com/watch?v=...')
                            ->url()
                            ->maxLength(255)
                            ->helperText('إذا كان الفيديو موجوداً على يوتيوب أو موقع آخر، أدخل الرابط هنا.'),
                        SpatieMediaLibraryFileUpload::make('video_file')
                            ->label('أو رفع ملف فيديو مبـاشر من جهازك')
                            ->collection('video_file')
                            ->acceptedFileTypes(['video/mp4', 'video/webm', 'video/ogg'])
                            ->maxSize(102400)
                            ->helperText('إذا كان الفيديو مخزناً على جهازك، قم برفعه هنا بصيغة (MP4, WebM).'),
                        SpatieMediaLibraryFileUpload::make('thumbnail')
                            ->label('الصورة المصغرة (Thumbnail)')
                            ->collection('thumbnail')
                            ->image()
                            ->helperText('صورة الغلاف التي تظهر في قائمة الفيديوهات بالمكتبة المرئية.'),
                    ]),

                Section::make('إعدادات حالة النشر')
                    ->schema([
                        Toggle::make('is_active')
                            ->label('نشر الفيديو وإظهاره بالموقع')
                            ->default(true),
                        DateTimePicker::make('published_at')
                            ->label('تاريخ ووقت النشر')
                            ->default(now()),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                SpatieMediaLibraryImageColumn::make('thumbnail')
                    ->collection('thumbnail')
                    ->label('الصورة المصغرة'),
                TextColumn::make('title')
                    ->label('عنوان الفيديو')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('source_type')
                    ->label('المصدر المعروض')
                    ->getStateUsing(fn (Library $record) => $record->hasMedia('video_file') ? 'ملف مرفوع' : ($record->video_url ? 'رابط خارجي' : 'بدون فيديو'))
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'ملف مرفوع' => 'success',
                        'رابط خارجي' => 'info',
                        default => 'gray',
                    }),
                IconColumn::make('is_active')
                    ->label('مُفعّل')
                    ->boolean(),
                TextColumn::make('published_at')
                    ->label('تاريخ النشر')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make(__('Basic Information'))
                    ->icon('heroicon-o-information-circle')
                    ->columns(3)
                    ->schema([
                        TextEntry::make('title')
                            ->translateLabel()
                            ->icon('heroicon-o-video-camera')
                            ->columnSpanFull(),
                    ]),

                Section::make(__('Details'))
                    ->icon('heroicon-o-document-text')
                    ->columns(1)
                    ->schema([
                        TextEntry::make('description')
                            ->translateLabel()
                            ->html()
                            ->columnSpanFull(),
                    ]),

                Section::make(__('Media'))
                    ->icon('heroicon-o-photo')
                    ->columns(2)
                    ->schema([
                        TextEntry::make('video_url')
                            ->translateLabel()
                            ->columnSpanFull(),
                        SpatieMediaLibraryImageEntry::make('thumbnail')
                            ->translateLabel()
                            ->collection('thumbnail')
                            ->columnSpanFull(),
                    ]),

                Section::make(__('Status & Settings'))
                    ->icon('heroicon-o-cog-6-tooth')
                    ->columns(2)
                    ->schema([
                        IconEntry::make('is_active')
                            ->translateLabel()
                            ->boolean(),
                    ]),

                Section::make(__('Timestamps'))
                    ->icon('heroicon-o-clock')
                    ->columns(2)
                    ->collapsed()
                    ->schema([
                        TextEntry::make('published_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                        TextEntry::make('created_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                        TextEntry::make('updated_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-arrow-path'),
                    ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLibraries::route('/'),
            'create' => Pages\CreateLibrary::route('/create'),
            'edit' => Pages\EditLibrary::route('/{record}/edit'),
        ];
    }
}
