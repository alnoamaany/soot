<?php

namespace App\Filament\Resources\MainMenuItemResource\Pages;

use App\Filament\Resources\MainMenuItemResource;
use Filament\Resources\Pages\EditRecord;

class EditMainMenuItem extends EditRecord
{
    protected static string $resource = MainMenuItemResource::class;
}
