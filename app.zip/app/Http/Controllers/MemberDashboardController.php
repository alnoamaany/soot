<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\PlatformMessage;
use App\Models\Admin;
use App\Notifications\PlatformMessageNotification;
use App\Models\MpFollower;
use App\Models\RequestReply;
use App\Models\Post;
use App\Models\Category;
use App\Models\Poll;
use App\Models\PollOption;
use App\Models\RequestPriority;
use App\Models\User;
use App\Notifications\RequestActivityNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use OpenSpout\Common\Entity\Row;
use OpenSpout\Reader\XLSX\Reader;
use OpenSpout\Writer\XLSX\Writer;

class MemberDashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (!$mp) {
            return redirect()->route('home')->with('error', __('غير مصرح: هذه اللوحة مخصصة للنواب فقط.'));
        }

        // Prepare filter options
        $cities = \App\Models\User::query()->whereNotNull('city')->distinct()->orderBy('city')->pluck('city')->filter()->values();
        $areas = \App\Models\User::query()->whereNotNull('area')->distinct()->orderBy('area')->pluck('area')->filter()->values();
        $types = MpRequest::query()->distinct()->orderBy('type')->pluck('type')->filter()->values();
        $priorities = RequestPriority::where('is_active', true)->orderBy('sort_order')->get();

        $activeSubscription = $mp->activeSubscription;
        $activePlan = $activeSubscription?->plan;
        $planMaxLimit = $activePlan ? (int) ($activePlan->request_limit ?? 0) : 0;
        $planPeriod = $activePlan?->limit_period ?: 'monthly';

        $reportData = $this->calculateReportData($mp, request());

        return view('member.dashboard', [
            'mp' => $mp,
            'activeSubscription' => $activeSubscription,
            'activePlan' => $activePlan,
            'planMaxLimit' => $planMaxLimit,
            'planPeriod' => $planPeriod,
            'reportData' => $reportData,
            'cities' => $cities,
            'areas' => $areas,
            'types' => $types,
            'priorities' => $priorities,
            'subscriptionFeatures' => [
                'polls' => $mp->canUseFeature('polls'),
                'videos' => $mp->canUseFeature('videos'),
                'news' => $mp->canUseFeature('news'),
            ],
            'videoCategories' => $mp->videoCategories()->orderBy('name')->get(),
            'mpVideos' => $mp->videos()->with(['category', 'media'])->latest()->get(),
            'mpPosts' => $mp->posts()->with(['category', 'media'])->latest('published_at')->get(),
            'mpPolls' => $mp->polls()->with(['options', 'votes'])->latest()->get(),
            'newsCategories' => Category::orderBy('name')->get(),
            'platformMessages' => $mp->platformMessages()->with('media')->latest('sent_at')->get(),
        ]);
    }

    /**
     * Administrative inbox for the authenticated MP.
     */
    public function platformMessages()
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $platformMessages = PlatformMessage::with('media')
            ->where('mp_id', $mp->id)
            ->where('recipient_type', 'mp')
            ->where('recipient_id', $user->id)
            ->latest('sent_at')
            ->latest('id')
            ->get();

        return view('member.platform-messages', [
            'mp' => $mp,
            'platformMessages' => $platformMessages,
        ]);
    }

    /**
     * Send a message from the authenticated MP to the platform administration.
     */
    public function sendAdminMessage(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $data = $request->validate([
            'subject' => ['required', 'string', 'max:255'],
            'message' => ['required', 'string', 'max:10000'],
            'attachments' => ['nullable', 'array', 'max:10'],
            'attachments.*' => ['file', 'max:51200', 'mimes:pdf,jpg,jpeg,png,gif,webp,doc,docx,xls,xlsx,ppt,pptx,zip,rar,7z,txt'],
        ], [
            'subject.required' => 'يرجى كتابة عنوان الرسالة.',
            'message.required' => 'يرجى كتابة نص الرسالة.',
            'attachments.*.max' => 'حجم الملف الواحد يجب ألا يتجاوز 50 ميجابايت.',
            'attachments.*.mimes' => 'نوع الملف المرفق غير مسموح به.',
        ]);

        $admins = Admin::query()->where('is_active', true)->get();

        if ($admins->isEmpty()) {
            return back()->with('error', 'لا يوجد مسؤول نشط حاليًا لاستقبال الرسالة.');
        }

        foreach ($admins as $admin) {
            $platformMessage = PlatformMessage::create([
                'mp_id' => $mp->id,
                'sender_type' => 'mp',
                'sender_id' => $user->id,
                'recipient_type' => 'admin',
                'recipient_id' => $admin->id,
                'subject' => $data['subject'],
                'message' => $data['message'],
                'sent_at' => now(),
            ]);

            foreach ($request->file('attachments', []) as $file) {
                $platformMessage->addMedia($file)->toMediaCollection('attachments');
            }

            if ($admin->email || method_exists($admin, 'notify')) {
                $admin->notify(new PlatformMessageNotification(
                    title: 'رسالة جديدة من النائب',
                    message: $data['subject'],
                    url: url('/admin/mps/' . $mp->id),
                ));
            }
        }

        return back()->with('success', 'تم إرسال الرسالة إلى إدارة المنصة بنجاح.');
    }

    /**
     * Show an administrative message sent to the authenticated MP.
     */
    public function showPlatformMessage($id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $message = \App\Models\PlatformMessage::with('media')
            ->where('id', $id)
            ->where('mp_id', $mp->id)
            ->firstOrFail();

        if (is_null($message->read_at)) {
            $message->forceFill(['read_at' => now()])->save();
        }

        return view('member.platform-message', [
            'mp' => $mp,
            'platformMessage' => $message,
        ]);
    }

    /**
     * Printable view of reports and statistics for the MP.
     */
    public function printReport(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $reportData = $this->calculateReportData($mp, $request);

        return view('member.reports_print', [
            'mp' => $mp,
            'reportData' => $reportData,
            'requests' => $reportData['requests'],
        ]);
    }

    /**
     * Calculate comprehensive statistics and report metrics for the MP.
     */
    public function calculateReportData(Mp $mp, Request $request): array
    {
        $query = MpRequest::with(['user.markazModel', 'user.governorate', 'requestPriority', 'requestType', 'requestStatus'])
            ->where('mp_id', $mp->id);

        $filterDescription = [];

        // Date range filter
        $range = $request->input('date_range', 'all');
        if ($range === 'today') {
            $query->whereDate('created_at', today());
            $filterDescription[] = 'اليوم (' . today()->format('Y-m-d') . ')';
        } elseif ($range === 'this_week') {
            $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
            $filterDescription[] = 'هذا الأسبوع';
        } elseif ($range === 'this_month') {
            $query->whereBetween('created_at', [now()->startOfMonth(), now()->endOfMonth()]);
            $filterDescription[] = 'هذا الشهر (' . now()->translatedFormat('F Y') . ')';
        } elseif ($range === 'this_year') {
            $query->whereBetween('created_at', [now()->startOfYear(), now()->endOfYear()]);
            $filterDescription[] = 'هذا العام (' . now()->year . ')';
        } elseif ($range === 'custom') {
            if ($request->filled('from')) {
                $query->whereDate('created_at', '>=', $request->input('from'));
                $filterDescription[] = 'من تاريخ: ' . $request->input('from');
            }
            if ($request->filled('to')) {
                $query->whereDate('created_at', '<=', $request->input('to'));
                $filterDescription[] = 'إلى تاريخ: ' . $request->input('to');
            }
        }

        // Sector filter
        if ($request->filled('recipient_sector') && $request->input('recipient_sector') !== 'all') {
            $query->where('recipient_sector', $request->input('recipient_sector'));
            $sectorName = match($request->input('recipient_sector')) {
                'government' => 'القطاع الحكومي',
                'private' => 'القطاع الخاص',
                default => 'جهات أخرى',
            };
            $filterDescription[] = 'القطاع: ' . $sectorName;
        }

        // Status filter
        if ($request->filled('status') && $request->input('status') !== 'all') {
            $query->where('status', $request->input('status'));
            $statusName = match($request->input('status')) {
                'received' => 'جديد / مستلم',
                'approved' => 'معتمد',
                'in_progress' => 'قيد الإجراء',
                'final_review' => 'مراجعة نهائية',
                'completed' => 'تم الإنجاز',
                'rejected' => 'مرفوض',
                default => $request->input('status'),
            };
            $filterDescription[] = 'الحالة: ' . $statusName;
        }

        // Priority filter
        if ($request->filled('priority_id') && $request->input('priority_id') !== 'all') {
            $query->where('request_priority_id', $request->input('priority_id'));
            $pName = RequestPriority::find($request->input('priority_id'))?->name;
            if ($pName) {
                $filterDescription[] = 'الأولوية: ' . $pName;
            }
        }

        $filteredRequests = (clone $query)->orderByDesc('created_at')->get();

        $totalCount = $filteredRequests->count();
        $completedCount = $filteredRequests->where('status', 'completed')->count();
        $inProgressCount = $filteredRequests->whereIn('status', ['in_progress', 'approved', 'final_review'])->count();
        $pendingCount = $filteredRequests->whereIn('status', ['pending', 'received'])->count();
        $rejectedCount = $filteredRequests->whereIn('status', ['rejected', 'closed'])->count();
        $completionRate = $totalCount > 0 ? round(($completedCount / $totalCount) * 100, 1) : 0;

        // Breakdown by status
        $statusBreakdown = [
            'received' => [
                'label' => 'جديد ومستلم',
                'count' => $filteredRequests->where('status', 'received')->count(),
                'color' => '#3b82f6',
                'badge' => 'bg-blue-500/20 text-blue-400 border-blue-500/30',
            ],
            'approved' => [
                'label' => 'معتمد',
                'count' => $filteredRequests->where('status', 'approved')->count(),
                'color' => '#8b5cf6',
                'badge' => 'bg-purple-500/20 text-purple-400 border-purple-500/30',
            ],
            'in_progress' => [
                'label' => 'قيد المتابعة والإجراء',
                'count' => $filteredRequests->where('status', 'in_progress')->count(),
                'color' => '#f59e0b',
                'badge' => 'bg-amber-500/20 text-amber-400 border-amber-500/30',
            ],
            'final_review' => [
                'label' => 'مراجعة نهائية',
                'count' => $filteredRequests->where('status', 'final_review')->count(),
                'color' => '#06b6d4',
                'badge' => 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
            ],
            'completed' => [
                'label' => 'تم الإنجاز والرد',
                'count' => $completedCount,
                'color' => '#10b981',
                'badge' => 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
            ],
            'rejected' => [
                'label' => 'مرفوض / متعذر',
                'count' => $rejectedCount,
                'color' => '#ef4444',
                'badge' => 'bg-red-500/20 text-red-400 border-red-500/30',
            ],
        ];

        // Breakdown by sector
        $sectorBreakdown = [
            'government' => [
                'label' => 'القطاع الحكومي',
                'count' => $filteredRequests->where('recipient_sector', 'government')->count(),
                'percent' => $totalCount > 0 ? round(($filteredRequests->where('recipient_sector', 'government')->count() / $totalCount) * 100, 1) : 0,
            ],
            'private' => [
                'label' => 'القطاع الخاص',
                'count' => $filteredRequests->where('recipient_sector', 'private')->count(),
                'percent' => $totalCount > 0 ? round(($filteredRequests->where('recipient_sector', 'private')->count() / $totalCount) * 100, 1) : 0,
            ],
            'other' => [
                'label' => 'جهات أخرى',
                'count' => $filteredRequests->where('recipient_sector', 'other')->count(),
                'percent' => $totalCount > 0 ? round(($filteredRequests->where('recipient_sector', 'other')->count() / $totalCount) * 100, 1) : 0,
            ],
        ];

        // Breakdown by priority
        $priorities = RequestPriority::where('is_active', true)->orderBy('sort_order')->get();
        $priorityBreakdown = [];
        foreach ($priorities as $p) {
            $cnt = $filteredRequests->where('request_priority_id', $p->id)->count();
            $priorityBreakdown[] = [
                'id' => $p->id,
                'name' => $p->name,
                'color' => $p->color ?: '#C8A84B',
                'count' => $cnt,
                'percent' => $totalCount > 0 ? round(($cnt / $totalCount) * 100, 1) : 0,
            ];
        }

        // Geographical breakdown (by markaz / city)
        $geoBreakdown = $filteredRequests->groupBy(function ($r) {
            return $r->user?->markazModel?->name_ar ?? $r->user?->markaz ?? $r->user?->city ?? 'غير محدد';
        })->map(function ($items, $key) use ($totalCount) {
            return [
                'name' => $key,
                'count' => $items->count(),
                'percent' => $totalCount > 0 ? round(($items->count() / $totalCount) * 100, 1) : 0,
            ];
        })->sortByDesc('count')->take(6)->values();

        // General MP metrics
        $followersCount = MpFollower::where('mp_id', $mp->id)->count();
        $postsCount = Post::where('mp_id', $mp->id)->count();
        $pollsCount = Poll::where('mp_id', $mp->id)->count();
        $totalVotesCount = (int) PollOption::whereHas('poll', fn($q) => $q->where('mp_id', $mp->id))->sum('votes_count');

        return [
            'totalCount' => $totalCount,
            'completedCount' => $completedCount,
            'inProgressCount' => $inProgressCount,
            'pendingCount' => $pendingCount,
            'rejectedCount' => $rejectedCount,
            'completionRate' => $completionRate,
            'statusBreakdown' => $statusBreakdown,
            'sectorBreakdown' => $sectorBreakdown,
            'priorityBreakdown' => $priorityBreakdown,
            'geoBreakdown' => $geoBreakdown,
            'followersCount' => $followersCount,
            'postsCount' => $postsCount,
            'pollsCount' => $pollsCount,
            'totalVotesCount' => $totalVotesCount,
            'filterDescription' => empty($filterDescription) ? 'جميع الفترات والطلبات المسجلة' : implode(' | ', $filterDescription),
            'requests' => $filteredRequests,
            'date_range' => $range,
            'from' => $request->input('from'),
            'to' => $request->input('to'),
            'status_filter' => $request->input('status', 'all'),
            'sector_filter' => $request->input('recipient_sector', 'all'),
            'priority_filter' => $request->input('priority_id', 'all'),
        ];
    }

    public function data(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (!$mp) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $totalRequests = MpRequest::where('mp_id', $mp->id)->count();
        $pendingRequests = MpRequest::where('mp_id', $mp->id)->whereIn('status', ['pending', 'received'])->count();
        $inProgressRequests = MpRequest::where('mp_id', $mp->id)->whereIn('status', ['in_progress', 'approved', 'final_review'])->count();
        $completedRequests = MpRequest::where('mp_id', $mp->id)->where('status', 'completed')->count();
        $followers = MpFollower::where('mp_id', $mp->id)->count();

        $effectivePeriod = $mp->getEffectiveLimitPeriod();
        $periodStart = match ($effectivePeriod) {
            'weekly' => now()->startOfWeek(),
            'monthly' => now()->startOfMonth(),
            default => now()->startOfDay(),
        };
        $currentPeriodCount = MpRequest::where('mp_id', $mp->id)->where('created_at', '>=', $periodStart)->count();

        return response()->json([
            'totalRequests' => $totalRequests,
            'pendingRequests' => $pendingRequests,
            'inProgressRequests' => $inProgressRequests,
            'completedRequests' => $completedRequests,
            'followers' => $followers,
            'currentPeriodCount' => $currentPeriodCount,
            'requestLimit' => (int) $mp->getEffectiveRequestLimit(),
            'limitPeriod' => $effectivePeriod,
        ]);
    }

    public function requests(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (!$mp) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $query = MpRequest::with(['user', 'requestPriority', 'requestType', 'requestStatus'])->where('mp_id', $mp->id);

        // Date range filter (created_at)
        if ($request->filled('from')) {
            $query->whereDate('created_at', '>=', $request->input('from'));
        }
        if ($request->filled('to')) {
            $query->whereDate('created_at', '<=', $request->input('to'));
        }

        // Type filter
        if ($request->filled('type')) {
            $query->where('type', $request->input('type'));
        }

        // Priority filter
        if ($request->filled('priority_id')) {
            $query->where('request_priority_id', $request->input('priority_id'));
        }

        // City / area filters (via relation to user)
        if ($request->filled('city')) {
            $city = $request->input('city');
            $query->whereHas('user', function ($q) use ($city) {
                $q->where('city', $city);
            });
        }
        if ($request->filled('area')) {
            $area = $request->input('area');
            $query->whereHas('user', function ($q) use ($area) {
                $q->where('area', $area);
            });
        }

        $perPage = 10;
        $paginated = $query->orderByDesc('created_at')->paginate($perPage);

        $items = $paginated->getCollection()->map(function ($r) {
            return [
                'id' => $r->id,
                'title' => $r->title,
                'status' => $r->status,
                'user_name' => $r->user?->name,
                'reference_number' => $r->reference_number ?: ('#' . $r->id),
                'type' => $r->type,
                'created_at' => $r->created_at->diffForHumans(),
                'priority_id' => $r->request_priority_id,
                'priority_name' => $r->requestPriority?->name ?? 'عادية',
                'priority_color' => $r->requestPriority?->color ?? '#94a3b8',
            ];
        })->values();

        return response()->json([
            'items' => $items,
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    /**
     * Show a single request detail to the MP.
     */
    public function showRequest($id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            return redirect()->route('home')->with('error', __('غير مصرح: هذه اللوحة مخصصة للنواب فقط.'));
        }

        $requestModel = MpRequest::with([
            'user',
            'requestPriority',
            'requestType',
            'requestStatus',
            'replies' => function($q) {
                $q->with('user')->orderBy('created_at', 'asc');
            }
        ])->where('id', $id)->where('mp_id', $mp->id)->first();

        if (! $requestModel) {
            abort(404);
        }

        $priorities = RequestPriority::where('is_active', true)->orderBy('sort_order')->get();

        return view('member.request', [
            'requestModel' => $requestModel,
            'priorities' => $priorities,
        ]);
    }

    /**
     * Store a reply from the MP to the request.
     */
    public function storeReply(Request $request, $id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $requestModel = MpRequest::where('id', $id)->where('mp_id', $mp->id)->first();
        if (! $requestModel) {
            return response()->json(['message' => 'Not found'], 404);
        }

        $request->validate([
            'content' => 'required|string|max:5000',
            'attachments' => 'nullable|array|max:10',
            'attachments.*' => 'file|max:51200|mimes:pdf,jpg,jpeg,png,gif,webp,doc,docx,xls,xlsx,ppt,pptx,zip,rar,7z,txt',
        ]);

        $reply = \App\Models\RequestReply::create([
            'mp_request_id' => $requestModel->id,
            'user_id' => $user->id,
            'content' => $request->input('content'),
        ]);

        foreach ($request->file('attachments', []) as $file) {
            $reply->addMedia($file)->toMediaCollection('attachments');
        }

        $requestModel->user?->notify(new RequestActivityNotification(
            request: $requestModel,
            title: 'رد جديد على طلبك',
            message: 'قام ' . ($mp->display_name ?: 'النائب') . ' بالرد على طلبك: ' . $requestModel->title,
            url: route('my-requests.show', $requestModel->id),
            event: 'reply_added',
        ));

        return redirect()->route('member.request.show', $requestModel->id)->with('success', 'تم إضافة الرد.');
    }

    /** Create a request entered directly by the MP office. */
    public function storeManualRequest(Request $request)
    {
        $mpUser = Auth::user();
        $mp = $mpUser?->mp;

        if (! $mp) {
            abort(403);
        }

        $data = $request->validate([
            'citizen_name' => 'required|string|max:255',
            'citizen_national_id' => 'required|digits:14',
            'recipient_sector' => 'required|in:government,private,other',
            'recipient_name' => 'nullable|required_if:recipient_sector,other|string|max:255',
            'status' => 'required|in:received,approved,in_progress,final_review,completed',
            'mp_reply' => 'nullable|string|max:5000',
            'notes' => 'nullable|string|max:5000',
            'attachments' => 'nullable|array|max:10',
            'attachments.*' => 'file|mimes:pdf,jpg,jpeg,png,doc,docx|max:5120',
        ], [
            'citizen_name.required' => 'اسم المواطن مطلوب.',
            'citizen_national_id.required' => 'الرقم القومي مطلوب.',
            'citizen_national_id.digits' => 'الرقم القومي يجب أن يتكون من 14 رقمًا.',
            'recipient_sector.required' => 'يرجى تحديد الجهة المقدّم لها الطلب.',
            'recipient_name.required_if' => 'يرجى كتابة اسم الجهة.',
            'attachments.max' => 'يمكن رفع 10 مرفقات كحد أقصى.',
            'attachments.*.max' => 'حجم كل مرفق يجب ألا يتجاوز 5 ميجابايت.',
        ]);

        $existingCitizen = \App\Models\User::where('national_id', $data['citizen_national_id'])->first();
        if ($existingCitizen && $existingCitizen->role !== 'citizen') {
            return back()->withInput()->withErrors([
                'citizen_national_id' => 'الرقم القومي مرتبط بحساب نائب أو مسؤول ولا يمكن استخدامه كمواطن.',
            ]);
        }

        $manualRequest = \Illuminate\Support\Facades\DB::transaction(function () use ($data, $existingCitizen, $mp, $mpUser) {
            $citizen = $existingCitizen ?: \App\Models\User::create([
                'name' => $data['citizen_name'],
                'national_id' => $data['citizen_national_id'],
                'email' => 'citizen-' . $data['citizen_national_id'] . '@requests.local',
                'password' => \Illuminate\Support\Facades\Hash::make(\Illuminate\Support\Str::random(32)),
                'role' => 'citizen',
                'is_approved' => true,
            ]);

            if ($existingCitizen) {
                $citizen->update(['name' => $data['citizen_name']]);
            }

            $sectorLabels = [
                'government' => 'جهة حكومية',
                'private' => 'جهة خاصة',
                'other' => $data['recipient_name'],
            ];
            $recipient = $sectorLabels[$data['recipient_sector']] ?? 'الجهة المختصة';

            $manualRequest = MpRequest::create([
                'user_id' => $citizen->id,
                'mp_id' => $mp->id,
                'type' => 'طلب مضاف بواسطة مكتب النائب',
                'recipient_sector' => $data['recipient_sector'],
                'recipient_name' => $data['recipient_name'] ?? null,
                'title' => 'طلب موجّه إلى ' . $recipient,
                'content' => $data['notes'] ?: 'تم تسجيل الطلب عن طريق مكتب النائب.',
                'notes' => $data['notes'] ?? null,
                'status' => $data['status'],
            ]);

            if (filled($data['mp_reply'] ?? null)) {
                \App\Models\RequestReply::create([
                    'mp_request_id' => $manualRequest->id,
                    'user_id' => $mpUser->id,
                    'content' => $data['mp_reply'],
                ]);
            }

            return $manualRequest;
        });

        foreach ($request->file('attachments', []) as $attachment) {
            $manualRequest->addMedia($attachment)->toMediaCollection('attachments');
        }

        if (filled($data['mp_reply'] ?? null)) {
            $manualRequest->load('user');
            $manualRequest->user?->notify(new RequestActivityNotification(
                request: $manualRequest,
                title: 'رد جديد على طلبك',
                message: 'قام ' . ($mp->display_name ?: 'النائب') . ' بالرد على طلبك.',
                url: route('my-requests.show', $manualRequest->id),
                event: 'reply_added',
            ));
        }

        $attachmentsCount = $manualRequest->getMedia('attachments')->count();

        return redirect()->route('member.request.show', $manualRequest->id)->with(
            'success',
            'تم إنشاء الطلب بنجاح. الرقم المرجعي: ' . $manualRequest->reference_number . ' — عدد المرفقات: ' . $attachmentsCount
        );
    }

    /**
     * Download the Excel sheet used by the MP office for bulk request imports.
     */
    public function downloadRequestsTemplate()
    {
        $filePath = tempnam(storage_path('app'), 'mp-requests-template-');
        $writer = new Writer();
        $writer->openToFile($filePath);
        $writer->addRow(Row::fromValues([
            'اسم المواطن', 'الرقم القومي', 'الجهة', 'اسم الجهة', 'حالة الطلب', 'رد النائب', 'ملاحظات', 'نوع الطلب',
        ]));
        $writer->addRow(Row::fromValues([
            'أحمد محمد علي', '29801011234567', 'حكومي', '', 'تم الاستلام', '', 'مثال توضيحي — احذف هذا الصف قبل الرفع', 'طلب خدمة',
        ]));
        $writer->addRow(Row::fromValues([
            'سارة محمود حسن', '29902021234567', 'أخرى', 'شركة المياه', 'قيد التنفيذ', 'جارٍ متابعة الطلب مع الجهة المختصة.', 'مثال لجهة أخرى', 'شكوى',
        ]));
        $writer->close();

        return response()
            ->download($filePath, 'نموذج-استيراد-طلبات-النائب.xlsx', [
                'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ])
            ->deleteFileAfterSend(true);
    }

    /**
     * Import several requests from the MP office Excel template.
     */
    public function importRequests(Request $request)
    {
        $mpUser = Auth::user();
        $mp = $mpUser?->mp;
        abort_unless($mp, 403);

        $request->validate([
            'requests_file' => 'required|file|mimes:xlsx|max:10240',
        ], [
            'requests_file.required' => 'يرجى اختيار ملف Excel.',
            'requests_file.mimes' => 'يُقبل ملف Excel بصيغة XLSX فقط.',
            'requests_file.max' => 'الحد الأقصى لحجم الملف هو 10 ميجابايت.',
        ]);

        $requiredHeaders = ['اسم المواطن', 'الرقم القومي', 'الجهة', 'حالة الطلب'];
        $reader = new Reader();
        $created = 0;
        $skipped = 0;
        $errors = [];
        $headers = null;
        $processedRows = 0;

        try {
            $reader->open($request->file('requests_file')->getRealPath());

            foreach ($reader->getSheetIterator() as $sheet) {
                foreach ($sheet->getRowIterator() as $rowNumber => $row) {
                    $values = array_map(
                        static fn ($cell) => trim((string) ($cell->getValue() ?? '')),
                        $row->getCells()
                    );

                    if ($headers === null) {
                        $headers = array_map(static fn ($value) => preg_replace('/^\xEF\xBB\xBF/', '', $value), $values);
                        $missing = array_diff($requiredHeaders, $headers);
                        if ($missing) {
                            return back()->withErrors([
                                'requests_file' => 'أعمدة الملف غير مكتملة. الأعمدة المطلوبة: ' . implode('، ', $requiredHeaders) . '.',
                            ]);
                        }
                        continue;
                    }

                    if (! array_filter($values, static fn ($value) => $value !== '')) {
                        continue;
                    }

                    if (++$processedRows > 1000) {
                        $errors[] = 'تم الوصول إلى الحد الأقصى وهو 1000 طلب في الملف الواحد.';
                        break 2;
                    }

                    $rowData = array_combine(
                        $headers,
                        array_slice(array_pad($values, count($headers), ''), 0, count($headers))
                    );

                    try {
                        $this->createImportedRequest($rowData, $mp, $mpUser);
                        $created++;
                    } catch (\Throwable $exception) {
                        $skipped++;
                        if (count($errors) < 10) {
                            $errors[] = 'الصف ' . ($rowNumber + 1) . ': ' . $exception->getMessage();
                        }
                    }
                }
                break; // The template uses the first worksheet only.
            }
        } finally {
            $reader->close();
        }

        $message = 'تم استيراد ' . $created . ' طلب بنجاح.';
        if ($skipped) {
            $message .= ' تم تجاوز ' . $skipped . ' صف لوجود بيانات غير صحيحة.';
        }

        return redirect()->route('member.dashboard')->with([
            'success' => $message,
            'import_errors' => $errors,
        ]);
    }

    private function createImportedRequest(array $row, $mp, User $mpUser): void
    {
        $name = trim((string) ($row['اسم المواطن'] ?? ''));
        $nationalId = preg_replace('/\D/', '', (string) ($row['الرقم القومي'] ?? ''));
        $sectorValue = trim((string) ($row['الجهة'] ?? ''));
        $sector = match ($sectorValue) {
            'حكومي', 'government' => 'government',
            'خاص', 'private' => 'private',
            'أخرى', 'اخرى', 'other' => 'other',
            default => null,
        };
        $status = match (trim((string) ($row['حالة الطلب'] ?? ''))) {
            'تم الاستلام', 'received' => 'received',
            'تمت الموافقة', 'approved' => 'approved',
            'قيد التنفيذ', 'in_progress' => 'in_progress',
            'قيد المراجعة النهائية', 'final_review' => 'final_review',
            'مكتمل', 'completed' => 'completed',
            default => null,
        };
        $recipientName = trim((string) ($row['اسم الجهة'] ?? ''));
        $reply = trim((string) ($row['رد النائب'] ?? ''));
        $notes = trim((string) ($row['ملاحظات'] ?? ''));
        $type = trim((string) ($row['نوع الطلب'] ?? '')) ?: 'طلب مضاف بواسطة مكتب النائب';

        if ($name === '' || strlen($nationalId) !== 14 || ! $sector || ! $status || ($sector === 'other' && $recipientName === '')) {
            throw new \RuntimeException('بيانات المواطن أو الجهة أو حالة الطلب غير صحيحة.');
        }

        $existingCitizen = User::where('national_id', $nationalId)->first();
        if ($existingCitizen && $existingCitizen->role !== 'citizen') {
            throw new \RuntimeException('الرقم القومي مرتبط بحساب غير مواطن.');
        }

        $createdRequest = DB::transaction(function () use ($existingCitizen, $name, $nationalId, $mp, $sector, $recipientName, $status, $reply, $notes, $type, $mpUser) {
            $citizen = $existingCitizen ?: User::create([
                'name' => $name,
                'national_id' => $nationalId,
                'email' => 'citizen-' . $nationalId . '@requests.local',
                'password' => Hash::make(Str::random(32)),
                'role' => 'citizen',
                'is_approved' => true,
            ]);

            if ($existingCitizen) {
                $citizen->update(['name' => $name]);
            }

            $sectorLabels = [
                'government' => 'جهة حكومية',
                'private' => 'جهة خاصة',
                'other' => $recipientName,
            ];
            $requestModel = MpRequest::create([
                'user_id' => $citizen->id,
                'mp_id' => $mp->id,
                'type' => $type,
                'recipient_sector' => $sector,
                'recipient_name' => $sector === 'other' ? $recipientName : null,
                'title' => 'طلب موجّه إلى ' . $sectorLabels[$sector],
                'content' => $notes ?: 'تم تسجيل الطلب عن طريق مكتب النائب.',
                'notes' => $notes ?: null,
                'status' => $status,
            ]);

            if ($reply !== '') {
                RequestReply::create([
                    'mp_request_id' => $requestModel->id,
                    'user_id' => $mpUser->id,
                    'content' => $reply,
                ]);
            }

            return [$requestModel, $citizen];
        });

        [$requestModel, $citizen] = $createdRequest;
        if ($existingCitizen && $reply !== '') {
            $citizen->notify(new RequestActivityNotification(
                request: $requestModel,
                title: 'رد جديد على طلبك',
                message: 'قام ' . ($mp->display_name ?: 'النائب') . ' بالرد على طلبك.',
                url: route('my-requests.show', $requestModel->id),
                event: 'reply_added',
            ));
        }
    }

    /**
     * Update request status (MP only).
     */
    public function updateStatus(Request $request, $id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            return redirect()->route('home')->with('error', 'غير مصرح.');
        }

        $requestModel = MpRequest::where('id', $id)->where('mp_id', $mp->id)->first();
        if (! $requestModel) {
            abort(404);
        }

        $request->validate([
            'status' => 'required|string|in:received,approved,in_progress,final_review,completed',
        ]);

        $requestModel->status = $request->input('status');
        $requestModel->save();

        // Optionally record a reply indicating status change
        \App\Models\RequestReply::create([
            'mp_request_id' => $requestModel->id,
            'user_id' => $user->id,
            'content' => 'حالة الطلب تم تغييرها إلى: ' . $requestModel->status,
        ]);

        $statusLabel = [
            'received' => 'تم الاستلام',
            'approved' => 'تمت الموافقة',
            'in_progress' => 'قيد التنفيذ',
            'final_review' => 'قيد المراجعة النهائية',
            'completed' => 'مكتمل',
        ][$requestModel->status] ?? $requestModel->status;

        $requestModel->user?->notify(new RequestActivityNotification(
            request: $requestModel,
            title: 'تم تحديث حالة طلبك',
            message: 'أصبحت حالة طلب «' . $requestModel->title . '»: ' . $statusLabel,
            url: route('my-requests.show', $requestModel->id),
            event: 'status_changed',
        ));

        return redirect()->route('member.request.show', $requestModel->id)->with('success', 'تم تحديث حالة الطلب.');
    }

    /** Add a private video that appears only on the MP public profile. */
    public function storeVideo(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp || ! $mp->canUseFeature('videos')) {
            abort(403);
        }

        $data = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string|max:5000',
            'category_id' => 'nullable|integer',
            'new_category_name' => 'nullable|string|max:100',
            'video_url' => 'nullable|required_without:video_file|url|max:255',
            'video_file' => 'nullable|required_without:video_url|file|mimetypes:video/mp4,video/webm,video/ogg|max:102400',
            'thumbnail' => 'nullable|image|max:5120',
            'is_active' => 'nullable|boolean',
        ], [
            'title.required' => 'عنوان الفيديو مطلوب.',
            'video_url.required_without' => 'أدخل رابط الفيديو أو ارفع ملف فيديو.',
            'video_file.required_without' => 'أدخل رابط الفيديو أو ارفع ملف فيديو.',
            'video_file.max' => 'حجم ملف الفيديو يجب ألا يتجاوز 100 ميجابايت.',
        ]);

        $categoryId = null;
        if (filled($data['new_category_name'] ?? null)) {
            $categoryId = \App\Models\MpVideoCategory::firstOrCreate([
                'mp_id' => $mp->id,
                'name' => trim($data['new_category_name']),
            ])->id;
        } elseif (filled($data['category_id'] ?? null)) {
            $categoryId = $mp->videoCategories()->whereKey($data['category_id'])->value('id');
            abort_unless($categoryId, 422);
        }

        $video = \App\Models\MpVideo::create([
            'mp_id' => $mp->id,
            'mp_video_category_id' => $categoryId,
            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'video_url' => $data['video_url'] ?? null,
            'is_active' => $request->boolean('is_active', true),
            'published_at' => now(),
        ]);

        if ($request->hasFile('video_file')) {
            $video->addMediaFromRequest('video_file')->toMediaCollection('video_file');
        }
        if ($request->hasFile('thumbnail')) {
            $video->addMediaFromRequest('thumbnail')->toMediaCollection('thumbnail');
        }

        return back()->with('success', 'تمت إضافة الفيديو إلى صفحتك بنجاح.');
    }

    /**
     * Delete a video published by the MP.
     */
    public function deleteVideo($id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp || ! $mp->canUseFeature('videos')) {
            abort(403);
        }

        $video = $mp->videos()->findOrFail($id);
        $video->clearMediaCollection('video_file');
        $video->clearMediaCollection('thumbnail');
        $video->delete();

        return back()->with('success', 'تم حذف الفيديو بنجاح.');
    }

    /**
     * Update MP request limits (from MP profile/dashboard).
     */
     public function updateLimits(Request $request)
     {
         $user = Auth::user();
         $mp = $user?->mp;

         if (! $mp) {
             return redirect()->route('home')->with('error', 'غير مصرح.');
         }

         $plan = $mp->activeSubscription?->plan;
         $planLimit = $plan ? (int) ($plan->request_limit ?? 0) : 0;

         $rules = [
             'request_limit' => 'required|integer|min:0',
             'limit_period' => 'required|string|in:daily,weekly,monthly',
         ];

         $messages = [
             'request_limit.required' => 'الحد الأقصى للطلبات مطلوب.',
             'request_limit.integer' => 'الحد الأقصى يجب أن يكون رقماً صحيحاً.',
             'request_limit.min' => 'الحد الأقصى لا يمكن أن يكون سالباً.',
             'limit_period.required' => 'يرجى اختيار فترة التحديد.',
             'limit_period.in' => 'فترة التحديد غير صالحة.',
         ];

         if ($planLimit > 0) {
             $rules['request_limit'] = "required|integer|min:1|max:{$planLimit}";
             $messages['request_limit.min'] = 'الحد الأدنى للطلبات هو 1 طلب.';
             $messages['request_limit.max'] = "الحد الأقصى المسموح به وفق باقة اشتراكك ({$plan->name}) هو {$planLimit} طلب.";
         }

         $validated = $request->validate($rules, $messages);

         $mp->update([
             'request_limit' => $validated['request_limit'],
             'limit_period' => $validated['limit_period'],
         ]);

         return back()->with('success', 'تم تحديث حد استقبال الطلبات بنجاح.');
     }

    /**
     * Update MP personal profile information.
     */
    public function updateProfile(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            return redirect()->route('home')->with('error', 'غير مصرح.');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'title' => 'nullable|string|max:100',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'phone' => 'required|string|max:20|unique:users,phone,' . $user->id,
            'password' => 'nullable|string|min:8|confirmed',
            'party' => 'nullable|string|max:255',
            'district' => 'nullable|string|max:255',
            'reception_hours' => 'nullable|string|max:255',
            'bio' => 'nullable|string|max:2000',
            'detailed_address' => 'nullable|string|max:1000',
            'avatar' => 'nullable|image|max:2048',
        ], [
            'name.required' => 'الاسم مطلوب.',
            'email.required' => 'البريد الإلكتروني مطلوب.',
            'email.email' => 'يرجى كتابة بريد إلكتروني صحيح.',
            'email.unique' => 'البريد الإلكتروني مستخدم بالفعل.',
            'phone.required' => 'رقم الهاتف مطلوب.',
            'phone.unique' => 'رقم الهاتف مستخدم بالفعل.',
            'password.min' => 'كلمة المرور يجب ألا تقل عن 8 أحرف.',
            'password.confirmed' => 'تأكيد كلمة المرور غير مطبق.',
            'avatar.image' => 'الصورة الشخصية يجب أن تكون ملف صورة.',
            'avatar.max' => 'حجم الصورة الشخصية يجب ألا يتجاوز 2 ميجابايت.',
        ]);

        $userData = [
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'phone' => $request->input('phone'),
            'detailed_address' => $request->input('detailed_address'),
        ];

        if ($request->filled('password')) {
            $userData['password'] = \Illuminate\Support\Facades\Hash::make($request->input('password'));
        }

        $user->update($userData);

        $mp->update([
            'title' => $request->input('title'),
            'party' => $request->input('party'),
            'district' => $request->input('district'),
            'reception_hours' => $request->input('reception_hours'),
            'bio' => $request->input('bio'),
        ]);

        if ($request->hasFile('avatar')) {
            $user->clearMediaCollection('avatar');
            $user->addMediaFromRequest('avatar')->toMediaCollection('avatar');
        }

        return back()->with('success', 'تم تحديث البيانات الشخصية والملف بنجاح.');
    }

    /**
     * Store a new update/news published by the MP for their citizens.
     */
    public function storeNews(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp || ! $mp->canUseFeature('news')) {
            abort(403, 'غير مصرح: باقتك الحالية لا تشمل نشر الأخبار والتحديثات.');
        }

        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string|max:10000',
            'category_id' => 'nullable|exists:categories,id',
            'thumbnail' => 'nullable|image|max:5120',
        ], [
            'title.required' => 'عنوان الخبر أو التحديث مطلوب.',
            'title.max' => 'عنوان الخبر طويل جداً.',
            'content.required' => 'تفاصيل ومحتوى الخبر مطلوب.',
            'thumbnail.image' => 'صورة الغلاف يجب أن تكون ملف صورة صالح.',
            'thumbnail.max' => 'حجم صورة الغلاف يجب ألا يتجاوز 5 ميجابايت.',
        ]);

        // If no category selected, assign to first category or create a default "بيانات وأخبار النواب"
        $categoryId = $request->input('category_id');
        if (! $categoryId) {
            $defaultCat = Category::firstOrCreate(
                ['slug' => 'mp-updates'],
                ['name' => 'بيانات وأنشطة النواب']
            );
            $categoryId = $defaultCat->id;
        }

        $post = Post::create([
            'mp_id' => $mp->id,
            'category_id' => $categoryId,
            'title' => $request->input('title'),
            'content' => $request->input('content'),
            'slug' => Str::slug($request->input('title')) . '-' . Str::random(5),
            'is_published' => true,
            'published_at' => now(),
        ]);

        if ($request->hasFile('thumbnail')) {
            $post->addMediaFromRequest('thumbnail')->toMediaCollection('thumbnail');
        }

        return back()->with('success', 'تم نشر التحديث والخبر للمواطنين بنجاح وسيظهر فوراً في صفحتك العامة!');
    }

    /**
     * Delete an update/news published by the MP.
     */
    public function deleteNews($id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $post = $mp->posts()->findOrFail($id);
        $post->clearMediaCollection('thumbnail');
        $post->delete();

        return back()->with('success', 'تم حذف التحديث بنجاح.');
    }

    /**
     * Update request priority by the MP (from inside or outside the request).
     */
    public function updatePriority(Request $request, $id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            if ($request->wantsJson() || $request->ajax()) {
                return response()->json(['success' => false, 'message' => 'غير مصرح.'], 403);
            }
            return redirect()->route('home')->with('error', 'غير مصرح.');
        }

        $requestModel = MpRequest::where('id', $id)->where('mp_id', $mp->id)->first();
        if (! $requestModel) {
            if ($request->wantsJson() || $request->ajax()) {
                return response()->json(['success' => false, 'message' => 'الطلب غير موجود.'], 404);
            }
            abort(404);
        }

        $priorityId = $request->input('request_priority_id') ?? $request->input('priority_id');

        $request->validate([
            'request_priority_id' => 'nullable|exists:request_priorities,id',
            'priority_id' => 'nullable|exists:request_priorities,id',
        ]);

        $requestModel->update([
            'request_priority_id' => $priorityId,
        ]);

        $requestModel->load('requestPriority');
        $priority = $requestModel->requestPriority;

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'تم تحديث أولوية الطلب بنجاح.',
                'priority' => [
                    'id' => $priority?->id,
                    'name' => $priority?->name ?? 'عادية',
                    'color' => $priority?->color ?? '#94a3b8',
                ],
            ]);
        }

        return redirect()->route('member.request.show', $requestModel->id)->with('success', 'تم تحديث أولوية الطلب بنجاح إلى: ' . ($priority?->name ?? 'عادية'));
    }

    /**
     * Store a new community poll created by the MP for their district.
     */
    public function storePoll(Request $request)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp || ! $mp->canUseFeature('polls')) {
            abort(403, 'غير مصرح: باقتك الحالية لا تشمل استطلاعات الرأي.');
        }

        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string|max:2000',
            'options' => 'required|array|min:2|max:10',
            'options.*' => 'required|string|max:255',
            'ends_at' => 'nullable|date',
        ], [
            'title.required' => 'عنوان استطلاع الرأي مطلوب.',
            'options.required' => 'يجب إدخال خيارات التصويت.',
            'options.min' => 'يجب إضافة خيارين للتصويت على الأقل.',
            'options.*.required' => 'نص الخيار لا يمكن أن يكون فارغاً.',
        ]);

        $poll = Poll::create([
            'mp_id' => $mp->id,
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'is_active' => true,
            'starts_at' => now(),
            'ends_at' => $request->filled('ends_at') ? \Carbon\Carbon::parse($request->input('ends_at')) : now()->addMonths(1),
        ]);

        foreach ($request->input('options') as $optLabel) {
            $trimmed = trim($optLabel);
            if (filled($trimmed)) {
                $poll->options()->create([
                    'label' => $trimmed,
                    'votes_count' => 0,
                ]);
            }
        }

        return back()->with('success', 'تم إنشاء ونشر استطلاع الرأي بنجاح وسيظهر حصرياً في صفحتك الشخصية!');
    }

    /**
     * Toggle active state of a poll created by the MP.
     */
    public function togglePoll($id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $poll = $mp->polls()->findOrFail($id);
        $poll->update([
            'is_active' => ! $poll->is_active,
        ]);

        $statusMsg = $poll->is_active ? 'تم تفعيل الاستطلاع واستقبال الأصوات.' : 'تم إغلاق الاستطلاع بنجاح.';
        return back()->with('success', $statusMsg);
    }

    /**
     * Delete a poll created by the MP.
     */
    public function deletePoll($id)
    {
        $user = Auth::user();
        $mp = $user?->mp;

        if (! $mp) {
            abort(403);
        }

        $poll = $mp->polls()->findOrFail($id);
        $poll->options()->delete();
        $poll->votes()->delete();
        $poll->delete();

        return back()->with('success', 'تم حذف استطلاع الرأي بنجاح.');
    }
}
