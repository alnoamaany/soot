<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

#[Fillable(['name', 'period', 'duration_months', 'price', 'free_days', 'allows_polls', 'allows_videos', 'allows_news', 'request_limit', 'limit_period', 'is_active'])]
class SubscriptionPlan extends Model
{
    use HasFactory;

    protected function casts(): array
    {
        return [
            'duration_months' => 'integer',
            'free_days' => 'integer',
            'price' => 'decimal:2',
            'allows_polls' => 'boolean',
            'allows_videos' => 'boolean',
            'allows_news' => 'boolean',
            'request_limit' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    public function subscriptions()
    {
        return $this->hasMany(MpSubscription::class);
    }
}
