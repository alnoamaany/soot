<?php

namespace App\Filament\Widgets;

use App\Models\Library;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\Poll;
use App\Models\Post;
use App\Models\User;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class AdminStatsOverview extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        return [
            Stat::make('إجمالي المستخدمين', User::count())
                ->description('المستخدمون المسجلون بالمنصة')
                ->descriptionIcon('heroicon-m-users')
                ->color('primary'),
            Stat::make('نواب الشعب', Mp::count())
                ->description('أعضاء البرلمان المتاحون')
                ->descriptionIcon('heroicon-m-user-group')
                ->color('success'),
            Stat::make('الطلبات المفتوحة', MpRequest::where('status', 'open')->count())
                ->description('بانتظار رد مكتب النائب')
                ->descriptionIcon('heroicon-m-envelope-open')
                ->color('warning'),
            Stat::make('المقالات والأخبار', Post::count())
                ->description('المركز الإعلامي والتحديثات')
                ->descriptionIcon('heroicon-m-document-text')
                ->color('info'),
            Stat::make('المكتبة المرئية', Library::count())
                ->description('عناصر وعروض المكتبة المرئية')
                ->descriptionIcon('heroicon-m-book-open')
                ->color('gray'),
            Stat::make('الاستطلاعات', Poll::count())
                ->description('استطلاعات الرأي النشطة والسابقة')
                ->descriptionIcon('heroicon-m-chart-bar')
                ->color('primary'),
        ];
    }
}
