<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    use HasFactory;

    protected $fillable = ['governorate_id', 'markaz_id', 'name_ar', 'name_en'];

    public function governorate()
    {
        return $this->belongsTo(Governorate::class);
    }

    public function markaz()
    {
        return $this->belongsTo(Markaz::class);
    }
}
