<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AreaResource\Pages;
use App\Models\Area;
use App\Models\Markaz;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Schemas\Components\Section;

class AreaResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = Area::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-home-modern';

    protected static ?int $navigationSort = 3;

    public static function getModelLabel(): string
    {
        return 'منطقة / حي';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المناطق والأحياء';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة الجغرافيا والمناطق';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات المنطقة / الحي')
                ->schema([
                    Select::make('governorate_id')
                        ->label('المحافظة')
                        ->relationship('governorate', 'name_ar')
                        ->searchable()
                        ->preload()
                        ->reactive()
                        ->afterStateUpdated(fn (callable $set) => $set('markaz_id', null))
                        ->required(),

                    Select::make('markaz_id')
                        ->label('المركز / القسم')
                        ->options(function (callable $get) {
                            $govId = $get('governorate_id');
                            if (!$govId) {
                                return Markaz::pluck('name_ar', 'id');
                            }
                            return Markaz::where('governorate_id', $govId)->pluck('name_ar', 'id');
                        })
                        ->searchable()
                        ->preload()
                        ->required(),

                    TextInput::make('name_ar')
                        ->label('اسم المنطقة / الحي (بالعربية)')
                        ->required()
                        ->maxLength(255)
                        ->unique(
                            table: 'areas',
                            column: 'name_ar',
                            ignoreRecord: true,
                            modifyRuleUsing: function ($rule, $get) {
                                $markazId = $get('markaz_id');
                                $govId = $get('governorate_id');
                                if ($markazId) {
                                    return $rule->where('markaz_id', $markazId);
                                }
                                if ($govId) {
                                    return $rule->where('governorate_id', $govId);
                                }
                                return $rule;
                            }
                        )
                        ->validationMessages([
                            'unique' => 'اسم المنطقة أو الحي مسجل مسبقاً في هذا النطاق.',
                        ]),

                    TextInput::make('name_en')
                        ->label('اسم المنطقة / الحي (بالإنجليزية)')
                        ->maxLength(255),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('#')
                    ->sortable(),

                TextColumn::make('name_ar')
                    ->label('المنطقة / الحي (بالعربية)')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),

                TextColumn::make('markaz.name_ar')
                    ->label('المركز / القسم')
                    ->searchable()
                    ->sortable()
                    ->badge(),

                TextColumn::make('governorate.name_ar')
                    ->label('المحافظة')
                    ->searchable()
                    ->sortable()
                    ->badge(),

                TextColumn::make('name_en')
                    ->label('بالإنجليزية')
                    ->searchable()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                TextColumn::make('created_at')
                    ->label('تاريخ الإنشاء')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('governorate_id')
                    ->label('تصفية حسب المحافظة')
                    ->relationship('governorate', 'name_ar')
                    ->searchable()
                    ->preload(),

                SelectFilter::make('markaz_id')
                    ->label('تصفية حسب المركز')
                    ->relationship('markaz', 'name_ar')
                    ->searchable()
                    ->preload(),
            ])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAreas::route('/'),
            'create' => Pages\CreateArea::route('/create'),
            'edit' => Pages\EditArea::route('/{record}/edit'),
        ];
    }
}
