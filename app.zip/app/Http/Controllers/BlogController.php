<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Post;
use App\Services\BlogService;
use Illuminate\View\View;

class BlogController extends Controller
{
    protected $blogService;

    public function __construct(BlogService $blogService)
    {
        $this->blogService = $blogService;
    }

    /**
     * Display the main blog page.
     */
    public function index(): View
    {
        $latestPost = $this->blogService->getLatestPost();
        $posts = $this->blogService->getPaginatedPosts(12, $latestPost?->id);
        $categories = Category::query()
            ->whereNull('parent_id')
            ->with(['children' => fn ($query) => $query->withCount('posts')->ordered()])
            ->withCount('posts')
            ->where(function ($query) {
                $query->whereHas('posts')
                    ->orWhereHas('children.posts');
            })
            ->ordered()
            ->get();

        return view('pages.blog', compact('latestPost', 'posts', 'categories'));
    }

    /**
     * Display posts for a specific category.
     */
    public function category(string $slug): View
    {
        $category = Category::query()->where('slug', $slug)->firstOrFail();
        $latestPost = $this->blogService->getLatestPost();
        $posts = $this->blogService->getPostsByCategory($category, 12);
        $categories = Category::query()
            ->whereNull('parent_id')
            ->with(['children' => fn ($query) => $query->withCount('posts')->ordered()])
            ->withCount('posts')
            ->where(function ($query) {
                $query->whereHas('posts')
                    ->orWhereHas('children.posts');
            })
            ->ordered()
            ->get();

        return view('pages.blog', compact('latestPost', 'posts', 'categories', 'category'));
    }

    /**
     * Display a specific post.
     */
    public function show(string $categorySlug, string $postSlug): View
    {
        $post = Post::with(['category', 'media'])
            ->whereHas('category', function ($query) use ($categorySlug) {
                $query->where('slug', $categorySlug);
            })
            ->where('slug', $postSlug)
            ->where('is_published', true)->whereNull('deleted_by_mp_at')
            ->firstOrFail();

        return view('pages.blog-show', compact('post'));
    }
}
