<?php
namespace App\Filament\Resources\PlatformImportantNotificationResource\Pages;
use App\Filament\Resources\PlatformImportantNotificationResource;
use Filament\Resources\Pages\ListRecords;
class ListPlatformImportantNotifications extends ListRecords { protected static string $resource = PlatformImportantNotificationResource::class; }
