<?php
namespace App\Filament\Resources\MpRequestResource\Pages;
use App\Filament\Resources\MpRequestResource;
use Filament\Resources\Pages\ViewRecord;
class ViewMpRequest extends ViewRecord { protected static string $resource = MpRequestResource::class; }
