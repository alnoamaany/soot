<?php

namespace App\Http\Controllers;

use App\Models\Poll;
use App\Models\PollOption;
use App\Models\PollVote;
use Illuminate\Http\Request;

class PollController extends Controller
{
    public function vote(Request $request, \App\Services\PollService $pollService)
    {
        $request->validate([
            'poll_option_id' => 'required|exists:poll_options,id',
        ]);

        try {
            $option = PollOption::findOrFail($request->poll_option_id);
            $poll = $option->poll;

            $pollService->vote($poll, $option, $request->ip(), auth()->id());

            return response()->json([
                'message' => 'تم تسجيل صوتك بنجاح',
                'results' => $poll->options()->get(['id', 'label', 'votes_count']),
                'total_votes' => $poll->options()->sum('votes_count'),
            ]);
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }
    }
}
