<?php
namespace App\Observers;

use App\Models\MpRequest;
use App\Services\AdminAlertService;

class MpRequestObserver
{
    public function created(MpRequest $request): void
    {
        AdminAlertService::notify(
            'request_created',
            'طلب مواطن جديد',
            "تم تقديم طلب مواطن جديد برقم {$request->reference_number}.",
            $request,
            meta: ['request_id' => $request->id, 'reference_number' => $request->reference_number],
        );
    }

    public function updated(MpRequest $request): void
    {
        if ($request->wasChanged('request_status_id') || $request->wasChanged('status')) {
            AdminAlertService::notify(
                'request_status_changed',
                'تغيير حالة طلب مواطن',
                "تم تغيير حالة الطلب {$request->reference_number}.",
                $request,
                meta: [
                    'request_id' => $request->id,
                    'request_status_id' => $request->request_status_id,
                    'status' => $request->status,
                ],
            );
        }
    }
}
