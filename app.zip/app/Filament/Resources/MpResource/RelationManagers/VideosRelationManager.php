<?php

namespace App\Filament\Resources\MpResource\RelationManagers;

use App\Models\MpVideo;
use App\Models\MpVideoCategory;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Illuminate\Database\Eloquent\Model;

class VideosRelationManager extends RelationManager
{
    protected static string $relationship = 'videos';

    public static function getTitle(Model $ownerRecord, string $pageClass): string
    {
        return 'تسجيلات ولقاءات النائب (' . $ownerRecord->videos()->count() . ')';
    }

    public static function getModelLabel(): string
    {
        return 'فيديو / تسجيل';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المكتبة المرئية والتسجيلات';
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('title')
                    ->label('عنوان الفيديو أو اللقاء')
                    ->required()
                    ->maxLength(255),

                Select::make('mp_video_category_id')
                    ->label('تصنيف الفيديو')
                    ->options(fn (RelationManager $livewire) => MpVideoCategory::where('mp_id', $livewire->ownerRecord->id)->pluck('name', 'id'))
                    ->createOptionForm([
                        TextInput::make('name')
                            ->label('اسم التصنيف الجديد')
                            ->required()
                            ->maxLength(255),
                    ])
                    ->createOptionUsing(function (array $data, RelationManager $livewire) {
                        return MpVideoCategory::firstOrCreate([
                            'mp_id' => $livewire->ownerRecord->id,
                            'name' => trim($data['name']),
                        ])->id;
                    })
                    ->searchable()
                    ->preload(),

                TextInput::make('video_url')
                    ->label('رابط الفيديو (YouTube / Vimeo / مباشر)')
                    ->placeholder('https://www.youtube.com/watch?v=...')
                    ->url()
                    ->maxLength(255),

                SpatieMediaLibraryFileUpload::make('video_file')
                    ->label('أو رفع ملف الفيديو مباشرة')
                    ->collection('video_file')
                    ->acceptedFileTypes(['video/mp4', 'video/webm', 'video/ogg'])
                    ->maxSize(102400),

                SpatieMediaLibraryFileUpload::make('thumbnail')
                    ->label('الصورة المصغرة (الغلاف)')
                    ->collection('thumbnail')
                    ->image(),

                Toggle::make('is_active')
                    ->label('مُفعّل ومعروض للمواطنين')
                    ->default(true),

                DateTimePicker::make('published_at')
                    ->label('تاريخ ووقت النشر')
                    ->default(now()),

                Textarea::make('description')
                    ->label('وصف وتفاصيل الفيديو')
                    ->rows(3)
                    ->maxLength(1000)
                    ->columnSpanFull(),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('title')
            ->columns([
                SpatieMediaLibraryImageColumn::make('thumbnail')
                    ->collection('thumbnail')
                    ->label('الغلاف'),

                TextColumn::make('title')
                    ->label('عنوان الفيديو')
                    ->searchable()
                    ->sortable()
                    ->weight('bold')
                    ->wrap(),

                TextColumn::make('category.name')
                    ->label('التصنيف')
                    ->badge()
                    ->placeholder('عام')
                    ->sortable(),

                IconColumn::make('is_active')
                    ->label('مُفعّل')
                    ->boolean(),

                TextColumn::make('published_at')
                    ->label('تاريخ النشر')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([])
            ->headerActions([
                Actions\CreateAction::make()
                    ->label('إضافة تسجيل/فيديو للنائب')
                    ->mutateFormDataUsing(function (array $data, RelationManager $livewire): array {
                        $data['mp_id'] = $livewire->ownerRecord->id;
                        return $data;
                    }),
            ])
            ->recordActions([
                Actions\ViewAction::make()->label('عرض'),
                Actions\EditAction::make()->label('تعديل'),
                Actions\DeleteAction::make()->label('حذف'),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
