<?php
namespace App\Observers;

use App\Models\PlatformMessage;
use App\Services\AdminAlertService;

class PlatformMessageObserver
{
    public function created(PlatformMessage $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');
        AdminAlertService::notify(
            'platform_message_created',
            'رسالة إدارية جديدة',
            str_replace(['{title}'], [$title], 'وصلت رسالة جديدة بعنوان "{title}".'),
            $model,
            meta: ['platform_message_id' => $model->id],
        );
    }
}
