<?php

namespace App\Filament\Resources\MpResource\Pages;

use App\Filament\Resources\MpResource;
use Filament\Resources\Pages\ViewRecord;
use Filament\Actions;

class ViewMp extends ViewRecord
{
    protected static string $resource = MpResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\EditAction::make(),
        ];
    }
}
