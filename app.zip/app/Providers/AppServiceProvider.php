<?php

namespace App\Providers;

use App\Settings\GeneralSettings;
use App\Models\Admin;
use App\Models\ContactMessage;
use App\Models\Faq;
use App\Models\Library;
use App\Models\MpRequest;
use App\Models\MpVideo;
use App\Models\PlatformMessage;
use App\Models\Poll;
use App\Models\Post;
use App\Models\User;
use App\Observers\AdminObserver;
use App\Observers\ContactMessageObserver;
use App\Observers\FaqObserver;
use App\Observers\LibraryObserver;
use App\Observers\MpRequestObserver;
use App\Observers\MpVideoObserver;
use App\Observers\PlatformMessageObserver;
use App\Observers\PollObserver;
use App\Observers\PostObserver;
use App\Observers\UserObserver;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Throwable;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        require_once app_path('Helper/helpers.php');
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Admin::observe(AdminObserver::class);
        User::observe(UserObserver::class);
        Post::observe(PostObserver::class);
        MpVideo::observe(MpVideoObserver::class);
        Library::observe(LibraryObserver::class);
        Faq::observe(FaqObserver::class);
        Poll::observe(PollObserver::class);
        MpRequest::observe(MpRequestObserver::class);
        ContactMessage::observe(ContactMessageObserver::class);
        PlatformMessage::observe(PlatformMessageObserver::class);

        if (app()->environment('production')) {
            URL::forceScheme('https');
        }

        Blade::directive('versionedAsset', function ($expression) {
            return "<?php echo versioned_asset({$expression}); ?>";
        });

        try {
            $settings = app(GeneralSettings::class);

            if (isset($settings->session_lifetime) && (int) $settings->session_lifetime > 0) {
                config(['session.lifetime' => (int) $settings->session_lifetime]);
            }

            if ($settings->smtp_enabled && filled($settings->smtp_host)) {
                config([
                    'mail.default' => 'smtp',
                    'mail.mailers.smtp.host' => $settings->smtp_host,
                    'mail.mailers.smtp.port' => $settings->smtp_port,
                    'mail.mailers.smtp.username' => filled($settings->smtp_username) ? $settings->smtp_username : null,
                    'mail.mailers.smtp.password' => filled($settings->smtp_password) ? $settings->smtp_password : null,
                    'mail.mailers.smtp.scheme' => match ($settings->smtp_encryption) {
                        'ssl' => 'smtps',
                        'tls' => 'smtp',
                        default => null,
                    },
                    'mail.from.address' => filled($settings->smtp_from_address)
                        ? $settings->smtp_from_address
                        : config('mail.from.address'),
                    'mail.from.name' => filled($settings->smtp_from_name)
                        ? $settings->smtp_from_name
                        : ($settings->site_name ?: config('mail.from.name')),
                ]);
            }
        } catch (Throwable) {
            // Settings can be unavailable while the application is being installed or migrated.
        }
    }
}
