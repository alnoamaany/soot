<?php

namespace App\Http\Controllers;

use App\Models\Mp;
use App\Models\MpRequest;
use App\Notifications\RequestActivityNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MpRequestController extends Controller
{
    /**
     * Show the request creation form.
     */
    public function create(Request $request)
    {
        $settings = app(\App\Settings\GeneralSettings::class);
        abort_unless($settings->citizen_requests_enabled, 404);
        // Open login modal instead of navigating to a dedicated login page.
        if (!Auth::check()) {
            $request->session()->put('url.intended', route('apply.index'));

            $previousUrl = url()->previous();
            $isInternalPrevious = is_string($previousUrl) && str_starts_with($previousUrl, url('/'));

            if (! $isInternalPrevious || str_contains($previousUrl, '/apply') || str_contains($previousUrl, '/login')) {
                $previousUrl = route('home');
            }

            $parts = parse_url($previousUrl);
            $path = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? request()->getHost());
            if (isset($parts['port'])) {
                $path .= ':' . $parts['port'];
            }
            $path .= $parts['path'] ?? '/';

            $query = [];
            if (! empty($parts['query'])) {
                parse_str($parts['query'], $query);
            }
            $query['login'] = '1';

            return redirect()->to($path . '?' . http_build_query($query))
                ->with('error', 'يرجى تسجيل الدخول لتقديم طلب.');
        }

        // Load all active MPs with their relational location data for the dropdown
        $mps = Mp::with(['user.governorate', 'user.markazModel', 'user.areaModel'])
            ->where('is_active', true)
            ->get();

        $selectedMpId = null;
        $savedLocationMessage = null;
        $citizenLimits = null;

        if (Auth::check()) {
            $user = Auth::user();
            $citizenLimits = $user->isCitizen() ? $this->getCitizenRequestLimits($user->id) : null;

            // Determine user registered location string
            $userGov = $user->governorate?->name_ar ?? $user->city;
            $userMarkaz = $user->markazModel?->name_ar ?? $user->markaz;
            $userArea = $user->areaModel?->name_ar ?? $user->area;

            $locationParts = array_filter([$userGov, $userMarkaz, $userArea]);
            if (!empty($locationParts)) {
                $savedLocationMessage = 'الموقع المسجل بحسابك: ' . implode(' - ', array_unique($locationParts));
            }

            // 1. Try matching MP by Area
            if (!empty($user->area_id)) {
                $mp = $mps->first(function ($item) use ($user) {
                    return $item->user && $item->user->area_id == $user->area_id;
                });
                if ($mp) {
                    $selectedMpId = $mp->id;
                }
            }

            // 2. Try matching MP by Markaz
            if (!$selectedMpId && !empty($user->markaz_id)) {
                $mp = $mps->first(function ($item) use ($user) {
                    return $item->user && $item->user->markaz_id == $user->markaz_id;
                });
                if ($mp) {
                    $selectedMpId = $mp->id;
                }
            }

            // 3. Try matching MP by Governorate
            if (!$selectedMpId && !empty($user->governorate_id)) {
                $mp = $mps->first(function ($item) use ($user) {
                    return $item->user && $item->user->governorate_id == $user->governorate_id;
                });
                if ($mp) {
                    $selectedMpId = $mp->id;
                }
            }

            // 4. Try matching MP by city / district text
            if (!$selectedMpId && !empty($userGov)) {
                $mp = $mps->first(function ($item) use ($userGov) {
                    if (!$item->user) return false;
                    $itemGov = $item->user->governorate?->name_ar ?? $item->user->city;
                    return ($itemGov && (str_contains($itemGov, $userGov) || str_contains($userGov, $itemGov)))
                        || ($item->district && (str_contains($item->district, $userGov) || str_contains($userGov, $item->district)));
                });
                if ($mp) {
                    $selectedMpId = $mp->id;
                }
            }
        }

        return view('pages.apply', compact('mps', 'selectedMpId', 'savedLocationMessage', 'citizenLimits'));
    }

    /**
     * Store the newly created request.
     */
    public function store(Request $request)
    {
        $settings = app(\App\Settings\GeneralSettings::class);
        abort_unless($settings->citizen_requests_enabled, 404);
        if (!Auth::check()) {
            return redirect()->to(route('home', ['login' => 1]))
                ->with('error', 'يرجى تسجيل الدخول لتقديم طلب.');
        }

        $user = Auth::user();
        $isCitizen = $user->isCitizen();

        if ($isCitizen) {
            $generalSettings = app(\App\Settings\GeneralSettings::class);

            // 1. Check Citizen Monthly Requests Limit
            if (!empty($generalSettings->citizen_monthly_request_limit) && $generalSettings->citizen_monthly_request_limit > 0) {
                $currentMonthCount = MpRequest::where('user_id', $user->id)
                    ->whereBetween('created_at', [now()->startOfMonth(), now()->endOfMonth()])
                    ->count();

                if ($currentMonthCount >= $generalSettings->citizen_monthly_request_limit) {
                    $daysUntilNextMonth = now()->diffInDays(now()->endOfMonth()) + 1;
                    return back()->with('error', "لقد استنفدت الحد الأقصى للطلبات المسموح لك بتقديمها هذا الشهر ({$generalSettings->citizen_monthly_request_limit} طلب/طلبات). يتجدد رصيدك تلقائياً مع بداية الشهر القادم (خلال {$daysUntilNextMonth} يوم).")->withInput();
                }
            }

            // 2. Check Citizen Concurrent Active Requests Limit
            if (!empty($generalSettings->citizen_max_active_requests) && $generalSettings->citizen_max_active_requests > 0) {
                $activeCount = MpRequest::where('user_id', $user->id)
                    ->whereNotIn('status', ['completed', 'closed', 'resolved', 'rejected'])
                    ->count();

                if ($activeCount >= $generalSettings->citizen_max_active_requests) {
                    return back()->with('error', "لديك حالياً ({$activeCount}) طلبات جارية وقيد المتابعة. الحد الأقصى للطلبات المفتوحة في نفس الوقت هو ({$generalSettings->citizen_max_active_requests}) طلب/طلبات. يرجى انتظار الانتهاء من الطلبات السابقة قبل تقديم طلب جديد.")->withInput();
                }
            }
        }

        // Try to auto-select MP based on authenticated user's area/governorate
        $selectedMpId = $request->input('mp_id');

        if (empty($selectedMpId)) {
            $mp = null;
            if (!empty($user->area_id)) {
                $mp = Mp::where('is_active', true)
                    ->whereHas('user', function ($q) use ($user) {
                        $q->where('area_id', $user->area_id);
                    })->first();
            }

            // fallback to governorate match
            if (!$mp && !empty($user->governorate_id)) {
                $mp = Mp::where('is_active', true)
                    ->whereHas('user', function ($q) use ($user) {
                        $q->where('governorate_id', $user->governorate_id);
                    })->first();
            }

            if ($mp) {
                $selectedMpId = $mp->id;
                // merge so validation sees it
                $request->merge(['mp_id' => $selectedMpId]);
            }
        }

        $request->validate([
            'mp_id' => 'nullable|exists:mps,id',
            'type' => 'required|string|max:255',
            'recipient_sector' => 'required|in:government,private,other',
            'recipient_name' => 'nullable|required_if:recipient_sector,other|string|max:255',
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'attachments' => 'nullable|array|max:10',
            'attachments.*' => 'file|mimes:pdf,jpg,jpeg,png,doc,docx|max:10240',
            'attachment' => 'nullable|file|mimes:pdf,jpg,jpeg,png,doc,docx|max:10240',
        ], [
            'mp_id.exists' => 'عضو البرلمان المختار غير موجود.',
            'type.required' => 'يرجى تحديد نوع الطلب.',
            'title.required' => 'عنوان الطلب مطلوب.',
            'title.max' => 'عنوان الطلب يجب ألا يتعدى ٢٥٥ حرفاً.',
            'content.required' => 'تفاصيل الطلب مطلوبة.',
            'attachments.array' => 'صيغة المرفقات غير صحيحة.',
            'attachments.max' => 'الحد الأقصى للمرفقات هو ١٠ ملفات.',
            'attachments.*.file' => 'كل مرفق يجب أن يكون ملفاً صحيحاً.',
            'attachments.*.mimes' => 'المرفقات المقبولة فقط هي: PDF, Word, PNG, JPG.',
            'attachments.*.max' => 'حجم كل مرفق لا يجب أن يتخطى ١٠ ميجابايت.',
            'attachment.file' => 'المرفق يجب أن يكون ملفاً صحيحاً.',
            'attachment.mimes' => 'المرفقات المقبولة فقط هي: PDF, Word, PNG, JPG.',
            'attachment.max' => 'حجم المرفق لا يجب أن يتخطى ١٠ ميجابايت.',
        ]);

        if ($selectedMpId) {
            $targetMp = Mp::with('user', 'activeSubscription.plan')->find($selectedMpId);
            $isTargetMpTheAuthor = ($targetMp && $targetMp->user_id === $user->id);

            if ($isCitizen && ! $isTargetMpTheAuthor && $targetMp && $targetMp->hasReachedRequestLimit()) {
                $periodName = match ($targetMp->getEffectiveLimitPeriod()) {
                    'weekly' => 'الأسبوع',
                    'monthly' => 'الشهر',
                    default => 'اليوم',
                };
                $mpName = $targetMp->display_name ?: 'النائب';
                $timeRemaining = $targetMp->getTimeUntilLimitReset();

                return back()->with('error', "وصل النائب ({$mpName}) إلى الحد الأقصى لاستقبال الطلبات لهذا الـ ({$periodName}). يمكنك تقديم طلب جديد بعد: {$timeRemaining}.")->withInput();
            }
        }

        $mpRequest = MpRequest::create([
            'user_id' => Auth::id(),
            'mp_id' => $selectedMpId,
            'type' => $request->type,
            'recipient_sector' => $request->recipient_sector,
            'recipient_name' => $request->recipient_name,
            'title' => $request->title,
            'content' => $request->content,
            'status' => 'received',
        ]);

        $mpRequest->load('user', 'mp.user');
        $mpUser = $mpRequest->mp?->user;

        if ($mpUser && $mpUser->id !== $mpRequest->user_id) {
            $mpUser->notify(new RequestActivityNotification(
                request: $mpRequest,
                title: 'طلب مواطن جديد',
                message: 'وصل إليك طلب جديد من ' . ($mpRequest->user?->name ?? 'مواطن') . ': ' . $mpRequest->title,
                url: route('member.request.show', $mpRequest->id),
                event: 'request_submitted',
            ));
        }

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $uploadedFile) {
                if ($uploadedFile && $uploadedFile->isValid()) {
                    $mpRequest->addMedia($uploadedFile)->toMediaCollection('attachments');
                }
            }
        }

        if ($request->hasFile('attachment')) {
            $mpRequest->addMediaFromRequest('attachment')->toMediaCollection('attachments');
        }

        return redirect()->route('apply.success', $mpRequest);
    }

    /**
     * Helper to retrieve citizen request limit status.
     */
    public function getCitizenRequestLimits(?int $userId): ?array
    {
        if (!$userId) {
            return null;
        }

        $generalSettings = app(\App\Settings\GeneralSettings::class);
        $monthlyLimit = (int) ($generalSettings->citizen_monthly_request_limit ?? 0);
        $maxActiveLimit = (int) ($generalSettings->citizen_max_active_requests ?? 0);

        $currentMonthCount = $monthlyLimit > 0
            ? MpRequest::where('user_id', $userId)->whereBetween('created_at', [now()->startOfMonth(), now()->endOfMonth()])->count()
            : 0;

        $activeCount = $maxActiveLimit > 0
            ? MpRequest::where('user_id', $userId)->whereNotIn('status', ['completed', 'closed', 'resolved', 'rejected'])->count()
            : 0;

        return [
            'monthly_limit' => $monthlyLimit,
            'monthly_count' => $currentMonthCount,
            'monthly_remaining' => $monthlyLimit > 0 ? max(0, $monthlyLimit - $currentMonthCount) : null,
            'max_active_limit' => $maxActiveLimit,
            'active_count' => $activeCount,
            'active_remaining' => $maxActiveLimit > 0 ? max(0, $maxActiveLimit - $activeCount) : null,
            'has_reached_monthly' => $monthlyLimit > 0 && $currentMonthCount >= $monthlyLimit,
            'has_reached_active' => $maxActiveLimit > 0 && $activeCount >= $maxActiveLimit,
        ];
    }

    /** Show the reference number immediately after a citizen submits a request. */
    /** Store a citizen reply on a request when the assigned MP allows it. */
    public function storeCitizenReply(Request $request, $id)
    {
        if (!Auth::check()) {
            return redirect()->to(route('home', ['login' => 1]))
                ->with('error', 'يرجى تسجيل الدخول للرد على الطلب.');
        }

        $user = Auth::user();
        $requestModel = MpRequest::with('mp')->where('id', $id)->where('user_id', $user->id)->firstOrFail();

        if (! $requestModel->citizen_can_reply) {
            return back()->with('error', 'النائب لا يسمح حاليًا للمواطن بالرد على هذا الطلب.');
        }

        $request->validate([
            'content' => 'required|string|max:5000',
            'attachments' => 'nullable|array|max:10',
            'attachments.*' => 'file|max:25600|mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx,zip',
        ], [
            'content.required' => 'نص الرد مطلوب.',
            'content.max' => 'نص الرد يجب ألا يتجاوز 5000 حرف.',
            'attachments.max' => 'يمكن رفع 10 مرفقات كحد أقصى.',
            'attachments.*.max' => 'حجم كل مرفق لا يجب أن يتجاوز 25 ميجابايت.',
            'attachments.*.mimes' => 'نوع الملف غير مدعوم. المسموح: PDF, Word, Excel, JPG, PNG, ZIP.',
        ]);

        $reply = \App\Models\RequestReply::create([
            'mp_request_id' => $requestModel->id,
            'user_id' => $user->id,
            'content' => $request->input('content'),
        ]);

        foreach ($request->file('attachments', []) as $attachment) {
            $reply->addMedia($attachment)->toMediaCollection('attachments');
        }

        $mpUser = $requestModel->mp?->user;
        if ($mpUser) {
            $mpUser->notify(new RequestActivityNotification(
                request: $requestModel,
                title: 'رد جديد من المواطن',
                message: 'أضاف المواطن ردًا جديدًا على طلبك: ' . $requestModel->title,
                url: route('member.request.show', $requestModel->id),
                event: 'reply_added',
            ));
        }

        return back()->with('success', 'تم إرسال ردك بنجاح.');
    }

    public function success(MpRequest $mpRequest)
    {
        abort_unless((string) $mpRequest->user_id === (string) Auth::id(), 403);

        return view('pages.request_submitted', compact('mpRequest'));
    }

    /**
     * Display the authenticated user's requests.
     */
    public function index()
    {
        if (!Auth::check()) {
            return redirect()->to(route('home', ['login' => 1]))
                ->with('error', 'يرجى تسجيل الدخول لعرض طلباتك.');
        }

        $requests = MpRequest::with(['mp.user'])
            ->where('user_id', Auth::id())
            ->latest()
            ->get();

        $user = Auth::user();
        $citizenLimits = $user?->isCitizen() ? $this->getCitizenRequestLimits($user->id) : null;

        return view('pages.my_requests', compact('requests', 'citizenLimits'));
    }

    /**
     * Display a single request belonging to the authenticated user.
     */
    public function show($id)
    {
        if (!Auth::check()) {
            return redirect()->to(route('home', ['login' => 1]))
                ->with('error', 'يرجى تسجيل الدخول لعرض الطلب.');
        }

        $requestModel = MpRequest::with(['mp.user'])->where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        return view('pages.request_show', ['request' => $requestModel]);
    }
}
