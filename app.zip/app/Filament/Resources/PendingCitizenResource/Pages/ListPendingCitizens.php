<?php

namespace App\Filament\Resources\PendingCitizenResource\Pages;

use App\Filament\Resources\PendingCitizenResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListPendingCitizens extends ListRecords
{
    protected static string $resource = PendingCitizenResource::class;

    protected function getHeaderActions(): array
    {
        return [];
    }
}
