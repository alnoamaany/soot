<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DeletedCitizenResource\Pages;
use App\Models\User;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class DeletedCitizenResource extends Resource
{
    protected static ?string $model = User::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-trash';

    protected static ?int $navigationSort = 90;

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة المستخدمين والأعضاء';
    }

    public static function getModelLabel(): string
    {
        return 'محذوفات النواب';
    }

    public static function getPluralModelLabel(): string
    {
        return 'محذوفات النواب';
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->whereNotNull('mp_deleted_at');
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('المواطن')
                    ->searchable(),

                TextColumn::make('email')
                    ->label('البريد'),

                TextColumn::make('mpDeletedByMp.display_name')
                    ->label('النائب المنفذ')
                    ->placeholder('غير محدد'),

                TextColumn::make('mp_deleted_reason')
                    ->label('سبب الحذف')
                    ->wrap(),

                TextColumn::make('mp_deleted_at')
                    ->label('تاريخ الحذف')
                    ->dateTime(),
            ])
            ->recordActions([
                Actions\EditAction::make()
                    ->visible(false),

                Actions\DeleteAction::make()
                    ->label('حذف نهائي')
                    ->requiresConfirmation(),

                Actions\Action::make('restore')
                    ->label('استعادة')
                    ->icon('heroicon-o-arrow-uturn-left')
                    ->color('success')
                    ->requiresConfirmation()
                    ->action(function (User $record) {
                        $record->update([
                            'mp_deleted_at' => null,
                            'mp_deleted_by_mp_id' => null,
                            'mp_deleted_reason' => null,
                        ]);

                        Notification::make()
                            ->title('تمت الاستعادة')
                            ->success()
                            ->send();
                    }),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDeletedCitizenResources::route('/'),
        ];
    }
}
