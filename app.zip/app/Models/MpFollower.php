<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Relations\Pivot;

#[Fillable(['user_id', 'mp_id'])]
class MpFollower extends Pivot
{
    protected $table = 'mp_followers';
}
