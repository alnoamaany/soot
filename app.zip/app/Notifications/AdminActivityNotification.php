<?php

namespace App\Notifications;

use App\Services\EmailTemplateService;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class AdminActivityNotification extends Notification
{
    public function __construct(
        public string $event,
        public string $title,
        public string $message,
        public ?string $url = null,
        public array $meta = [],
        private bool $sendEmail = true,
        private bool $saveToDatabase = true,
    ) {
    }

    public function via(object $notifiable): array
    {
        $channels = [];

        if ($this->saveToDatabase) {
            $channels[] = 'database';
        }

        if (
            $this->sendEmail
            && filled($notifiable->routeNotificationFor('mail'))
            && (EmailTemplateService::get('admin_activity')?->is_enabled ?? true)
        ) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toDatabase(object $notifiable): array
    {
        return [
            'title' => $this->title,
            'message' => $this->message,
            'event' => $this->event,
            'url' => $this->url,
            'meta' => $this->meta,
        ];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $settings = app(\App\Settings\GeneralSettings::class);

        $template = EmailTemplateService::render(
            'admin_activity',
            [
                'name' => $notifiable->name ?? 'مدير المنصة',
                'email' => $notifiable->routeNotificationFor('mail') ?? '',
                'event' => $this->event,
                'title' => $this->title,
                'message' => $this->message,
                'url' => $this->url ?? '',
                'site_name' => $settings->site_name ?? 'منصة صوتنا',
            ],
            [
                'subject' => '{title}',
                'greeting' => 'مرحبًا {name}',
                'body_html' => '{message}',
                'button_text' => 'فتح في لوحة الإدارة',
                'button_url' => '{url}',
                'footer' => 'هذا إشعار آلي من {site_name}.',
            ]
        );

        $mail = (new MailMessage)
            ->subject($template['subject'] ?: $this->title)
            ->greeting($template['greeting'] ?: 'مرحبًا')
            ->line($template['body_html'] ?: $this->message);

        if (filled($template['button_text']) && filled($template['button_url'])) {
            $mail->action($template['button_text'], $template['button_url']);
        }

        if (filled($template['footer'])) {
            $mail->line($template['footer']);
        }

        return $mail;
    }
}
