<?php

namespace App\Helper\Traits\Filamentv4;

use Illuminate\Contracts\Support\Htmlable;

trait FilamentTranslatedLabelResource
{
    /**
     * Plural Model Label.
     */
    // For Resources
    public static function getPluralModelLabel(): string
    {
        return __(ucwords(str(parent::getModelLabel())->plural()));
    }

    /**
     * Single Model Label.
     */
    // For Resources
    public static function getModelLabel(): string
    {
        return __(ucwords(parent::getModelLabel()));
    }

    public static function getNavigationLabel(): string
    {
        return __(parent::getNavigationLabel());
    }

    public function getHeading(): string|Htmlable
    {
        return __(parent::getHeading());
    }
}
