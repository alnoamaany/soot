<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Carbon\Carbon;

class MemberAd extends Model
{
    protected $fillable = [
        'member_id',
        'target_type',
        'title',
        'subtitle',
        'image',
        'url',
        'ad_type',
        'code',
        'position',
        'start_date',
        'end_date',
        'enabled',
        'priority',
        'max_views',
        'views',
        'clicks',
        'settings',
    ];


    protected $casts = [
        'enabled' => 'boolean',

        'start_date' => 'datetime',
        'end_date' => 'datetime',

        'settings' => 'array',
    ];




    public function getSettingsAttribute($value)
{
    $settings = json_decode($value ?? '{}', true) ?? [];

    return array_merge([
        'desktop_width'=>1200,
        'desktop_height'=>320,
        'tablet_width'=>768,
        'tablet_height'=>240,
        'mobile_width'=>360,
        'mobile_height'=>180,
        'fit'=>'cover',
        'position'=>'center',
    ], $settings);
}

    /**
     * العضو صاحب صفحة الإعلان
     */
    public function member(): BelongsTo
    {
        return $this->belongsTo(User::class, 'member_id');
    }


    /**
     * الإعلانات الحالية الصالحة للعرض
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query
            ->where('enabled', true)
            ->where(function ($q) {
                $q->whereNull('start_date')
                  ->orWhere('start_date', '<=', now());
            })
            ->where(function ($q) {
                $q->whereNull('end_date')
                  ->orWhere('end_date', '>=', now());
            })
            ->orderBy('priority');
    }


    /**
     * هل الإعلان متاح الآن؟
     */
    public function isActive(): bool
    {
        return $this->enabled
            && (!$this->start_date || $this->start_date <= now())
            && (!$this->end_date || $this->end_date >= now());
    }


    /**
     * زيادة عدد المشاهدات
     */
    public function registerView(): void
    {
        $this->increment('views');
    }


    /**
     * زيادة عدد الضغطات
     */
    public function registerClick(): void
    {
        $this->increment('clicks');
    }


    /**
     * حالة الإعلان
     */
    public function getStatusAttribute(): string
    {
        if (!$this->enabled) {
            return 'غير مفعل';
        }

        if ($this->end_date && $this->end_date < now()) {
            return 'منتهي';
        }

        if ($this->start_date && $this->start_date > now()) {
            return 'مجدول';
        }

        return 'نشط';
    }
public function canDisplay(): bool
{
    if (!$this->isActive()) {
        return false;
    }

    if ($this->max_views && $this->views >= $this->max_views) {
        return false;
    }

    return true;
}
}
