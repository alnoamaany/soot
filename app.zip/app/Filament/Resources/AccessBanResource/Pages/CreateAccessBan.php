<?php
namespace App\Filament\Resources\AccessBanResource\Pages;
use App\Filament\Resources\AccessBanResource;
use Filament\Resources\Pages\CreateRecord;
class CreateAccessBan extends CreateRecord { protected static string $resource=AccessBanResource::class; }
