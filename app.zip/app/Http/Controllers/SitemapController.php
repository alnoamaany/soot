<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Library;
use App\Models\Mp;
use App\Models\Post;
use Illuminate\Http\Response;

class SitemapController extends Controller
{
    /**
     * Generate dynamic XML sitemap for search engines.
     */
    public function index(): Response
    {
        $staticUrls = [
            [
                'loc' => route('home'),
                'lastmod' => now()->toAtomString(),
                'changefreq' => 'daily',
                'priority' => '1.0',
            ],
            [
                'loc' => route('members.index'),
                'lastmod' => now()->toAtomString(),
                'changefreq' => 'daily',
                'priority' => '0.9',
            ],
            [
                'loc' => route('blog.index'),
                'lastmod' => now()->toAtomString(),
                'changefreq' => 'daily',
                'priority' => '0.9',
            ],
            [
                'loc' => route('library.index'),
                'lastmod' => now()->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.8',
            ],
            [
                'loc' => route('apply.index'),
                'lastmod' => now()->startOfMonth()->toAtomString(),
                'changefreq' => 'monthly',
                'priority' => '0.8',
            ],
            [
                'loc' => route('contact.index'),
                'lastmod' => now()->startOfMonth()->toAtomString(),
                'changefreq' => 'monthly',
                'priority' => '0.7',
            ],
            [
                'loc' => route('about'),
                'lastmod' => now()->startOfMonth()->toAtomString(),
                'changefreq' => 'monthly',
                'priority' => '0.6',
            ],
            [
                'loc' => route('services.index'),
                'lastmod' => now()->startOfMonth()->toAtomString(),
                'changefreq' => 'monthly',
                'priority' => '0.6',
            ],
            [
                'loc' => route('faq.index'),
                'lastmod' => now()->startOfMonth()->toAtomString(),
                'changefreq' => 'monthly',
                'priority' => '0.6',
            ],
            [
                'loc' => route('privacy'),
                'lastmod' => now()->startOfYear()->toAtomString(),
                'changefreq' => 'yearly',
                'priority' => '0.5',
            ],
            [
                'loc' => route('terms'),
                'lastmod' => now()->startOfYear()->toAtomString(),
                'changefreq' => 'yearly',
                'priority' => '0.5',
            ],
        ];

        // 1. Members / MPs
        $mps = Mp::where('is_active', true)->get();
        $mpUrls = $mps->map(function ($mp) {
            return [
                'loc' => route('mp-page.show', $mp->id),
                'lastmod' => ($mp->updated_at ?? now())->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.8',
            ];
        })->toArray();

        // 2. Blog / News Categories
        $categories = Category::all();
        $categoryUrls = $categories->map(function ($cat) {
            return [
                'loc' => route('blog.category', $cat->slug),
                'lastmod' => ($cat->updated_at ?? now())->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.7',
            ];
        })->toArray();

        // 3. Blog / News Posts
        $posts = Post::where('is_published', true)->with('category')->get();
        $postUrls = $posts->map(function ($post) {
            $catSlug = $post->category->slug ?? 'general';
            return [
                'loc' => route('blog.show', ['category' => $catSlug, 'post' => $post->slug]),
                'lastmod' => ($post->published_at ?? $post->updated_at ?? now())->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.8',
            ];
        })->toArray();

        // 4. Video Library items
        $videos = Library::where('is_active', true)->get();
        $videoUrls = $videos->map(function ($video) {
            return [
                'loc' => route('library.index', ['v' => $video->id]),
                'lastmod' => ($video->published_at ?? $video->updated_at ?? now())->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.7',
            ];
        })->toArray();

        $allUrls = array_merge($staticUrls, $mpUrls, $categoryUrls, $postUrls, $videoUrls);

        $xml = '<?xml version="1.0" encoding="UTF-8"?>';
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">';

        foreach ($allUrls as $url) {
            $xml .= '<url>';
            $xml .= '<loc>' . htmlspecialchars($url['loc']) . '</loc>';
            if (!empty($url['lastmod'])) {
                $xml .= '<lastmod>' . $url['lastmod'] . '</lastmod>';
            }
            if (!empty($url['changefreq'])) {
                $xml .= '<changefreq>' . $url['changefreq'] . '</changefreq>';
            }
            if (!empty($url['priority'])) {
                $xml .= '<priority>' . $url['priority'] . '</priority>';
            }
            $xml .= '</url>';
        }

        $xml .= '</urlset>';

        return response($xml, 200, [
            'Content-Type' => 'application/xml',
            'X-Robots-Tag' => 'noindex, follow',
        ]);
    }
}
