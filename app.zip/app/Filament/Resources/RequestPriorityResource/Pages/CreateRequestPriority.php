<?php
namespace App\Filament\Resources\RequestPriorityResource\Pages;
use App\Filament\Resources\RequestPriorityResource;
use Filament\Resources\Pages\CreateRecord;
class CreateRequestPriority extends CreateRecord { protected static string $resource = RequestPriorityResource::class; }
