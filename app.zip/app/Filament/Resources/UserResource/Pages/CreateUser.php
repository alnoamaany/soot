<?php

namespace App\Filament\Resources\UserResource\Pages;

use App\Filament\Resources\UserResource;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Area;
use App\Rules\EgyptianPhone;
use Filament\Resources\Pages\CreateRecord;

class CreateUser extends CreateRecord
{
    protected static string $resource = UserResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        if (!empty($data['phone'])) {
            $data['phone'] = EgyptianPhone::normalize($data['phone']);
        }

        if (empty($data['email']) && !empty($data['phone'])) {
            $data['email'] = $data['phone'] . '@parliament.gov.eg';
        }

        $data['role'] = 'citizen';

        if (!empty($data['governorate_id'])) {
            $data['city'] = Governorate::where('id', $data['governorate_id'])->value('name_ar');
        }
        if (!empty($data['markaz_id'])) {
            $data['markaz'] = Markaz::where('id', $data['markaz_id'])->value('name_ar');
        }
        if (!empty($data['area_id'])) {
            $data['area'] = Area::where('id', $data['area_id'])->value('name_ar');
        }

        return $data;
    }
}
