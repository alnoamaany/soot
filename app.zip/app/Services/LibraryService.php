<?php

namespace App\Services;

use App\Models\Library;
use Illuminate\Pagination\LengthAwarePaginator;

class LibraryService
{
    /**
     * Get active library videos with pagination.
     *
     * @param int $perPage
     * @return LengthAwarePaginator
     */
    public function getActiveVideos(int $perPage = 12, ?int $categoryId = null): LengthAwarePaginator
    {
        return Library::query()
            ->where('is_active', true)
            ->whereNull('deleted_by_mp_at')
            ->when($categoryId, function ($query) use ($categoryId) {
                $category = \App\Models\LibraryCategory::find($categoryId);
                if ($category) {
                    $query->whereIn('library_category_id', $category->descendantIds(includeSelf: true));
                }
            })
            ->where(function ($query) {
                $query->whereNull('published_at')
                    ->orWhere('published_at', '<=', now());
            })
            ->with(['media'])
            ->latest('published_at')
            ->latest('id')
            ->paginate($perPage);
    }
}
