<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LibraryCategoryResource\Pages;
use App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
use App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
use App\Models\LibraryCategory;
use App\Rules\NoBlockedWords;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Infolists\Components\TextEntry;
use Illuminate\Validation\ValidationException;

class LibraryCategoryResource extends Resource
{
    use FilamentTranslatedLabelResource;
    use FilamentCountBadgeResource;

    protected static ?string $model = LibraryCategory::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-tag';
    protected static ?int $navigationSort = 1;

    public static function getModelLabel(): string { return 'تصنيف مكتبة مرئية'; }
    public static function getPluralModelLabel(): string { return 'تصنيفات المكتبة المرئية'; }
    public static function getNavigationLabel(): string { return 'تصنيفات المكتبة المرئية'; }
    public static function getNavigationGroup(): ?string { return 'المحتوى والوسائط'; }

    private static function parentOptions(?LibraryCategory $record = null): array
    {
        $all = LibraryCategory::query()->orderBy('sort_order')->orderBy('name')->get();
        $excluded = [];

        if ($record) {
            $excluded[] = $record->id;
            $pending = [$record->id];
            while ($pending) {
                $parentId = array_pop($pending);
                $children = $all->where('parent_id', $parentId)->pluck('id')->all();
                foreach ($children as $childId) {
                    $excluded[] = $childId;
                    $pending[] = $childId;
                }
            }
        }

        $options = [];
        $add = function ($parentId, string $prefix = '') use (&$add, &$options, $all, $excluded): void {
            foreach ($all->where('parent_id', $parentId)->sortBy([['sort_order', 'asc'], ['name', 'asc']]) as $category) {
                if (in_array($category->id, $excluded, true)) {
                    continue;
                }
                $options[$category->id] = $prefix . $category->name;
                $add($category->id, $prefix . '— ');
            }
        };

        $add(null);
        return $options;
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Grid::make(['default' => 1, 'md' => 1, 'xl' => 12])->schema([
                Section::make('معلومات التصنيف')
                    ->description('البيانات الأساسية لتصنيف المكتبة المرئية')
                    ->schema([
                        TextInput::make('name')
                            ->label('اسم التصنيف')
                            ->required()
                            ->rules([new NoBlockedWords()])
                            ->maxLength(255),
                        Textarea::make('description')
                            ->label('وصف التصنيف')
                            ->rows(5)
                            ->rules([new NoBlockedWords()])
                            ->maxLength(65535),
                    ])
                    ->columns(1)
                    ->columnSpan(['xl' => 7]),
                Section::make('هيكل وترتيب التصنيف')
                    ->description('حدد التصنيف الأب ورقم الظهور والرابط المختصر')
                    ->schema([
                        Select::make('parent_id')
                            ->label('التصنيف الأب')
                            ->options(fn (?LibraryCategory $record): array => static::parentOptions($record))
                            ->searchable()
                            ->preload()
                            ->nullable()
                            ->placeholder('تصنيف رئيسي — بدون أب')
                            ->helperText('اتركه فارغاً لإنشاء تصنيف رئيسي، أو اختر تصنيفاً أب لإنشاء تصنيف فرعي.')
                            ->columnSpanFull(),
                        Grid::make(['default' => 1, 'md' => 2])->schema([
                            TextInput::make('sort_order')
                                ->label('الترتيب')
                                ->numeric()
                                ->integer()
                                ->minValue(1)
                                ->default(fn (): int => (int) LibraryCategory::query()->max('sort_order') + 1)
                                ->required()
                                ->unique(ignoreRecord: true)
                                ->helperText('رقم فريد لا يتكرر داخل تصنيفات المكتبة، والأرقام الأصغر تظهر أولاً.'),
                            TextInput::make('slug')
                                ->label('الرابط المختصر')
                                ->helperText('يُنشأ تلقائياً من الاسم إذا تُرك فارغاً.')
                                ->maxLength(255)
                                ->unique(ignoreRecord: true),
                        ])->columnSpanFull(),
                    ])
                    ->columns(1)
                    ->columnSpan(['xl' => 5]),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('sort_order')
            ->reorderable('sort_order')
            ->columns([
                TextColumn::make('sort_order')->label('الترتيب')->sortable()->badge(),
                TextColumn::make('name')->label('التصنيف')->searchable()->sortable(),
                TextColumn::make('parent.name')->label('التصنيف الأب')->placeholder('رئيسي')->searchable(),
                TextColumn::make('children_count')->label('التصنيفات الفرعية')->counts('children')->badge()->sortable(),
                TextColumn::make('libraries_count')->label('عدد عناصر المكتبة')->counts('libraries')->badge()->sortable(),
                TextColumn::make('slug')->label('الرابط')->searchable()->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('created_at')->label('تاريخ الإنشاء')->dateTime()->sortable()->toggleable(isToggledHiddenByDefault: true),
            ])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make()->before(function (LibraryCategory $record): void {
                    if ($record->children()->exists() || $record->libraries()->exists()) {
                        throw ValidationException::withMessages([
                            'record' => 'لا يمكن حذف هذا التصنيف لأنه يحتوي على تصنيفات فرعية أو عناصر مكتبة مرتبطة به. انقل العناصر أولاً.',
                        ]);
                    }
                }),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('معلومات التصنيف')->columns(3)->schema([
                TextEntry::make('name')->label('اسم التصنيف'),
                TextEntry::make('parent.name')->label('التصنيف الأب')->placeholder('تصنيف رئيسي'),
                TextEntry::make('sort_order')->label('الترتيب'),
                TextEntry::make('slug')->label('الرابط'),
                TextEntry::make('children_count')->label('التصنيفات الفرعية')->state(fn (LibraryCategory $record): int => $record->children()->count()),
                TextEntry::make('libraries_count')->label('عدد عناصر المكتبة')->state(fn (LibraryCategory $record): int => $record->libraries()->count()),
                TextEntry::make('description')->label('الوصف')->placeholder('لا يوجد وصف')->columnSpanFull(),
            ]),
        ]);
    }

    public static function getRelations(): array { return []; }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLibraryCategories::route('/'),
            'create' => Pages\CreateLibraryCategory::route('/create'),
            'edit' => Pages\EditLibraryCategory::route('/{record}/edit'),
            'view' => Pages\ViewLibraryCategory::route('/{record}'),
        ];
    }
}
