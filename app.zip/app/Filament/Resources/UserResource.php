<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Pages;
use App\Filament\Resources\UserResource\RelationManagers;
use App\Models\User;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Infolists\Components\SpatieMediaLibraryImageEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Components\Section;
use Illuminate\Database\Eloquent\Builder;

class UserResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = User::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-users';
    protected static ?int $navigationSort = 1;

    public static function getModelLabel(): string
    {
        return 'مواطن';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المواطنون';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة المستخدمين والأعضاء';
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where(function ($query) {
                $query->where('role', '!=', 'mp')
                    ->orWhereNull('role');
            })
            ->whereDoesntHave('mp');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('البيانات الشخصية والحساب')
                ->schema([
                    SpatieMediaLibraryFileUpload::make('avatar')
                        ->collection('avatar')
                        ->label('الصورة الشخصية')
                        ->image()
                        ->avatar()
                        ->columnSpanFull(),
                    TextInput::make('name')
                        ->label('الاسم الكامل')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('phone')
                        ->label('رقم الهاتف')
                        ->required()
                        ->unique(table: 'users', column: 'phone', ignorable: fn (?User $record) => $record)
                        ->rules([new \App\Rules\EgyptianPhone()])
                        ->maxLength(64),
                    TextInput::make('password')
                        ->label('كلمة المرور')
                        ->password()
                        ->revealable()
                        ->required(fn (string $operation): bool => $operation === 'create')
                        ->dehydrated(fn (?string $state): bool => filled($state))
                        ->dehydrateStateUsing(fn (string $state): string => \Illuminate\Support\Facades\Hash::make($state))
                        ->minLength(8)
                        ->helperText(fn (string $operation): ?string => $operation === 'edit' ? 'اتركها فارغة للإبقاء على كلمة المرور الحالية' : null),
                    TextInput::make('national_id')
                        ->label('الرقم القومي (اختياري)')
                        ->unique(table: 'users', column: 'national_id', ignorable: fn (?User $record) => $record)
                        ->nullable()
                        ->length(14),
                    TextInput::make('email')
                        ->label('البريد الإلكتروني')
                        ->email()
                        ->unique(table: 'users', column: 'email', ignorable: fn (?User $record) => $record)
                        ->nullable()
                        ->maxLength(255),
                    Select::make('governorate_id')
                        ->label('المحافظة')
                        ->options(fn () => \App\Models\Governorate::orderBy('name_ar')->pluck('name_ar', 'id'))
                        ->searchable()
                        ->preload()
                        ->reactive()
                        ->afterStateUpdated(function (callable $set): void {
                            $set('markaz_id', null);
                            $set('area_id', null);
                        }),
                    Select::make('markaz_id')
                        ->label('المركز / القسم')
                        ->options(fn (callable $get) => filled($get('governorate_id'))
                            ? \App\Models\Markaz::where('governorate_id', $get('governorate_id'))->orderBy('name_ar')->pluck('name_ar', 'id')
                            : [])
                        ->searchable()
                        ->preload()
                        ->disabled(fn (callable $get): bool => blank($get('governorate_id')))
                        ->reactive()
                        ->afterStateUpdated(fn (callable $set) => $set('area_id', null)),
                    Select::make('area_id')
                        ->label('المنطقة / الحي')
                        ->options(fn (callable $get) => filled($get('markaz_id'))
                            ? \App\Models\Area::where('markaz_id', $get('markaz_id'))->orderBy('name_ar')->pluck('name_ar', 'id')
                            : [])
                        ->searchable()
                        ->preload()
                        ->disabled(fn (callable $get): bool => blank($get('markaz_id'))),
                    Textarea::make('detailed_address')
                        ->label('العنوان التفصيلي')
                        ->rows(3)
                        ->maxLength(1000)
                        ->columnSpanFull(),
                    Toggle::make('is_approved')
                        ->label('حساب مُفعّل ومعتمد')
                        ->default(true)
                        ->columnSpanFull(),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            SpatieMediaLibraryImageColumn::make('avatar')->collection('avatar')->label('الصورة'),
            TextColumn::make('name')->label('الاسم')->searchable()->sortable(),
            TextColumn::make('phone')->label('الهاتف')->searchable(),
            TextColumn::make('national_id')->label('الرقم القومي')->searchable()->placeholder('—'),
            TextColumn::make('email')->label('البريد الإلكتروني')->searchable(),
            // TextColumn::make('roles.name')->label('الأدوار')->badge(),
            TextColumn::make('governorate.name_ar')->label('المحافظة')->sortable(),
            TextColumn::make('markazModel.name_ar')->label('المركز'),
            IconColumn::make('is_approved')->boolean()->label('معتمد'),
            TextColumn::make('created_at')->label('تاريخ التسجيل')->dateTime()->sortable(),
        ])
        ->recordActions([
            Actions\Action::make('approve')
                ->label('اعتماد')
                ->icon('heroicon-o-check-circle')
                ->color('success')
                ->visible(fn (User $record): bool => ! $record->is_approved)
                ->requiresConfirmation()
                ->action(function (User $record): void {
                    $record->update(['is_approved' => true]);
                    \Filament\Notifications\Notification::make()
                        ->title('تم اعتماد الحساب بنجاح')
                        ->success()
                        ->send();
                }),
            Actions\ViewAction::make(),
            Actions\EditAction::make(),
            Actions\DeleteAction::make(),
        ])
        ->toolbarActions([
            Actions\BulkActionGroup::make([
                Actions\BulkAction::make('approve_selected')
                    ->label('اعتماد المحدد')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->requiresConfirmation()
                    ->action(function (\Illuminate\Database\Eloquent\Collection $records): void {
                        $records->each->update(['is_approved' => true]);
                        \Filament\Notifications\Notification::make()
                            ->title('تم اعتماد الحسابات المحددة بنجاح')
                            ->success()
                            ->send();
                    }),
                Actions\DeleteBulkAction::make(),
            ]),
        ])
        ->filters([
            \Filament\Tables\Filters\TernaryFilter::make('is_approved')
                ->label('حالة الاعتماد')
                ->trueLabel('المعتمدون فقط')
                ->falseLabel('بانتظار الموافقة فقط'),
        ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('المعلومات الأساسية')->schema([
                TextEntry::make('name')->label('الاسم الكامل'),
                TextEntry::make('phone')->label('رقم الهاتف'),
                TextEntry::make('national_id')->label('الرقم القومي')->placeholder('غير محدد'),
                TextEntry::make('email')->label('البريد الإلكتروني'),
                TextEntry::make('governorate.name_ar')->label('المحافظة'),
                TextEntry::make('markazModel.name_ar')->label('المركز/القسم'),
                TextEntry::make('areaModel.name_ar')->label('المنطقة/الحي'),
                TextEntry::make('is_approved')
                    ->label('حالة التفعيل')
                    ->formatStateUsing(fn ($state) => $state ? 'مُفعّل ومعتمد' : 'غير مُفعّل'),
            ]),
        ]);
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\RequestsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
            'view' => Pages\ViewUser::route('/{record}'),
        ];
    }
}
