<?php

namespace App\Http\Controllers;

use App\Models\PlatformImportantNotification;
use Illuminate\Http\Request;

class ImportantNotificationController extends Controller
{
    public function index(Request $request)
    {
        abort_unless($request->user(), 403);

        $notifications = PlatformImportantNotification::query()
            ->visibleTo($request->user())
            ->latest('sent_at')
            ->latest('id')
            ->paginate(15);

        return view('pages.important_notifications', compact('notifications'));
    }
}
