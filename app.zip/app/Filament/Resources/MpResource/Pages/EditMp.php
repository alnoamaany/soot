<?php

namespace App\Filament\Resources\MpResource\Pages;

use App\Filament\Resources\MpResource;
use App\Models\Area;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\MpSubscription;
use App\Models\SubscriptionPlan;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Validation\ValidationException;

class EditMp extends EditRecord
{
    protected static string $resource = MpResource::class;

    private ?int $subscriptionPlanId = null;
    private array $userData = [];
    private ?string $avatarPath = null;

    protected function mutateFormDataBeforeFill(array $data): array
    {
        $user = $this->record->user;
        if ($user) {
            $data['user_name'] = $user->name;
            $data['user_email'] = $user->email;
            $data['user_phone'] = $user->phone;
            $data['user_national_id'] = $user->national_id;
            $data['user_governorate_id'] = $user->governorate_id;
            $data['user_markaz_id'] = $user->markaz_id;
            $data['user_area_id'] = $user->area_id;
            $data['user_detailed_address'] = $user->detailed_address;
        }

        $activeSub = $this->record->subscriptions()->where('status', 'active')->latest()->first();
        if ($activeSub) {
            $data['subscription_plan_id'] = $activeSub->subscription_plan_id;
        }

        return $data;
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        $this->subscriptionPlanId = !empty($data['subscription_plan_id']) ? (int) $data['subscription_plan_id'] : null;
        $this->avatarPath = is_string($data['user_avatar'] ?? null) ? $data['user_avatar'] : null;

        $governorateName = !empty($data['user_governorate_id']) ? Governorate::where('id', $data['user_governorate_id'])->value('name_ar') : null;
        $markazName = !empty($data['user_markaz_id']) ? Markaz::where('id', $data['user_markaz_id'])->value('name_ar') : null;
        $areaName = !empty($data['user_area_id']) ? Area::where('id', $data['user_area_id'])->value('name_ar') : null;

        $this->userData = [
            'name' => $data['user_name'] ?? null,
            'email' => $data['user_email'] ?? null,
            'phone' => !empty($data['user_phone']) ? \App\Rules\EgyptianPhone::normalize($data['user_phone']) : null,
            'national_id' => $data['user_national_id'] ?? null,
            'city' => $governorateName,
            'markaz' => $markazName,
            'area' => $areaName,
            'governorate_id' => $data['user_governorate_id'] ?? null,
            'markaz_id' => $data['user_markaz_id'] ?? null,
            'area_id' => $data['user_area_id'] ?? null,
            'detailed_address' => $data['user_detailed_address'] ?? null,
        ];

        if (!empty($data['user_password'])) {
            $this->userData['password'] = $data['user_password'];
        }

        $this->ensureLocationHierarchy();

        unset(
            $data['subscription_plan_id'],
            $data['user_name'],
            $data['user_email'],
            $data['user_phone'],
            $data['user_national_id'],
            $data['user_password'],
            $data['user_governorate_id'],
            $data['user_markaz_id'],
            $data['user_area_id'],
            $data['user_detailed_address'],
            $data['user_avatar'],
        );

        return $data;
    }

    private function ensureLocationHierarchy(): void
    {
        $governorateId = $this->userData['governorate_id'] ?? null;
        $markazId = $this->userData['markaz_id'] ?? null;
        $areaId = $this->userData['area_id'] ?? null;

        if ($markazId && $governorateId && ! Markaz::whereKey($markazId)->where('governorate_id', $governorateId)->exists()) {
            throw ValidationException::withMessages([
                'user_markaz_id' => 'المركز المختار لا يتبع المحافظة المختارة.',
            ]);
        }

        if ($areaId && $markazId && $governorateId && ! Area::whereKey($areaId)->where('markaz_id', $markazId)->where('governorate_id', $governorateId)->exists()) {
            throw ValidationException::withMessages([
                'user_area_id' => 'المنطقة المختارة لا تتبع المركز والمحافظة المختارين.',
            ]);
        }
    }

    protected function afterSave(): void
    {
        $user = $this->record->user;
        if ($user) {
            $user->update(array_filter($this->userData, fn ($val, $key) => $val !== null || in_array($key, ['governorate_id', 'markaz_id', 'area_id', 'detailed_address', 'city', 'markaz', 'area']), ARRAY_FILTER_USE_BOTH));

            if ($this->avatarPath) {
                $user->clearMediaCollection('avatar');
                $user->addMediaFromDisk($this->avatarPath, 'public')->toMediaCollection('avatar');
            }
        }

        if ($this->subscriptionPlanId) {
            $activeSub = $this->record->subscriptions()->where('status', 'active')->latest()->first();
            if ($activeSub) {
                if ($activeSub->subscription_plan_id !== $this->subscriptionPlanId) {
                    $plan = SubscriptionPlan::find($this->subscriptionPlanId);
                    $activeSub->update([
                        'subscription_plan_id' => $this->subscriptionPlanId,
                        'price' => $plan?->price ?? $activeSub->price,
                        'free_days' => $plan?->free_days ?? $activeSub->free_days,
                    ]);
                }
            } else {
                MpSubscription::create([
                    'mp_id' => $this->record->id,
                    'subscription_plan_id' => $this->subscriptionPlanId,
                    'status' => 'active',
                ]);
            }
        }
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
