<?php

namespace App\Filament\Widgets;

use App\Models\MpRequest;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Facades\DB;

class RequestsStatusChart extends ChartWidget
{
    protected ?string $heading = 'توزيع الطلبات حسب الحالة';
    
    protected static ?int $sort = 2;
    
    // Make this chart take up half the width
    protected int | string | array $columnSpan = [
        'md' => 1,
        'xl' => 1,
    ];

    protected function getData(): array
    {
        $data = MpRequest::select('status', DB::raw('count(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status')
            ->toArray();

        $labels = array_map(function ($status) {
            return match ($status) {
                'open' => 'مفتوح',
                'in_progress' => 'قيد المعالجة',
                'resolved' => 'تم الحل',
                'closed' => 'مغلق',
                default => $status,
            };
        }, array_keys($data));

        return [
            'datasets' => [
                [
                    'label' => 'عدد الطلبات',
                    'data' => array_values($data),
                    'backgroundColor' => [
                        '#6366F1', '#10B981', '#F59E0B', '#EF4444', '#3B82F6', '#8B5CF6'
                    ],
                ],
            ],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'pie';
    }
}
