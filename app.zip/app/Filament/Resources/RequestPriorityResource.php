<?php

namespace App\Filament\Resources;

use App\Filament\Resources\RequestPriorityResource\Pages;
use App\Models\RequestPriority;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class RequestPriorityResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = RequestPriority::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-exclamation-triangle';
    public static function getNavigationGroup(): ?string { return 'إعدادات الطلبات'; }
    public static function getModelLabel(): string { return 'أولوية طلب'; }
    public static function getPluralModelLabel(): string { return 'أولويات الطلبات'; }
    public static function getEloquentQuery(): Builder { return parent::getEloquentQuery()->withCount('requests'); }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('name')->label('اسم الأولوية')->required()->unique(ignoreRecord: true)->maxLength(255),
            Select::make('color')->label('اللون')->options(['gray' => 'رمادي', 'primary' => 'أساسي', 'info' => 'أزرق', 'success' => 'أخضر', 'warning' => 'أصفر', 'danger' => 'أحمر'])->default('gray')->required(),
            TextInput::make('sort_order')->label('ترتيب العرض')->numeric()->default(0)->required(),
            Toggle::make('is_active')->label('نشطة')->default(true),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->label('الأولوية')->searchable()->sortable(),
            TextColumn::make('requests_count')->label('عدد الطلبات')->badge()->color('primary')->sortable(),
            TextColumn::make('sort_order')->label('الترتيب')->sortable(),
            IconColumn::make('is_active')->label('نشطة')->boolean(),
        ])->recordActions([
            Actions\EditAction::make(),
            Actions\DeleteAction::make()->disabled(fn (RequestPriority $record): bool => $record->requests()->exists())->tooltip('لا يمكن حذف أولوية مرتبطة بطلبات.'),
        ]);
    }

    public static function getPages(): array { return ['index' => Pages\ListRequestPriorities::route('/'), 'create' => Pages\CreateRequestPriority::route('/create'), 'edit' => Pages\EditRequestPriority::route('/{record}/edit')]; }
}
