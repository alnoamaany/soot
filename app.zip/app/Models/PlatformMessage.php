<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class PlatformMessage extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    protected $fillable = ['mp_id', 'sender_type', 'sender_id', 'recipient_type', 'recipient_id', 'subject', 'message', 'sent_at'];

    protected function casts(): array
    {
        return ['sent_at' => 'datetime'];
    }

    public function mp() { return $this->belongsTo(Mp::class); }
    public function admin() { return $this->belongsTo(Admin::class); }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('attachments');
    }
}
