<?php

declare(strict_types=1);

namespace App\Policies;

use Illuminate\Foundation\Auth\User as AuthUser;
use App\Models\Markaz;
use Illuminate\Auth\Access\HandlesAuthorization;

class MarkazPolicy
{
    use HandlesAuthorization;
    
    public function viewAny(AuthUser $authUser): bool
    {
        return $authUser->can('ViewAny:Markaz');
    }

    public function view(AuthUser $authUser, Markaz $markaz): bool
    {
        return $authUser->can('View:Markaz');
    }

    public function create(AuthUser $authUser): bool
    {
        return $authUser->can('Create:Markaz');
    }

    public function update(AuthUser $authUser, Markaz $markaz): bool
    {
        return $authUser->can('Update:Markaz');
    }

    public function delete(AuthUser $authUser, Markaz $markaz): bool
    {
        return $authUser->can('Delete:Markaz');
    }

    public function deleteAny(AuthUser $authUser): bool
    {
        return $authUser->can('DeleteAny:Markaz');
    }

    public function restore(AuthUser $authUser, Markaz $markaz): bool
    {
        return $authUser->can('Restore:Markaz');
    }

    public function forceDelete(AuthUser $authUser, Markaz $markaz): bool
    {
        return $authUser->can('ForceDelete:Markaz');
    }

    public function forceDeleteAny(AuthUser $authUser): bool
    {
        return $authUser->can('ForceDeleteAny:Markaz');
    }

    public function restoreAny(AuthUser $authUser): bool
    {
        return $authUser->can('RestoreAny:Markaz');
    }

    public function replicate(AuthUser $authUser, Markaz $markaz): bool
    {
        return $authUser->can('Replicate:Markaz');
    }

    public function reorder(AuthUser $authUser): bool
    {
        return $authUser->can('Reorder:Markaz');
    }

}