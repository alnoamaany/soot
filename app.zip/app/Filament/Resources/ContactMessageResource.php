<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ContactMessageResource\Pages;
use App\Models\ContactMessage;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\SpatieMediaLibraryImageEntry;

class ContactMessageResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = ContactMessage::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-envelope';

    public static function getNavigationGroup(): ?string
    {
        return __('الدعم والاتصالات');
    }

    public static function getModelLabel(): string
    {
        return __('رسالة اتصل بنا');
    }

    public static function getPluralModelLabel(): string
    {
        return __('رسائل اتصل بنا');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات الرسالة')->schema([
                TextInput::make('name')->label('الاسم')->required(),
                TextInput::make('phone')->label('الهاتف')->required(),
                TextInput::make('email')->label('البريد الإلكتروني'),
                Select::make('type')->label('نوع الرسالة')->options([
                    'inquiry' => 'استفسار عام',
                    'complaint' => 'شكوى',
                    'suggestion' => 'مقترح',
                    'other' => 'أخرى',
                ])->required(),
                Textarea::make('message')->label('نص الرسالة')->required()->columnSpanFull(),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->label('الاسم')->searchable()->sortable(),
            TextColumn::make('phone')->label('الهاتف')->searchable(),
            TextColumn::make('email')->label('البريد الإلكتروني')->searchable(),
            TextColumn::make('type')->label('نوع الرسالة')->formatStateUsing(fn(string $state): string => match ($state) {
                'inquiry' => 'استفسار عام',
                'complaint' => 'شكوى',
                'suggestion' => 'مقترح',
                    'other' => 'أخرى',
                default => $state,
            })->badge(),
            TextColumn::make('created_at')->label('تاريخ الإرسال')->dateTime()->sortable(),
        ])
        ->recordActions([
            Actions\ViewAction::make(),
            Actions\DeleteAction::make(),
        ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('تفاصيل الرسالة')->schema([
                TextEntry::make('name')->label('اسم المرسل'),
                TextEntry::make('phone')->label('رقم الهاتف'),
                TextEntry::make('email')->label('البريد الإلكتروني'),
                TextEntry::make('type')->label('نوع الرسالة')->formatStateUsing(fn(string $state): string => match ($state) {
                    'inquiry' => 'استفسار عام',
                    'complaint' => 'شكوى',
                    'suggestion' => 'مقترح',
                    'other' => 'أخرى',
                    default => $state,
                }),
                TextEntry::make('message')->label('نص الرسالة')->columnSpanFull(),
                TextEntry::make('created_at')->label('تاريخ ووقت الإرسال')->dateTime(),
            ]),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListContactMessages::route('/'),
            'view' => Pages\ViewContactMessage::route('/{record}'),
        ];
    }
}
