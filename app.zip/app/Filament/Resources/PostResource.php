<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PostResource\Pages;
use App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
use App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
use App\Models\Post;
use App\Rules\NoBlockedWords;
use Filament\Actions;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Group;
use Filament\Forms\Components\RichEditor;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DateTimePicker;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use Filament\Infolists;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\SpatieMediaLibraryImageEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Infolist;

class PostResource extends Resource
{
    use FilamentTranslatedLabelResource;
    use FilamentCountBadgeResource;

    protected static ?string $model = Post::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-document-text';

    protected static ?int $navigationSort = 2;

    public static function getModelLabel(): string
    {
        return 'مقال / خبر';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المقالات والأخبار';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'المركز الإعلامي';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([


                            Section::make(__('معلومات المقال'))
                                ->schema([
                                    TextInput::make('title')
                                        ->translateLabel()
                                        ->required()
                                        ->maxLength(255)
                                        ->rules([new NoBlockedWords()])
                                        ->placeholder('أدخل عنوان المقال'),

                                    RichEditor::make('content')
                                        ->translateLabel()
                                        ->rules([new NoBlockedWords()])
                                        ->required()
                                        ->columnSpanFull(),
                                ]),
                  

                            Section::make(__('إعدادات النشر'))
                                ->schema([
                                    Select::make('mp_id')
                                        ->label('النائب صاحب الخبر / التحديث')
                                        ->options(fn () => \App\Models\Mp::with('user')->where('is_active', true)->get()->mapWithKeys(fn ($mp) => [$mp->id => $mp->display_name]))
                                        ->placeholder('عام (للمركز الإعلامي — الإدارة)')
                                        ->searchable()->preload()->nullable(),

                                    Select::make('category_id')
                                        ->relationship('category', 'name')
                                        ->translateLabel()
                                        ->required()
                                        ->searchable()
                                        ->preload(),

                                    TextInput::make('sort_order')
                                        ->label('ترتيب الظهور داخل التصنيف')
                                        ->numeric()
                                        ->minValue(1)
                                        ->default(fn (?Post $record) => $record?->sort_order ?: null)
                                        ->required()
                                        ->unique(ignoreRecord: true, modifyRuleUsing: function ($rule, $get) {
                                            return $rule->where('category_id', $get('category_id'));
                                        })
                                        ->helperText('رقم فريد داخل التصنيف فقط. الأصغر يظهر أولاً.'),

                                    Toggle::make('is_published')
                                        ->translateLabel()
                                        ->default(true)
                                        ->required(),

                                    DateTimePicker::make('published_at')
                                        ->translateLabel()
                                        ->default(now()),
                                ]),

                            Section::make(__('الوسائط'))
                                ->schema([
                                    SpatieMediaLibraryFileUpload::make('thumbnail')
                                        ->collection('thumbnail')
                                        ->translateLabel()
                                        ->image()
                                        ->imageEditor(),
                                ]),


            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                SpatieMediaLibraryImageColumn::make('thumbnail')
                    ->collection('thumbnail')
                    ->translateLabel(),

                TextColumn::make('title')
                    ->translateLabel()
                    ->searchable()
                    ->sortable()
                    ->limit(50),

                TextColumn::make('category.name')
                    ->translateLabel()
                    ->sortable()
                    ->searchable(),

                TextColumn::make('sort_order')
                    ->label('الترتيب')
                    ->sortable(),

                IconColumn::make('is_published')
                    ->translateLabel()
                    ->boolean(),

                TextColumn::make('published_at')
                    ->translateLabel()
                    ->dateTime()
                    ->sortable(),

                TextColumn::make('created_at')
                    ->translateLabel()
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('category')
                    ->relationship('category', 'name')
                    ->translateLabel(),

                TernaryFilter::make('is_published')
                    ->translateLabel(),
            ])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('المعلومات الأساسية')
                    ->icon('heroicon-o-information-circle')
                    ->columns(3)
                    ->schema([
                        TextEntry::make('title')
                            ->translateLabel()
                            ->icon('heroicon-o-document-text')
                            ->columnSpanFull(),

                        TextEntry::make('category.name')
                            ->translateLabel()
                            ->icon('heroicon-o-tag'),
                    ]),

                Section::make(__('Details'))
                    ->icon('heroicon-o-document-text')
                    ->columns(1)
                    ->schema([
                        TextEntry::make('content')
                            ->translateLabel()
                            ->html()
                            ->columnSpanFull(),
                    ]),

                Section::make('الوسائط')
                    ->icon('heroicon-o-photo')
                    ->columns(2)
                    ->schema([
                        SpatieMediaLibraryImageEntry::make('thumbnail')
                            ->collection('thumbnail')
                            ->translateLabel()
                            ->columnSpanFull(),
                    ]),

                Section::make('الحالة والإعدادات')
                    ->icon('heroicon-o-cog-6-tooth')
                    ->columns(2)
                    ->schema([
                        IconEntry::make('is_published')
                            ->translateLabel()
                            ->boolean(),
                    ]),

                Section::make('التواريخ والأوقات')
                    ->icon('heroicon-o-clock')
                    ->columns(2)
                    ->collapsed()
                    ->schema([
                        TextEntry::make('published_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                        TextEntry::make('created_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-calendar'),
                        TextEntry::make('updated_at')
                            ->translateLabel()
                            ->dateTime()
                            ->icon('heroicon-o-arrow-path'),
                    ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPosts::route('/'),
            'create' => Pages\CreatePost::route('/create'),
            'edit' => Pages\EditPost::route('/{record}/edit'),
            'view' => Pages\ViewPost::route('/{record}'),
        ];
    }
}
