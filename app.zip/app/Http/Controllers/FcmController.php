<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FcmController extends Controller
{
    public function storeToken(Request $request)
    {
        $request->validate([
            'fcm_token' => 'required|string',
        ]);

        if (auth()->check()) {
            auth()->user()->update(['fcm_token' => $request->fcm_token]);
            return response()->json(['message' => 'Token saved successfully']);
        }

        return response()->json(['message' => 'Unauthorized'], 401);
    }
}
