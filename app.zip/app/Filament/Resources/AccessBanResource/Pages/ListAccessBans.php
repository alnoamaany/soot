<?php
namespace App\Filament\Resources\AccessBanResource\Pages;
use App\Filament\Resources\AccessBanResource;
use Filament\Resources\Pages\ListRecords;
class ListAccessBans extends ListRecords { protected static string $resource=AccessBanResource::class; }
