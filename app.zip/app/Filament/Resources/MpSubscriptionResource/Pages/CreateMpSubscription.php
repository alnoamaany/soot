<?php
namespace App\Filament\Resources\MpSubscriptionResource\Pages;
use App\Filament\Resources\MpSubscriptionResource;
use Filament\Resources\Pages\CreateRecord;
class CreateMpSubscription extends CreateRecord { protected static string $resource = MpSubscriptionResource::class; }
