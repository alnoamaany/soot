<?php

namespace App\Services;

use App\Models\Category;
use App\Models\Post;
use Illuminate\Pagination\LengthAwarePaginator;

class BlogService
{
    /**
     * Get the latest published post for the hero section.
     */
    public function getLatestPost(): ?Post
    {
        return Post::with(['category', 'media'])
            ->where('is_published', true)
            ->whereNull('mp_id')
            ->where(function ($query) {
                $query->whereNull('published_at')
                    ->orWhere('published_at', '<=', now());
            })
            ->latest('published_at')
            ->latest('id')
            ->first();
    }

    /**
     * Get paginated published posts (excluding the latest post if provided).
     */
    public function getPaginatedPosts(int $perPage = 12, ?int $excludePostId = null): LengthAwarePaginator
    {
        return Post::with(['category', 'media'])
            ->where('is_published', true)
            ->whereNull('mp_id')
            ->where(function ($query) {
                $query->whereNull('published_at')
                    ->orWhere('published_at', '<=', now());
            })
            ->when($excludePostId, function ($query) use ($excludePostId) {
                $query->where('id', '!=', $excludePostId);
            })
            ->latest('published_at')
            ->latest('id')
            ->paginate($perPage);
    }

    /**
     * Get paginated posts for a specific category.
     */
    public function getPostsByCategory(Category $category, int $perPage = 12): LengthAwarePaginator
    {
        return Post::query()
            ->whereIn('category_id', $category->descendantIds(includeSelf: true))
            ->with(['category', 'media'])
            ->where('is_published', true)
            ->whereNull('mp_id')
            ->where(function ($query) {
                $query->whereNull('published_at')
                    ->orWhere('published_at', '<=', now());
            })
            ->latest('published_at')
            ->latest('id')
            ->paginate($perPage);
    }
}
