<?php

namespace App\Http\Controllers;

use App\Services\LibraryService;
use App\Models\LibraryCategory;
use Illuminate\Http\Request;
use Illuminate\View\View;

class LibraryController extends Controller
{
    /**
     * The library service instance.
     *
     * @var LibraryService
     */
    protected $libraryService;

    /**
     * Create a new controller instance.
     *
     * @param LibraryService $libraryService
     */
    public function __construct(LibraryService $libraryService)
    {
        $this->libraryService = $libraryService;
    }

    /**
     * Display a listing of the library videos.
     *
     * @return View
     */
    public function index(Request $request): View
    {
        $categoryId = $request->integer('category');
        $videos = $this->libraryService->getActiveVideos(12, $categoryId ?: null);
        $categories = LibraryCategory::query()
            ->whereNull('parent_id')
            ->with(['children' => fn ($query) => $query->withCount(['libraries' => fn ($q) => $q->where('is_active', true)])->ordered()])
            ->withCount(['libraries' => fn ($q) => $q->where('is_active', true)])
            ->where(function ($query) {
                $query->whereHas('libraries', fn ($q) => $q->where('is_active', true))
                    ->orWhereHas('children.libraries', fn ($q) => $q->where('is_active', true));
            })
            ->ordered()
            ->get();

        return view('pages.library', compact('videos', 'categories'));
    }
}
