<?php

namespace App\Filament\Pages\Reports;

use App\Models\Library;
use App\Models\Mp;
use App\Models\MpVideo;
use App\Models\MpVideoCategory;
use Filament\Pages\Page;
use Livewire\WithPagination;

class MediaAndVideosReport extends Page
{
    use WithPagination;

    protected string $view = 'filament.pages.reports.media-and-videos-report';

    public static function getNavigationIcon(): string | \Illuminate\View\ComponentAttributeBag | null
    {
        return 'heroicon-o-video-camera';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'التقارير والإحصائيات البرلمانية';
    }

    public static function getNavigationSort(): ?int
    {
        return 6;
    }

    public static function getNavigationLabel(): string
    {
        return 'تقرير المكتبات المرئية والوسائط';
    }

    public function getTitle(): string | \Illuminate\Contracts\Support\Htmlable
    {
        return 'تقرير المكتبات المرئية وقنوات النواب';
    }

    public static function getBreadcrumb(): string
    {
        return 'تقرير المكتبات المرئية';
    }

    public ?string $mpId = 'all';
    public int $perPage = 25;

    public function updatingMpId(): void { $this->resetPage(); }
    public function updatingPerPage(): void { $this->resetPage(); }

    public function resetFilters(): void
    {
        $this->mpId = 'all';
        $this->perPage = 25;
        $this->resetPage();
    }

    public function getViewData(): array
    {
        $vQuery = MpVideo::query();

        if ($this->mpId && $this->mpId !== 'all') {
            $vQuery->where('mp_id', $this->mpId);
        }

        $totalVideos = (clone $vQuery)->count();
        $totalLibraryItems = Library::count();

        // Paginated videos list
        $videos = (clone $vQuery)
            ->with(['mp', 'category'])
            ->latest('published_at')
            ->paginate($this->perPage);

        $libraryItems = Library::latest('published_at')->take(50)->get();
        $categoriesBreakdown = MpVideoCategory::withCount('videos')->get();

        return [
            'videos' => $videos,
            'totalVideos' => $totalVideos,
            'totalLibraryItems' => $totalLibraryItems,
            'libraryItems' => $libraryItems,
            'categoriesBreakdown' => $categoriesBreakdown,
            'mpsList' => Mp::with('user:id,name')->select('id', 'user_id', 'title')->get(),
        ];
    }
}
