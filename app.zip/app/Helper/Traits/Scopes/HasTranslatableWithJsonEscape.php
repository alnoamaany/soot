<?php

namespace App\Helper\Traits\Scopes;

use Spatie\Translatable\HasTranslations;

trait HasTranslatableWithJsonEscape
{
    use HasTranslations;

    /**
     * Encode the given value as JSON.
     */
    protected function asJson(mixed $value, $flags = 0): string
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE);
    }
}
