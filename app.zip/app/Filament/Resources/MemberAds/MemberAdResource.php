<?php

namespace App\Filament\Resources\MemberAds;

use App\Filament\Resources\MemberAds\Pages\CreateMemberAd;
use App\Filament\Resources\MemberAds\Pages\EditMemberAd;
use App\Filament\Resources\MemberAds\Pages\ListMemberAds;
use App\Filament\Resources\MemberAds\Schemas\MemberAdForm;
use App\Filament\Resources\MemberAds\Tables\MemberAdsTable;
use App\Models\MemberAd;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class MemberAdResource extends Resource
{
    protected static ?string $model = MemberAd::class;
public static function getNavigationLabel(): string
{
    return 'الإعلانات داخل صفحات الأعضاء';
}

public static function getNavigationGroup(): ?string
{
    return 'الدعاية والإعلان';
}

public static function getNavigationSort(): ?int
{
    return 2;
}
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedMegaphone;

    public static function form(Schema $schema): Schema
    {
        return MemberAdForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return MemberAdsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListMemberAds::route('/'),
            'create' => CreateMemberAd::route('/create'),
            'edit' => EditMemberAd::route('/{record}/edit'),
        ];
    }
}
