<?php

namespace App\Filament\Widgets;

use App\Models\MpRequest;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use Filament\Tables\Columns\TextColumn;

class LatestRequestsWidget extends BaseWidget
{
    public static function canView(): bool
    {
        return (bool) app(\App\Settings\GeneralSettings::class)->latest_requests_widget_enabled;
    }

    protected static ?int $sort = 4;

    protected static ?string $heading = 'أحدث الطلبات المقدمة';

    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                MpRequest::query()->latest()->limit(5)
            )
            ->columns([
                TextColumn::make('reference_number')
                    ->label('رقم الطلب')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('user.name')
                    ->label('المواطن')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('mp.user.name')
                    ->label('النائب')
                    ->formatStateUsing(fn ($state, MpRequest $record) => $record->mp?->display_name ?: ($state ?: 'طلب عام'))
                    ->placeholder('طلب عام')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('requestType.name')
                    ->label('نوع الطلب')
                    ->badge()
                    ->placeholder(fn (MpRequest $record) => $record->type ?: 'غير محدد')
                    ->sortable(),

                TextColumn::make('requestStatus.name')
                    ->label('الحالة')
                    ->badge()
                    ->placeholder(fn (MpRequest $record) => match ($record->status) {
                        'open' => 'مفتوح',
                        'in_progress' => 'قيد المعالجة',
                        'resolved' => 'تم الحل',
                        'closed' => 'مغلق',
                        default => $record->status ?: 'غير محدد',
                    })
                    ->color(fn (MpRequest $record) => $record->requestStatus?->color ?? match ($record->status) {
                        'open' => 'warning',
                        'in_progress' => 'info',
                        'resolved' => 'success',
                        'closed' => 'danger',
                        default => 'gray',
                    }),

                TextColumn::make('created_at')
                    ->label('تاريخ التقديم')
                    ->dateTime()
                    ->sortable(),
            ])
            ->paginated(false);
    }
}
