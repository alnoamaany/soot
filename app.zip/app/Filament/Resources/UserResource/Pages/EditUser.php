<?php

namespace App\Filament\Resources\UserResource\Pages;

use App\Filament\Resources\UserResource;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Area;
use App\Rules\EgyptianPhone;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditUser extends EditRecord
{
    protected static string $resource = UserResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\ViewAction::make(),
            Actions\DeleteAction::make(),
        ];
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        if (!empty($data['phone'])) {
            $data['phone'] = EgyptianPhone::normalize($data['phone']);
        }

        if (empty($data['email']) && !empty($data['phone'])) {
            $data['email'] = $data['phone'] . '@parliament.gov.eg';
        }

        if (!empty($data['governorate_id'])) {
            $data['city'] = Governorate::where('id', $data['governorate_id'])->value('name_ar');
        }
        if (!empty($data['markaz_id'])) {
            $data['markaz'] = Markaz::where('id', $data['markaz_id'])->value('name_ar');
        }
        if (!empty($data['area_id'])) {
            $data['area'] = Area::where('id', $data['area_id'])->value('name_ar');
        }

        return $data;
    }
}
