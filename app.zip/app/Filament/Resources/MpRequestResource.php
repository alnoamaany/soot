<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MpRequestResource\Pages;
use App\Models\Mp;
use App\Models\MpRequest;
use App\Models\RequestPriority;
use App\Models\RequestStatus;
use App\Models\RequestType;
use App\Models\User;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class MpRequestResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = MpRequest::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-inbox-stack';
    protected static ?int $navigationSort = 1;
    public static function getNavigationGroup(): ?string { return 'طلبات المواطنين'; }

    public static function shouldRegisterNavigation(): bool
    {
        try {
            return (bool) app(\App\Settings\GeneralSettings::class)->citizen_requests_enabled;
        } catch (\Throwable $e) {
            return true;
        }
    }
    public static function getModelLabel(): string { return 'طلب مواطن'; }
    public static function getPluralModelLabel(): string { return 'طلبات المواطنين'; }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([Section::make('بيانات الطلب')->schema([
            Select::make('user_id')->label('المواطن')->options(fn () => User::orderBy('name')->pluck('name', 'id'))->searchable()->required(),
            Select::make('mp_id')->label('العضو الموجّه إليه')->options(fn () => Mp::with('user')->get()->mapWithKeys(fn (Mp $mp) => [$mp->id => $mp->display_name ?: "عضو #{$mp->id}"]))->searchable(),
            TextInput::make('reference_number')->label('الرقم المرجعي')->disabled()->dehydrated(false)->helperText('يُنشأ تلقائيًا عند الحفظ.'),
            Select::make('request_type_id')->label('نوع الطلب')->relationship('requestType', 'name', fn ($query) => $query->where('is_active', true)->orderBy('sort_order'))->searchable()->preload()->required(),
            Select::make('request_priority_id')->label('أولوية الطلب')->relationship('requestPriority', 'name', fn ($query) => $query->where('is_active', true)->orderBy('sort_order'))->searchable()->preload()->required(),
            Select::make('request_status_id')->label('حالة الطلب')->relationship('requestStatus', 'name', fn ($query) => $query->where('is_active', true)->orderBy('sort_order'))->searchable()->preload()->required(),
            TextInput::make('title')->label('عنوان الطلب')->required()->maxLength(255),
            Textarea::make('content')->label('تفاصيل الطلب')->required()->rows(6)->columnSpanFull(),
            \Filament\Forms\Components\SpatieMediaLibraryFileUpload::make('attachments')
                ->collection('attachments')
                ->label('المرفقات والمستندات الداعمة')
                ->multiple()
                ->downloadable()
                ->openable()
                ->columnSpanFull(),
            Textarea::make('notes')->label('ملاحظات')->rows(4)->columnSpanFull(),
        ]), Section::make('الجهة المقدّم لها الطلب')->schema([
            Select::make('recipient_sector')->label('النوع')->options([
                'government' => 'حكومي',
                'private' => 'خاص',
                'other' => 'أخرى',
            ])->required()->reactive(),
            TextInput::make('recipient_name')->label('اسم الجهة')->maxLength(255)
                ->visible(fn (callable $get): bool => $get('recipient_sector') === 'other')
                ->required(fn (callable $get): bool => $get('recipient_sector') === 'other'),
        ])]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('reference_number')->label('المرجع')->badge()->searchable()->copyable(),
            TextColumn::make('user.name')->label('المواطن')->searchable()->sortable(),
            TextColumn::make('mp.user.name')->label('العضو الموجّه إليه')->placeholder('غير محدد')->searchable(),
            TextColumn::make('title')->label('العنوان')->searchable()->wrap(),
            TextColumn::make('requestType.name')->label('النوع')->badge()->placeholder('غير محدد'),
            TextColumn::make('requestPriority.name')->label('الأولوية')->badge()->placeholder('غير محدد')->color(fn (MpRequest $record) => $record->requestPriority?->color),
            TextColumn::make('requestStatus.name')->label('الحالة')->badge()->placeholder('غير محدد')->color(fn (MpRequest $record) => $record->requestStatus?->color),
            TextColumn::make('created_at')->label('تاريخ التقديم')->dateTime()->sortable(),
        ])->filters([
            SelectFilter::make('mp_id')->label('العضو')->options(fn () => Mp::with('user')->get()->mapWithKeys(fn (Mp $mp) => [$mp->id => $mp->display_name ?: "عضو #{$mp->id}"])),
            SelectFilter::make('request_type_id')->label('النوع')->options(fn () => RequestType::orderBy('sort_order')->pluck('name', 'id')),
            SelectFilter::make('request_priority_id')->label('الأولوية')->options(fn () => RequestPriority::orderBy('sort_order')->pluck('name', 'id')),
            SelectFilter::make('request_status_id')->label('الحالة')->options(fn () => RequestStatus::orderBy('sort_order')->pluck('name', 'id')),
        ])->recordActions([Actions\ViewAction::make(), Actions\EditAction::make(), Actions\DeleteAction::make()]);
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListMpRequests::route('/'), 'create' => Pages\CreateMpRequest::route('/create'), 'edit' => Pages\EditMpRequest::route('/{record}/edit'), 'view' => Pages\ViewMpRequest::route('/{record}')];
    }
}
