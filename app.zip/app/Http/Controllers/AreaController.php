<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Area;
use App\Models\Markaz;
use Illuminate\Validation\Rule;

class AreaController extends Controller
{
    /**
     * Auto-create a markaz for a governorate if it doesn't exist.
     * Expects JSON: { governorate_id: int, name_ar: string }
     */
    public function autoCreateMarkaz(Request $request)
    {
        $data = $request->validate([
            'governorate_id' => ['required','integer','exists:governorates,id'],
            'name_ar' => ['required','string','max:255'],
        ]);

        // Try to find existing markaz (case-insensitive)
        $existing = Markaz::where('governorate_id', $data['governorate_id'])
            ->whereRaw('LOWER(name_ar) = ?', [mb_strtolower($data['name_ar'])])->first();

        if ($existing) {
            return response()->json(['id' => $existing->id, 'name_ar' => $existing->name_ar]);
        }

        $markaz = Markaz::create([
            'governorate_id' => $data['governorate_id'],
            'name_ar' => $data['name_ar'],
        ]);

        return response()->json(['id' => $markaz->id, 'name_ar' => $markaz->name_ar]);
    }

    /**
     * Auto-create an area for a markaz if it doesn't exist.
     * Expects JSON: { markaz_id: int, name_ar: string }
     */
    public function autoCreate(Request $request)
    {
        $data = $request->validate([
            'markaz_id' => ['required','integer','exists:markazes,id'],
            'name_ar' => ['required','string','max:255'],
        ]);

        // Retrieve governorate_id from markaz
        $markaz = Markaz::findOrFail($data['markaz_id']);

        // Try to find existing area (case-insensitive)
        $existing = Area::where('markaz_id', $data['markaz_id'])
            ->whereRaw('LOWER(name_ar) = ?', [mb_strtolower($data['name_ar'])])->first();

        if ($existing) {
            return response()->json(['id' => $existing->id, 'name_ar' => $existing->name_ar]);
        }

        $area = Area::create([
            'markaz_id' => $data['markaz_id'],
            'governorate_id' => $markaz->governorate_id, // Keep governorate_id for backward compatibility
            'name_ar' => $data['name_ar'],
        ]);

        return response()->json(['id' => $area->id, 'name_ar' => $area->name_ar]);
    }
}
