<?php

namespace App\Filament\Resources\MemberAds\Pages;

use App\Filament\Resources\MemberAds\MemberAdResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMemberAd extends CreateRecord
{
    protected static string $resource = MemberAdResource::class;
}
