<?php

namespace App\Http\Controllers;

use App\Models\Mp;
use App\Models\User;
use App\Models\MemberAd;
use Illuminate\Http\Request;

class MpController extends Controller
{
    public function index(Request $request)
    {
        $query = Mp::with('user')->where('is_active', true);

        if ($request->filled('city')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('city', $request->city);
            });
        }

        if ($request->filled('area')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('area', $request->area);
            })->orWhere('district', $request->area);
        }

        $mps = $query->latest()->get();

        // Distinct filters for governorates and districts
        $cities = User::whereHas('mp')->whereNotNull('city')->where('city', '!=', '')->distinct()->pluck('city');
        $areas = User::whereHas('mp')->whereNotNull('area')->where('area', '!=', '')->distinct()->pluck('area');

        return view('pages.members', compact('mps', 'cities', 'areas'));
    }

    public function show($id)
    {
        $mp = Mp::with([
            'user.governorate',
            'user.markazModel',
            'user.areaModel',
            'activeSubscription.plan',
        ])->findOrFail($id);

        // Strictly load only this specific MP's own active videos
        $videos = $mp->videos()
            ->where('mp_id', $mp->id)
            ->where('is_active', true)
            ->where(function ($published) {
                $published->whereNull('published_at')->orWhere('published_at', '<=', now());
            })
            ->with(['category', 'media'])
            ->latest('published_at')
            ->get();

        $mp->setRelation('videos', $videos);

        // Strictly load only this specific MP's own video categories
        $videoCategories = $mp->videoCategories()
            ->where('mp_id', $mp->id)
            ->with(['videos' => function ($query) use ($mp) {
                $query->where('mp_id', $mp->id)
                    ->where('is_active', true)
                    ->where(function ($published) {
                        $published->whereNull('published_at')->orWhere('published_at', '<=', now());
                    });
            }])
            ->get();

        $mp->setRelation('videoCategories', $videoCategories);

        $followersCount = $mp->followers()->count();
        $isFollowing = false;
        $userRequests = collect();

        if (auth()->check()) {
            $isFollowing = auth()->user()->followingMps()->where('mp_id', $mp->id)->exists();
            // Privacy rule: Only fetch the authenticated user's OWN requests directed to this MP
            $userRequests = auth()->user()->requests()
                ->where('mp_id', $mp->id)
                ->with(['requestStatus', 'requestType', 'requestPriority', 'replies'])
                ->latest()
                ->get();
        }

        // Aggregate statistics for MP profile (numbers only, strictly protecting other citizens' identity)
        $totalRequestsCount = $mp->requests()->count();
        $completedRequestsCount = $mp->requests()
            ->where(function ($q) {
                $q->where('status', 'completed')
                    ->orWhereHas('requestStatus', fn ($s) => $s->where('name', 'like', '%مكتمل%'));
            })->count();
        $repliedRequestsCount = $mp->requests()
            ->where(function ($q) {
                $q->whereHas('replies')
                    ->orWhere('status', 'completed')
                    ->orWhereHas('requestStatus', fn ($s) => $s->where('name', 'like', '%مكتمل%'));
            })->count();
        $responseRate = $totalRequestsCount > 0 ? min(100, round(($repliedRequestsCount / $totalRequestsCount) * 100)) : 100;
        $videosCount = $mp->videos()->where('mp_id', $mp->id)->where('is_active', true)->count();

        // MP's own news & citizen updates (strictly where mp_id = $mp->id)
        $posts = $mp->posts()
            ->where('mp_id', $mp->id)
            ->with(['category', 'media'])
            ->where('is_published', true)
            ->latest('published_at')
            ->get();

        // MP's own community polls (strictly where mp_id = $mp->id)
        $polls = $mp->polls()
            ->where('mp_id', $mp->id)
            ->with(['options', 'votes'])
            ->latest()
            ->get();

        $displayStats = [
            'followers' => $mp->followers_stat_mode === 'manual' && $mp->followers_stat_manual !== null ? (int) $mp->followers_stat_manual : $followersCount,
            'completed_requests' => $mp->completed_requests_stat_mode === 'manual' && $mp->completed_requests_stat_manual !== null ? (int) $mp->completed_requests_stat_manual : $completedRequestsCount,
            'recorded_videos' => $mp->recorded_videos_stat_mode === 'manual' && $mp->recorded_videos_stat_manual !== null ? (int) $mp->recorded_videos_stat_manual : $videosCount,
            'response_rate' => $mp->response_rate_stat_mode === 'manual' && $mp->response_rate_stat_manual !== null ? (int) $mp->response_rate_stat_manual : $responseRate,
        ];
        // Active advertisements inside this MP page
        $memberAds = MemberAd::where(function($q) use ($mp) {
        $q->where('member_id', $mp->user_id)
          ->orWhere('member_id', $mp->id);
    })
    ->active()
    ->orderBy('priority')
    ->get()
    ->filter(fn($ad) => $ad->canDisplay())
    ->values();
        $generalSettings = app(\App\Settings\GeneralSettings::class);

return view('pages.mp_page', compact(
    'mp', 'followersCount', 'isFollowing', 'userRequests',
    'totalRequestsCount', 'completedRequestsCount', 'responseRate',
    'videosCount', 'posts', 'polls', 'generalSettings', 
    'displayStats', 'memberAds'
));
    }
}
