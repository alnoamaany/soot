<?php

namespace App\Observers;

use App\Models\MpVideo;
use App\Filament\Resources\MpResource;
use App\Services\AdminAlertService;

class MpVideoObserver
{
    public function created(MpVideo $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');

        $url = null;

        if ($model->mp_id) {
            try {
                $url = MpResource::getUrl('edit', [
                    'record' => $model->mp_id,
                ]);
            } catch (\Throwable) {
                $url = null;
            }
        }

        AdminAlertService::notify(
            'video_created',
            'إضافة فيديو جديد',
            str_replace(
                ['{title}'],
                [$title],
                'تمت إضافة الفيديو "{title}" بواسطة النائب.'
            ),
            $model,
            url: $url,
            meta: [
                'video_id' => $model->id,
                'mp_id' => $model->mp_id,
            ],
        );
    }
}
