<?php
namespace App\Observers;

use App\Models\Poll;
use App\Services\AdminAlertService;

class PollObserver
{
    public function created(Poll $model): void
    {
        $title = (string) ($model->title ?? $model->subject ?? $model->name ?? $model->question ?? 'بدون عنوان');
        AdminAlertService::notify(
            'poll_created',
            'إضافة استطلاع جديد',
            str_replace(['{title}'], [$title], 'تمت إضافة استطلاع جديد: "{title}".'),
            $model,
            meta: ['poll_id' => $model->id],
        );
    }
}
