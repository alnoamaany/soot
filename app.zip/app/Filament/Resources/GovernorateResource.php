<?php

namespace App\Filament\Resources;

use App\Filament\Resources\GovernorateResource\Pages;
use App\Models\Governorate;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Actions;
use Filament\Schemas\Components\Section;

class GovernorateResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = Governorate::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-map';

    protected static ?int $navigationSort = 1;

    public static function getModelLabel(): string
    {
        return 'محافظة';
    }

    public static function getPluralModelLabel(): string
    {
        return 'المحافظات';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'إدارة الجغرافيا والمناطق';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('بيانات المحافظة')
                ->schema([
                    TextInput::make('name_ar')
                        ->label('اسم المحافظة (بالعربية)')
                        ->required()
                        ->maxLength(255)
                        ->unique(table: 'governorates', column: 'name_ar', ignoreRecord: true)
                        ->validationMessages([
                            'unique' => 'اسم المحافظة مسجل مسبقاً.',
                        ]),

                    TextInput::make('name_en')
                        ->label('اسم المحافظة (بالإنجليزية)')
                        ->maxLength(255),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('#')
                    ->sortable(),

                TextColumn::make('name_ar')
                    ->label('اسم المحافظة (بالعربية)')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),

                TextColumn::make('name_en')
                    ->label('اسم المحافظة (بالإنجليزية)')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('markazes_count')
                    ->label('عدد المراكز/الأقسام')
                    ->counts('markazes')
                    ->badge()
                    ->color('info'),

                TextColumn::make('areas_count')
                    ->label('عدد المناطق/الأحياء')
                    ->counts('areas')
                    ->badge()
                    ->color('success'),

                TextColumn::make('created_at')
                    ->label('تاريخ الإنشاء')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([])
            ->recordActions([
                Actions\ViewAction::make(),
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListGovernorates::route('/'),
            'create' => Pages\CreateGovernorate::route('/create'),
            'edit' => Pages\EditGovernorate::route('/{record}/edit'),
        ];
    }
}
