<?php
namespace App\Filament\Resources\CitizenNotificationResource\Pages;use App\Filament\Resources\CitizenNotificationResource;use Filament\Resources\Pages\ViewRecord;class ViewCitizenNotification extends ViewRecord{protected static string $resource=CitizenNotificationResource::class;}
