<?php
namespace App\Filament\Pages;
use App\Settings\GeneralSettings;
use Filament\Pages\SettingsPage;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\RichEditor;
class ManageWelcomeNotice extends SettingsPage {
 protected static string $settings=GeneralSettings::class;
 public static function getNavigationIcon():string{return 'heroicon-o-sparkles';}
 public static function getNavigationGroup():?string{return 'الدعم والاتصالات';}
 public static function getNavigationSort():?int{return 10;}
 public static function getNavigationLabel():string{return 'إشعار البداية';}
 public function getTitle():string{return 'إشعار البداية';}
 public function form(Schema $schema):Schema{return $schema->components([
  Section::make('مظهر وإعدادات الإشعار')->schema([
   Toggle::make('welcome_notice_enabled')->label('تفعيل'),
   TextInput::make('welcome_notice_title')->label('العنوان'),
   ColorPicker::make('welcome_notice_color')->label('لون العنوان'),
   RichEditor::make('welcome_notice_body')->label('النص')->columnSpanFull(),
   TextInput::make('welcome_notice_duration_seconds')->label('مدة الظهور بالثواني')->numeric()->minValue(1)->maxValue(60),
   Toggle::make('welcome_notice_show_every_visit')->label('إظهار عند كل فتح للمنصة')->helperText('عند الإيقاف يظهر مرة واحدة لكل متصفح حتى تغيير الإشعار.'),
  ])->columns(2)
 ]);}
}