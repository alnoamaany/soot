<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class EgyptianPhone implements ValidationRule
{
    /**
     * Normalize an Egyptian phone string:
     * - Convert Arabic/Eastern digits to English digits
     * - Remove non-digits except a leading plus
     * - Remove leading country codes (+20, 0020, 20) to format as local (01xxxxxxxxx)
     */
    public static function normalize(?string $phone): string
    {
        if ($phone === null) {
            return '';
        }

        // Convert Arabic/Eastern digits
        $easternDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $westernDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        $clean = str_replace($easternDigits, $westernDigits, trim($phone));

        // Remove whitespace, dashes, slashes, brackets
        $clean = preg_replace('/[\s\-\(\)\/\.]+/', '', $clean);

        // Normalize country code (+20 or 0020 or 20)
        if (str_starts_with($clean, '+20')) {
            $clean = '0' . substr($clean, 3);
        } elseif (str_starts_with($clean, '0020')) {
            $clean = '0' . substr($clean, 4);
        } elseif (str_starts_with($clean, '20') && strlen($clean) === 12 && str_starts_with($clean, '201')) {
            $clean = '0' . substr($clean, 2);
        }

        return $clean;
    }

    /**
     * Run the validation rule.
     *
     * @param  \Closure(string, ?string=): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (empty($value)) {
            $fail('رقم الهاتف مطلوب.');
            return;
        }

        $normalized = self::normalize((string) $value);

        // Egyptian mobile phone format: 11 digits starting with 010, 011, 012, or 015
        if (!preg_match('/^01[0125][0-9]{8}$/', $normalized)) {
            $fail('رقم الهاتف يجب أن يكون رقم مصري صحيح مكون من 11 رقماً يبدأ بـ (010, 011, 012, 015).');
        }
    }
}
