<?php
namespace App\Http\Middleware;
use App\Models\AccessBan; use Closure; use Illuminate\Http\Request; use Symfony\Component\HttpFoundation\Response;
class CheckAccessBan {
 public function handle(Request $request, Closure $next): Response {
   $ban=AccessBan::where('is_active',true)->where(function($q)use($request){$q->where('ip_address',$request->ip());})->latest()->first();
   if($ban) return response()->view('errors.access-banned',['reason'=>$ban->reason ?: 'تم منع هذا الاتصال من دخول المنصة.'],403);
   return $next($request);
 }
}
