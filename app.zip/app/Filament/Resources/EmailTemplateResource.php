<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EmailTemplateResource\Pages;
use App\Models\EmailTemplate;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Actions\EditAction;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\HtmlString;
use UnitEnum;
use BackedEnum;

class EmailTemplateResource extends Resource
{
    protected static ?string $model = EmailTemplate::class;

    protected static string|BackedEnum|null $navigationIcon = 'heroicon-o-envelope-open';

    protected static ?string $navigationLabel = 'قوالب البريد الإلكتروني';

    protected static ?string $modelLabel = 'قالب بريد إلكتروني';

    protected static ?string $pluralModelLabel = 'قوالب البريد الإلكتروني';

    protected static string|UnitEnum|null $navigationGroup = 'الإعدادات';

    protected static ?int $navigationSort = 110;

    public static function getNavigationBadge(): ?string
    {
        return (string) EmailTemplate::count();
    }

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('بيانات القالب')
                    ->description('تحكم كامل في محتوى الرسالة الإلكترونية. التعديلات هنا تطبق مباشرة على الرسائل التي تستخدم هذا القالب.')
                    ->schema([
                        TextInput::make('name')
                            ->label('اسم القالب')
                            ->required()
                            ->maxLength(255),

                        TextInput::make('key')
                            ->label('مفتاح القالب')
                            ->disabled()
                            ->dehydrated(false)
                            ->helperText('المفتاح البرمجي للقالب ولا يتم تغييره من لوحة التحكم.'),

                        Toggle::make('is_enabled')
                            ->label('تفعيل هذا القالب')
                            ->helperText('عند التعطيل لن يتم إرسال هذا النوع من الرسائل.')
                            ->default(true)
                            ->columnSpanFull(),
                    ])
                    ->columns(2),

                Section::make('محتوى البريد الإلكتروني')
                    ->description('يمكنك تعديل النصوص بالكامل. المتغيرات المدعومة موضحة أسفل كل حقل.')
                    ->schema([
                        TextInput::make('subject')
                            ->label('موضوع / عنوان البريد')
                            ->maxLength(255)
                            ->helperText(fn ($record) => new HtmlString(
                                '<strong>المتغيرات المتاحة:</strong> ' .
                                e(self::variablesFor($record?->key))
                            ))
                            ->columnSpanFull(),

                        TextInput::make('greeting')
                            ->label('التحية')
                            ->maxLength(255)
                            ->helperText(fn ($record) => new HtmlString(
                                '<strong>مثال:</strong> مرحباً {name}،<br>' .
                                '<strong>المتغيرات:</strong> ' .
                                e(self::variablesFor($record?->key))
                            ))
                            ->columnSpanFull(),

                        RichEditor::make('body_html')
                            ->label('محتوى الرسالة')
                            ->toolbarButtons([
                                'bold',
                                'italic',
                                'underline',
                                'strike',
                                'link',
                                'blockquote',
                                'h2',
                                'h3',
                                'bulletList',
                                'orderedList',
                                'undo',
                                'redo',
                            ])
                            ->helperText(fn ($record) => new HtmlString(
                                '<strong>المتغيرات المتاحة:</strong> ' .
                                e(self::variablesFor($record?->key))
                            ))
                            ->columnSpanFull(),

                        TextInput::make('button_text')
                            ->label('نص زر الإجراء')
                            ->maxLength(255)
                            ->helperText('اتركه فارغاً إذا كنت لا تريد إظهار زر.'),

                        TextInput::make('button_url')
                            ->label('رابط زر الإجراء')
                            ->maxLength(2000)
                            ->helperText(fn ($record) => new HtmlString(
                                '<strong>المتغيرات المتاحة:</strong> ' .
                                e(self::variablesFor($record?->key))
                            )),

                        Textarea::make('footer')
                            ->label('النص السفلي للرسالة')
                            ->rows(4)
                            ->helperText(fn ($record) => new HtmlString(
                                '<strong>المتغيرات المتاحة:</strong> ' .
                                e(self::variablesFor($record?->key))
                            ))
                            ->columnSpanFull(),
                    ])
                    ->columns(2),

                Section::make('المتغيرات')
                    ->description('استخدم هذه المتغيرات داخل موضوع الرسالة أو التحية أو المحتوى أو الرابط أو الفوتر. سيتم استبدالها تلقائياً بالقيمة الفعلية عند الإرسال.')
                    ->schema([
                        Textarea::make('variables_reference')
                            ->label('المتغيرات المتاحة لهذا القالب')
                            ->default(fn ($record) => self::variablesFor($record?->key))
                            ->disabled()
                            ->dehydrated(false)
                            ->rows(4)
                            ->columnSpanFull(),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('اسم القالب')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('key')
                    ->label('المفتاح')
                    ->badge()
                    ->searchable(),

                Tables\Columns\IconColumn::make('is_enabled')
                    ->label('الحالة')
                    ->boolean(),

                Tables\Columns\TextColumn::make('subject')
                    ->label('موضوع الرسالة')
                    ->limit(60)
                    ->searchable(),

                Tables\Columns\TextColumn::make('updated_at')
                    ->label('آخر تعديل')
                    ->dateTime('Y-m-d H:i')
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('is_enabled')
                    ->label('حالة القالب'),
            ])
            ->actions([
                EditAction::make()
                    ->label('تعديل'),
            ])
            ->bulkActions([])
            ->defaultSort('id');
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListEmailTemplates::route('/'),
            'create' => Pages\CreateEmailTemplate::route('/create'),
            'edit' => Pages\EditEmailTemplate::route('/{record}/edit'),
        ];
    }

    public static function variablesFor(?string $key): string
    {
        return match ($key) {
            'welcome',
            'account_approved' => '{name}, {phone}, {email}, {site_name}, {status}, {login_url}',

            'important_citizen_notification',
            'important_platform_notification',
            'admin_content_action' => '{name}, {email}, {title}, {message}, {url}, {site_name}',

            'new_device_login_citizen',
            'new_device_login_admin' => '{name}, {account_name}, {email}, {ip_address}, {country}, {user_agent}, {login_at}, {site_name}',

            'subscription_expiring' => '{name}, {email}, {date}, {ends_at}, {site_name}',

            'admin_activity' => '{name}, {email}, {event}, {title}, {message}, {url}, {site_name}',

            default => 'لا توجد متغيرات محددة.',
        };
    }
}
