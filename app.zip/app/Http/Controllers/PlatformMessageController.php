<?php
namespace App\Http\Controllers;
use App\Models\PlatformMessage;
use App\Models\Admin;
use App\Models\User;
use App\Notifications\PlatformMessageNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class PlatformMessageController extends Controller {
 public function index(){
  $user=Auth::user(); abort_unless($user?->mp,403);
  $messages=PlatformMessage::where(fn($q)=>$q->where('recipient_type',User::class)->where('recipient_id',$user->id))->orWhere(fn($q)=>$q->where('sender_type',User::class)->where('sender_id',$user->id))->latest()->get();
  return view('member.messages',compact('messages'));
 }
 public function reply(Request $request,PlatformMessage $message){
  $user=Auth::user(); abort_unless($user?->mp,403);
  $isRecipient=$message->recipient_type===User::class && (int)$message->recipient_id===(int)$user->id;
  $isSender=$message->sender_type===User::class && (int)$message->sender_id===(int)$user->id;
  abort_unless($isRecipient||$isSender,403);
  $data=$request->validate(['message'=>'required|string|max:5000']);
  $target=$isRecipient?$message->sender:$message->recipient;
  if(!$target) return back()->with('error','لا يمكن تحديد مستلم الرسالة.');
  PlatformMessage::create(['sender_type'=>User::class,'sender_id'=>$user->id,'recipient_type'=>get_class($target),'recipient_id'=>$target->id,'subject'=>'رد: '.($message->subject?:'رسالة إدارية'),'message'=>$data['message']]);
  $url=$target instanceof User?route('member.messages'):url('/admin/platform-messages');
  $target->notify(new PlatformMessageNotification('رسالة جديدة من النائب',$data['message'],$url));
  return back()->with('success','تم إرسال الرد بنجاح.');
 }
 public function composeAdmin(){ $user=Auth::user(); abort_unless($user?->mp,403); return view('member.message_admin',['admins'=>Admin::where('is_active',true)->orderBy('name')->get()]); }
 public function sendAdmin(Request $request){
  $user=Auth::user(); abort_unless($user?->mp,403);
  $data=$request->validate(['admin_id'=>'required|exists:admins,id','subject'=>'nullable|string|max:255','message'=>'required|string|max:5000']);
  $admin=Admin::findOrFail($data['admin_id']);
  PlatformMessage::create(['sender_type'=>User::class,'sender_id'=>$user->id,'recipient_type'=>Admin::class,'recipient_id'=>$admin->id,'subject'=>$data['subject']?:'رسالة إدارية من النائب','message'=>$data['message']]);
  $admin->notify(new PlatformMessageNotification('رسالة إدارية من النائب',$data['message'],url('/admin/platform-messages')));
  return redirect()->route('member.messages')->with('success','تم إرسال الرسالة الإدارية.');
 }
}
