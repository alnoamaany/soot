<?php

namespace App\Http\Middleware;

use App\Settings\GeneralSettings;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class EnforceDeviceLimit
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! Auth::check() || ! $request->hasSession()) {
            return $next($request);
        }

        $account = Auth::user();
        if (!empty($account->banned_at)) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return response()->view('errors.access-banned', ['reason' => $account->ban_reason ?: 'تم حظر هذا الحساب من دخول المنصة.'], 403);
        }
        if (!empty($account->mp_suspended_at)) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return response()->view('errors.access-banned', ['reason' => $account->mp_suspension_reason ?: 'تم إيقاف هذا الحساب مؤقتاً بواسطة إدارة المنصة.'], 403);
        }
        if (!empty($account->mp_deleted_at)) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return response()->view('errors.access-banned', ['reason' => 'تم تعليق الحساب لحين مراجعة الإدارة.'], 403);
        }

        $limit = (int) (app(GeneralSettings::class)->max_devices_per_user ?? 0);
        if ($limit <= 0) {
            return $next($request);
        }

        $sessionId = $request->session()->getId();
        $activeSince = now()->subMinutes((int) config('session.lifetime', 120))->timestamp;

        $query = DB::table(config('session.table', 'sessions'))
            ->where('user_id', Auth::id())
            ->where('last_activity', '>=', $activeSince);

        if ($query->where('id', '!=', $sessionId)->count() >= $limit) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('login')
                ->with('error', 'تم الوصول إلى الحد الأقصى لعدد الأجهزة المسموح بها لهذا الحساب. يرجى تسجيل الخروج من جهاز آخر ثم المحاولة مرة أخرى.');
        }

        return $next($request);
    }
}
