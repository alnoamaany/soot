<?php

namespace App\Filament\Resources\MarkazResource\Pages;

use App\Filament\Resources\MarkazResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMarkaz extends CreateRecord
{
    protected static string $resource = MarkazResource::class;
}
