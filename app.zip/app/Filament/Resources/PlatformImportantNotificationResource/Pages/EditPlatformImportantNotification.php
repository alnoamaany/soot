<?php
namespace App\Filament\Resources\PlatformImportantNotificationResource\Pages;
use App\Filament\Resources\PlatformImportantNotificationResource;
use Filament\Resources\Pages\EditRecord;
class EditPlatformImportantNotification extends EditRecord { protected static string $resource = PlatformImportantNotificationResource::class; }
