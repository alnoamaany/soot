<?php
namespace App\Filament\Resources\MpSubscriptionResource\Pages;
use App\Filament\Resources\MpSubscriptionResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
class EditMpSubscription extends EditRecord { protected static string $resource = MpSubscriptionResource::class; protected function getHeaderActions(): array { return [Actions\DeleteAction::make()]; } }
