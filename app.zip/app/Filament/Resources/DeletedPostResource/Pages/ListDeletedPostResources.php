<?php
namespace App\Filament\Resources\DeletedPostResource\Pages;
use App\Filament\Resources\DeletedPostResource;
use Filament\Resources\Pages\ListRecords;
class ListDeletedPostResources extends ListRecords { protected static string $resource = DeletedPostResource::class; }
