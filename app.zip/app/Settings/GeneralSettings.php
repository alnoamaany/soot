<?php

namespace App\Settings;

use Spatie\LaravelSettings\Settings;
use Spatie\LaravelSettings\Attributes\ShouldBeEncrypted;

class GeneralSettings extends Settings
{
    public string $site_name;
    public ?string $site_slogan = null;
    public ?string $featured_notice = 'البوابة الرسمية — مجلس الشعب المصري';
    public ?string $site_logo;
    public ?string $site_favicon;
    public ?string $about_us;
    public ?string $privacy_policy;
    public ?string $terms_of_use;
    public ?string $footer_copyright = null;
    public array $footer_links = [];

    public bool $smtp_enabled = false;
    public ?string $smtp_host = null;
    public int $smtp_port = 587;
    public ?string $smtp_username = null;
    #[ShouldBeEncrypted]
    public ?string $smtp_password = null;
    public ?string $smtp_encryption = 'tls';
    public ?string $smtp_from_address = null;
    public ?string $smtp_from_name = null;

    // Contact Page Settings
    public ?string $contact_phone = '+20 2 1234 5678';
    public ?string $contact_email = 'info@parliament.gov.eg';
    public ?string $contact_address = 'مجلس النواب المصري، شارع قصر العيني، القاهرة، مصر';
    public ?string $contact_intro = 'نحن هنا للاستماع لاستفساراتك ومقترحاتك. يرجى تعبئة النموذج أدناه وسنقوم بالرد عليك في أقرب وقت ممكن.';

    // Google Ads / AdSense Settings
    public bool $google_adsense_enabled = false;
    public ?string $google_adsense_client_id = null;
    public bool $google_ads_auto_ads = true;
    public ?string $google_ads_header_code = null;
    public ?string $google_ad_slot_top = null;
    public ?string $google_ad_slot_sidebar = null;
    public ?string $google_ad_slot_in_article = null;
    public ?string $google_ad_slot_footer = null;

    // SEO, Google Search Console & Analytics
    public ?string $google_site_verification = null;
    public ?string $google_analytics_id = null;
    public ?string $meta_description = 'المنصة البرلمانية الرسمية للتواصل المباشر مع أعضاء مجلس النواب المصري ومتابعة أحدث الأخبار والبيانات والخدمات البرلمانية.';
    public ?string $meta_keywords = 'مجلس النواب, البرلمان المصري, نواب الشعب, الدوائر الانتخابية, تقديم شكوى برلمانية, أخبار البرلمان, مصر';
    public ?string $og_image = null;

    // Regular Homepage Banner Ad Settings (Multi-placement)
    public bool $home_banner_ad_enabled = true;
    public array $home_banner_ad_placements = ['below_members'];
    public ?string $home_banner_ad_image = null;
    public ?string $home_banner_ad_url = null;
    public ?string $home_banner_ad_title = null;
    public ?string $home_banner_ad_subtitle = null;
    public ?string $home_banner_ad_code = null;
    public array $home_banner_ads = [];

    // Citizen Request Limits & Approval
    public int $citizen_monthly_request_limit = 0;
    public int $citizen_max_active_requests = 0;
    public bool $auto_approve_citizens = false;
    public bool $citizen_requests_enabled = true;
    public bool $latest_requests_widget_enabled = true;

    // Welcome / Startup Notice Settings
    // Administrative notification controls
    public bool $admin_notifications_enabled = true;
    public bool $admin_email_notifications_enabled = true;
    public ?string $admin_notification_email = null;

    public bool $welcome_notice_enabled = false;
    public ?string $welcome_notice_title = null;
    public ?string $welcome_notice_body = null;
    public ?string $welcome_notice_color = '#C8A84B';
    public int $welcome_notice_duration_seconds = 5;
    public bool $welcome_notice_show_every_visit = false;
    // Welcome Email Settings
    public bool $welcome_email_enabled = true;
    public string $welcome_email_subject = 'مرحباً بك في منصة {site_name}';
    public ?string $welcome_email_body = null;

    // Account Approval Email Settings
    // Platform security and access controls
    public ?string $blocked_words = '';
    public int $session_lifetime = 120;
    public int $max_devices_per_user = 3;

    // MP profile statistic visibility
    public bool $mp_show_followers = true;
    public bool $mp_show_completed_requests = true;
    public bool $mp_show_recorded_videos = true;
    public bool $mp_show_response_rate = true;

    // Citizen email notification preferences
    public bool $email_notify_new_request = true;
    public bool $email_notify_request_status = true;
    public bool $email_notify_important_notifications = true;

    // Image watermark
    public bool $watermark_enabled = false;
    public ?string $watermark_image = null;
    public string $watermark_position = 'bottom-right';
    public string $watermark_motion = 'static';
    public int $watermark_opacity = 35;

    public bool $approval_email_enabled = true;
    public string $approval_email_subject = 'تهانينا! تم تفعيل واعتماد حسابكم في منصة {site_name}';
    public ?string $approval_email_body = null;

    public static function group(): string
    {
        return 'general';
    }
}
