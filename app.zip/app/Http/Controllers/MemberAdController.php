<?php

namespace App\Http\Controllers;

use App\Models\MemberAd;

class MemberAdController extends Controller
{
    public function click(MemberAd $memberAd)
    {
        $memberAd->registerClick();

        if ($memberAd->url) {
            return redirect()->away($memberAd->url);
        }

        return back();
    }
}
