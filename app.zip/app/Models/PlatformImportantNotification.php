<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class PlatformImportantNotification extends Model
{
    use HasFactory;

    protected $fillable = [
        'title', 'body', 'recipient_scope', 'recipient_user_id', 'admin_id', 'is_active', 'sent_at',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'sent_at' => 'datetime'];
    }

    public function recipient() { return $this->belongsTo(User::class, 'recipient_user_id'); }
    public function admin() { return $this->belongsTo(Admin::class); }

    public function scopeVisibleTo(Builder $query, User $user): Builder
    {
        $scope = $user->isMp() ? 'mps' : 'citizens';

        return $query->where('is_active', true)
            ->where(function (Builder $q) use ($user, $scope) {
                $q->where('recipient_scope', 'all')
                    ->orWhere('recipient_scope', $scope)
                    ->orWhere(function (Builder $specific) use ($user) {
                        $specific->where('recipient_scope', 'user')
                            ->where('recipient_user_id', $user->id);
                    });
            });
    }
}
