<?php
namespace App\Filament\Resources\DeletedLibraryResource\Pages;
use App\Filament\Resources\DeletedLibraryResource; use Filament\Resources\Pages\ListRecords;
class ListDeletedLibraryResources extends ListRecords {protected static string $resource=DeletedLibraryResource::class;}
