<?php

namespace App\Filament\Resources\PendingCitizenResource\Pages;

use App\Filament\Resources\PendingCitizenResource;
use App\Models\Governorate;
use App\Models\Markaz;
use App\Models\Area;
use App\Rules\EgyptianPhone;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditPendingCitizen extends EditRecord
{
    protected static string $resource = PendingCitizenResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('approve')
                ->label('اعتماد وتفعيل الحساب')
                ->icon('heroicon-o-check-circle')
                ->color('success')
                ->requiresConfirmation()
                ->action(function (): void {
                    $this->record->update(['is_approved' => true]);
                    $this->notify('success', 'تم اعتماد وتفعيل الحساب بنجاح.');
                    $this->redirect(PendingCitizenResource::getUrl('index'));
                }),
            Actions\ViewAction::make(),
            Actions\DeleteAction::make()->label('رفض وحذف'),
        ];
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        if (!empty($data['phone'])) {
            $data['phone'] = EgyptianPhone::normalize($data['phone']);
        }

        if (empty($data['email']) && !empty($data['phone'])) {
            $data['email'] = $data['phone'] . '@parliament.gov.eg';
        }

        if (!empty($data['governorate_id'])) {
            $data['city'] = Governorate::where('id', $data['governorate_id'])->value('name_ar');
        }
        if (!empty($data['markaz_id'])) {
            $data['markaz'] = Markaz::where('id', $data['markaz_id'])->value('name_ar');
        }
        if (!empty($data['area_id'])) {
            $data['area'] = Area::where('id', $data['area_id'])->value('name_ar');
        }

        return $data;
    }
}
