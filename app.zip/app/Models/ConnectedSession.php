<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ConnectedSession extends Model {
    protected $table='sessions'; protected $primaryKey='id'; public $incrementing=false; protected $keyType='string'; public $timestamps=false;
    protected $casts=['last_activity'=>'integer'];
    public function user(){return $this->belongsTo(User::class);}
    public function getLastActivityDateAttribute(){return \Illuminate\Carbon\Carbon::createFromTimestamp($this->last_activity);}
}
