<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

#[Fillable(['mp_id', 'subscription_plan_id', 'price', 'free_days', 'starts_at', 'ends_at', 'status', 'reminder_sent_at'])]
class MpSubscription extends Model
{
    use HasFactory;

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'free_days' => 'integer',
            'starts_at' => 'date',
            'ends_at' => 'date',
            'reminder_sent_at' => 'datetime',
        ];
    }

    public function mp()
    {
        return $this->belongsTo(Mp::class);
    }

    public function plan()
    {
        return $this->belongsTo(SubscriptionPlan::class, 'subscription_plan_id');
    }

    protected static function booted(): void
    {
        static::saving(function (self $subscription): void {
            $plan = $subscription->relationLoaded('plan')
                ? $subscription->plan
                : SubscriptionPlan::find($subscription->subscription_plan_id);

            if (! $plan) {
                return;
            }

            $subscription->starts_at ??= now()->startOfDay();
            $subscription->price ??= $plan->price;
            $subscription->free_days ??= (int) $plan->free_days;

            if (! $subscription->ends_at || $subscription->isDirty(['subscription_plan_id', 'starts_at', 'free_days'])) {
                $durationMonths = (int) ($plan->duration_months ?? 0);
                $freeDays = (int) ($subscription->free_days ?? 0);

                $subscription->ends_at = $subscription->starts_at
                    ->copy()
                    ->addMonths($durationMonths)
                    ->addDays($freeDays);
                $subscription->reminder_sent_at = null;
            }
        });
    }
}
