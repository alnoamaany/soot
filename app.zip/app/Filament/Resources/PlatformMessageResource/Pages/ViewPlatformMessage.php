<?php
namespace App\Filament\Resources\PlatformMessageResource\Pages;
use App\Filament\Resources\PlatformMessageResource;
use Filament\Resources\Pages\ViewRecord;
class ViewPlatformMessage extends ViewRecord {protected static string $resource=PlatformMessageResource::class;}
