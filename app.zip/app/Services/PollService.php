<?php

namespace App\Services;

use App\Models\Poll;
use App\Models\PollOption;
use App\Models\PollVote;
use Illuminate\Support\Facades\DB;

class PollService
{
    public function vote(Poll $poll, PollOption $option, string $ip, ?int $userId = null)
    {
        return DB::transaction(function () use ($poll, $option, $ip, $userId) {
            $hasVoted = PollVote::where('poll_id', $poll->id)
                ->where('ip_address', $ip)
                ->exists();

            if ($hasVoted) {
                throw new \Exception('لقد قمت بالتصويت بالفعل');
            }

            $vote = PollVote::create([
                'poll_id' => $poll->id,
                'poll_option_id' => $option->id,
                'ip_address' => $ip,
                'user_id' => $userId,
            ]);

            $option->increment('votes_count');

            return $vote;
        });
    }

    public function toggleStatus(Poll $poll)
    {
        $poll->is_active = !$poll->is_active;
        $poll->save();

        return $poll;
    }
}
