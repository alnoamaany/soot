<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Post extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    protected $fillable = [
        'mp_id',
        'category_id',
        'sort_order',
        'title',
        'content',
        'slug',
        'is_published',
        'published_at',
        'deleted_by_mp_id', 'deleted_by_mp_at', 'deleted_by_mp_reason',
    ];

    protected $casts = [
        'is_published' => 'boolean',
        'published_at' => 'datetime', 'deleted_by_mp_at' => 'datetime',
    ];

    /**
     * Boot the model.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($post) {
            if ($post->sort_order === null || (int) $post->sort_order === 0) {
                $post->sort_order = ((int) static::query()->where('category_id', $post->category_id)->max('sort_order')) + 1;
            }
            if (empty($post->slug)) {
                $post->slug = Str::slug($post->title) . '-' . Str::random(5);
            }
        });
    }

    /**
     * Register media collections.
     */
    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('thumbnail')
            ->singleFile();
    }

    /**
     * Get the category that owns the post.
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Get the MP that owns the post/update.
     */
    public function mp(): BelongsTo
    {
        return $this->belongsTo(Mp::class);
    }
}
