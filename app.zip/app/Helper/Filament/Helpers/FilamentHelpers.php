<?php

namespace App\Helper\Filament\Helpers;

use Filament\Forms;
use Filament\Forms\Components\Field;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Notification as LaravelNotifications;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Ysfkaya\FilamentPhoneInput;

class FilamentHelpers
{

    public static function registerMacros(): void
    {
        // DateTimePicker::configureUsing(fn (DateTimePicker $component) => $component->timezone('Africa/Cairo'));
        //        TextColumn::configureUsing(fn (TextColumn $column) => $column->timezone('Africa/Cairo'));

        Table::configureUsing(function (Table $table): void {
            $table->paginationPageOptions([5, 10, 25, 50]);
        });

        SpatieMediaLibraryFileUpload::configureUsing(fn(SpatieMediaLibraryFileUpload $field) => $field->visibility(fn(SpatieMediaLibraryFileUpload $component) => FilamentHelpers::determineDiskVisibility($component->getDiskName())));
        SpatieMediaLibraryImageColumn::configureUsing(fn(SpatieMediaLibraryImageColumn $column) => $column->visibility(fn($record, $state) => FilamentHelpers::determineDiskVisibility($record->media->first(fn(Media $media): bool => in_array($media->uuid, ($state ?? [])))?->disk)));

        Forms\Components\Select::macro('fixSelectTranslatable', function (?string $title = null) {
            return $this->getOptionLabelFromRecordUsing(fn(Model $record) => FilamentHelpers::extractLocalizedNameFromRecord($record, $title));
        });

        Forms\Components\Select::configureUsing(
            fn(Forms\Components\Select $field) => $field
                ->getOptionLabelFromRecordUsing(fn(Model $record) => FilamentHelpers::extractLocalizedNameFromRecord($record))
        );
    }

    public static function extractLocalizedNameFromRecord(Model $record, ?string $field = null)
    {
        $field ??= in_array('name', $record->getFillable())
            ? 'name'
            : 'content';

        if (!method_exists($record, 'translate')) {
            return $record->getAttribute($field) ?? '-';
        }

        if (!$record->isTranslatableAttribute($field)) {
            return $record->getAttribute($field) ?? '-';
        }

        $trans = $record->translate($field, app()->getLocale());
        if (filled($trans)) {
            return $trans ?? '-';
        }

        return collect($record->getTranslations($field))->first() ?? ($field . '-not-found-#' . $record->getKey());
    }

    public static function determineDiskVisibility(?string $disk): string
    {
        if (!filled($disk)) {
            return 'public';
        }
        if (in_array(config("filesystems.disks.{$disk}.driver"), ['s3', 'gcs', 'gcs-asia1'])) {
            return 'private';
        }

        return 'public';
    }

    public static function getPhoneFormInput($prefix = '', $initCountry = 'AE'): FilamentPhoneInput\Forms\PhoneInput
    {
        return FilamentPhoneInput\Forms\PhoneInput::make("{$prefix}phone")
            // ->label(__('Phone number'))
            ->countryStatePath("{$prefix}phone_country")
            // ->onlyCountries(array_column(PhoneCountry::cases(), 'value'))
            ->initialCountry($initCountry)
            ->i18n(app()->getLocale() == 'ar' ?
                phone_countries_ar::getCountries() :
                phone_countries_en::getCountries())
            ->formatOnDisplay(false)
            ->formatAsYouType(false)
            ->countrySearch(true)
            ->rule('phone')
            ->required();
    }

    public static function getNotifyForm(array $excludeMethods = []): array
    {
        return [
            Forms\Components\TextInput::make('title')
                ->label(__('title'))
                ->columnSpan(4)
                ->required()
                ->maxLength(191),

            Forms\Components\Textarea::make('body')
                ->label(__('details'))
                ->columnSpan(4)
                ->required(),

            Forms\Components\TextInput::make('image')
                ->label(__('image'))
                ->url()
                ->columnSpan(4),

            Forms\Components\Select::make('methods')
                ->label(__('methods'))
                ->multiple()
                ->columnSpan(4)
                ->options(collect([
                    'database' => __('database'),
                    'fcm' => __('fcm'),
                    'whatsapp' => __('whatsapp'),
                ])->except($excludeMethods)->toArray())
                ->minItems(1)
                ->required(),
        ];
    }

    public static function notifyUsersAction(array $data = [], array|Collection $users = []): bool
    {
        $class = class_exists('Modules\Notification\Notifications\GeneralNotification')
            ? \Modules\Notification\Notifications\GeneralNotification::class
            : \App\Notifications\GeneralNotification::class;

        LaravelNotifications::send(
            notifiables: $users,
            notification: new $class(
                title: $data['title'],
                body: $data['body'],
                image: $data['image'] ?? null,
                methods: $data['methods'],
            ),
        );

        Notification::make('notified_user')
            ->success()
            ->title('Notified Users')
            ->body('Notified ' . count($users) . ' Users Successfully')
            ->send();

        return true;
    }

    /**
     * Returns Same Field With Multi Langs.
     */
    public static function translateFilamentField(Field $field, array $requiredLocales = ['ar']): Group
    {
        $locales = collect(config('app.available_locales'));

        return Group::make()
            ->columnSpanFull()
            ->visible($field->isVisible())
            ->columns($locales->count())
            ->schema(
                $locales->map(
                    fn(array $lang, string $key) => $field->getClone()
                        ->name($field->getName() . '.' . $key)
                        ->statePath($field->getName() . '.' . $key)
                        ->when(!filled($field->getHint()), fn($field) => $field->hint(__('With :locale', ['locale' => $lang['native']])))
                        ->when(method_exists($field, 'placeholder'), fn($field) => $field->placeholder(__('With :locale', ['locale' => $lang['native']])))
                        ->required(in_array($key, $requiredLocales) || in_array('*', $requiredLocales))
                        ->columnSpan(1),
                )->toArray(),
            );
    }

    public static function translateFilamentFieldTap(array $fields, array $requiredLocales = ['ar'], bool $columnSpanFull = false, ?int $columns = null): Tabs
    {
        $locales = collect(config('app.available_locales'));

        $tabs = Tabs::make();

        if ($columnSpanFull === true) {
            $tabs->columnSpanFull();
        }
        if ($columns) {
            $tabs->columns($columns);
        }

        return $tabs
            ->tabs(
                $locales->map(
                    fn(array $lang, string $key) => Tab::make($lang['native'])
                        ->schema(collect($fields)->map(function (Field $field) use ($key, $lang, $requiredLocales) {
                            return $field->getClone()
                                ->name($field->getName() . '.' . $key)
                                ->statePath($field->getName() . '.' . $key)
                                ->visible($field->isVisible())
                                ->when(!filled($field->getHint()), fn($field) => $field->hint(__('With :locale', ['locale' => $lang['native']])))
                                ->when(method_exists($field, 'placeholder'), fn($field) => $field->placeholder(__('With :locale', ['locale' => $lang['native']])))
                                ->required(
                                    ($field->isRequired() && in_array('*', $requiredLocales)) || ($field->isRequired() && in_array($key, $requiredLocales))
                                );
                        })->toArray())
                )->toArray(),
            );
    }
}
