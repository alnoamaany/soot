<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FaqResource\Pages;
use App\Models\Faq;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Actions;
class FaqResource extends Resource
{
    use \App\Helper\Traits\Filamentv4\FilamentTranslatedLabelResource;
    use \App\Helper\Traits\Filamentv4\FilamentCountBadgeResource;
    protected static ?string $model = Faq::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-question-mark-circle';



    public static function getModelLabel(): string
    {
        return 'سؤال شائع';
    }

    public static function getPluralModelLabel(): string
    {
        return 'الأسئلة الشائعة';
    }

    public static function getNavigationGroup(): ?string
    {
        return 'الدعم والدليل';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('سؤال'))
                ->schema([
                    TextInput::make('question')
                        ->required()
                        ->maxLength(255),
                    Textarea::make('answer')
                        ->required()
                        ->maxLength(65535),
                ]),
            Section::make(__('الإعدادات'))
                ->schema([
                    Toggle::make('is_active')->default(true),
                    TextInput::make('sort_order')->numeric()->default(0),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('question')->limit(60)->searchable(),
            TextColumn::make('is_active'),
            TextColumn::make('sort_order')->sortable(),
            TextColumn::make('created_at')->dateTime()->sortable()->toggleable(isToggledHiddenByDefault: true),
        ])->recordActions([
           Actions\ViewAction::make(),
           Actions\EditAction::make(),
           Actions\DeleteAction::make(),
        ])->toolbarActions([
        //    Actions\CreateAction::make(),
        ]);
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListFaqs::route('/'),
            'create' => Pages\CreateFaq::route('/create'),
            'edit' => Pages\EditFaq::route('/{record}/edit'),
            'view' => Pages\ViewFaq::route('/{record}'),
        ];
    }
}
