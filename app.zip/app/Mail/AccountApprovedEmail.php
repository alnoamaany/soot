<?php

namespace App\Mail;

use App\Services\EmailTemplateService;
use App\Settings\GeneralSettings;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class AccountApprovedEmail extends Mailable
{
    use Queueable, SerializesModels;

    public string $userName;
    public string $userPhone;
    public string $userEmail;

    public string $subjectText;
    public string $greetingText;
    public string $bodyHtml;
    public string $buttonText;
    public string $buttonUrl;
    public string $footerText;

    public string $loginUrl;
    public string $siteName;
    public string $siteSlogan;
    public ?string $siteLogoUrl;

    public bool $templateEnabled;

    public function __construct(
        string $userName,
        string $userPhone,
        string $userEmail,
        ?string $customSubject = null,
        ?string $customBody = null
    ) {
        $settings = app(GeneralSettings::class);

        $this->siteName = $settings->site_name ?? 'مجلس النواب المصري';
        $this->siteSlogan = $settings->site_slogan ?? 'صوت المواطن إلى نائبه في البرلمان';
        $this->siteLogoUrl = !empty($settings->site_logo)
            ? url('storage/' . $settings->site_logo)
            : null;

        $this->userName = $userName;
        $this->userPhone = $userPhone;
        $this->userEmail = $userEmail;
        $this->loginUrl = route('login');

        $variables = [
            'name' => $this->userName,
            'phone' => $this->userPhone,
            'email' => $this->userEmail,
            'site_name' => $this->siteName,
            'login_url' => $this->loginUrl,
        ];

        $legacySubject = $customSubject
            ?: ($settings->approval_email_subject
                ?: 'تهانينا! تم تفعيل واعتماد حسابكم في منصة {site_name}');

        $legacyBody = $customBody
            ?: ($settings->approval_email_body ?: '
                <p>يسرنا إبلاغكم بأنه قد تمت مراجعة واعتماد حسابكم بنجاح في <strong>{site_name}</strong>.</p>
                <p>يمكنكم الآن تسجيل الدخول بكامل الصلاحيات واستعراض الخدمات المتاحة عبر المنصة.</p>
            ');

        $template = EmailTemplateService::render(
            'account_approved',
            $variables,
            [
                'subject' => $legacySubject,
                'greeting' => 'عزيزي المواطن {name}،',
                'body_html' => $legacyBody,
                'button_text' => 'تسجيل الدخول إلى حسابك الآن',
                'button_url' => '{login_url}',
                'footer' => 'تم إرسال هذه الرسالة آليًا من {site_name}.',
            ]
        );

        $this->templateEnabled = $template['enabled'];

        $this->subjectText = $template['subject'] ?? '';
        $this->greetingText = $template['greeting'] ?? '';
        $this->bodyHtml = $template['body_html'] ?? '';
        $this->buttonText = $template['button_text'] ?? '';
        $this->buttonUrl = $template['button_url'] ?? '';
        $this->footerText = $template['footer'] ?? '';
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->subjectText
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.account_approved'
        );
    }

    public function attachments(): array
    {
        return [];
    }
}
