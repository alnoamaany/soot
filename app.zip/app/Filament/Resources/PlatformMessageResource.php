<?php
namespace App\Filament\Resources;
use App\Filament\Resources\PlatformMessageResource\Pages;
use App\Models\PlatformMessage;
use App\Models\Admin;
use App\Models\User;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Actions;
class PlatformMessageResource extends Resource {
 protected static ?string $model=PlatformMessage::class;
 protected static string|\BackedEnum|null $navigationIcon='heroicon-o-paper-airplane';
 public static function getNavigationGroup():?string{return 'الدعم والاتصالات';}
 public static function getModelLabel():string{return 'رسالة إدارية';}
 public static function getPluralModelLabel():string{return 'الرسائل الإدارية';}
 public static function form(Schema $schema):Schema{return $schema->components([
  Section::make('إرسال رسالة')->schema([
   Select::make('recipient_kind')->label('موجه إلى')->options(['user'=>'نائب','admin'=>'إداري'])->required()->live(),
   Select::make('recipient_id')->label('المستلم')->options(function($get){$type=$get('recipient_kind');if($type==='admin')return Admin::where('is_active',true)->orderBy('name')->pluck('name','id')->toArray();if($type==='user')return User::where('role','mp')->orWhereHas('mp')->orderBy('name')->pluck('name','id')->toArray();return [];})->searchable()->required(),
   TextInput::make('subject')->label('عنوان الرسالة')->maxLength(255),
   Textarea::make('message')->label('نص الرسالة')->required()->rows(8)->maxLength(5000)->columnSpanFull(),
  ])->columns(2)
 ]);}
 public static function table(Table $table):Table{return $table->columns([
  TextColumn::make('sender.name')->label('المرسل')->searchable(),TextColumn::make('recipient.name')->label('المستلم')->searchable(),TextColumn::make('subject')->label('العنوان')->searchable(),TextColumn::make('created_at')->label('التاريخ')->dateTime()->sortable()
  ])->recordActions([Actions\ViewAction::make(),Actions\DeleteAction::make()]);}
 public static function infolist(Schema $schema):Schema{return $schema->components([Section::make('تفاصيل الرسالة')->schema([
  \Filament\Infolists\Components\TextEntry::make('sender.name')->label('المرسل'),\Filament\Infolists\Components\TextEntry::make('recipient.name')->label('المستلم'),\Filament\Infolists\Components\TextEntry::make('subject')->label('العنوان'),\Filament\Infolists\Components\TextEntry::make('message')->label('الرسالة')->columnSpanFull(),\Filament\Infolists\Components\TextEntry::make('created_at')->label('التاريخ')->dateTime()
 ])]);}
 public static function getPages():array{return ['index'=>Pages\ListPlatformMessages::route('/'),'create'=>Pages\CreatePlatformMessage::route('/create'),'view'=>Pages\ViewPlatformMessage::route('/{record}')];}
}
