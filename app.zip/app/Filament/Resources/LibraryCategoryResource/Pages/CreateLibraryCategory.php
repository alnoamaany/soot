<?php

namespace App\Filament\Resources\LibraryCategoryResource\Pages;

use App\Filament\Resources\LibraryCategoryResource;
use Filament\Resources\Pages\CreateRecord;
use Filament\Support\Enums\Width;

class CreateLibraryCategory extends CreateRecord
{
    protected static string $resource = LibraryCategoryResource::class;
    protected string|Width|null $maxContentWidth = Width::Full;
}
