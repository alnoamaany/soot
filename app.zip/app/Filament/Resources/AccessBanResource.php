<?php
namespace App\Filament\Resources;
use App\Filament\Resources\AccessBanResource\Pages;
use App\Models\AccessBan;
use Filament\Resources\Resource; use Filament\Schemas\Schema; use Filament\Schemas\Components\Section; use Filament\Forms\Components\TextInput; use Filament\Forms\Components\Textarea; use Filament\Forms\Components\Toggle; use Filament\Tables\Table; use Filament\Tables\Columns\TextColumn; use Filament\Tables\Columns\IconColumn; use Filament\Actions;
class AccessBanResource extends Resource {
 protected static ?string $model=AccessBan::class; protected static string|\BackedEnum|null $navigationIcon='heroicon-o-no-symbol'; protected static ?int $navigationSort=6;
 public static function getNavigationGroup():?string{return 'إدارة الحسابات';} public static function getModelLabel():string{return 'منع الدخول';} public static function getPluralModelLabel():string{return 'قائمة الممنوعين';}
 public static function form(Schema $schema):Schema{return $schema->components([Section::make('بيانات المنع')->schema([TextInput::make('ip_address')->label('IP')->required(),TextInput::make('country')->label('الدولة'),Textarea::make('reason')->label('سبب المنع')->required()->columnSpanFull(),Toggle::make('is_active')->label('المنع فعال')->default(true)])]);}
 public static function table(Table $table):Table{return $table->columns([TextColumn::make('ip_address')->label('IP')->searchable()->copyable(),TextColumn::make('country')->label('الدولة'),TextColumn::make('reason')->label('سبب المنع')->wrap(),IconColumn::make('is_active')->label('فعال')->boolean(),TextColumn::make('created_at')->label('تاريخ المنع')->dateTime()])->recordActions([Actions\EditAction::make(),Actions\DeleteAction::make()]);}
 public static function getPages():array{return ['index'=>Pages\ListAccessBans::route('/'),'create'=>Pages\CreateAccessBan::route('/create'),'edit'=>Pages\EditAccessBan::route('/{record}/edit')];}
}
